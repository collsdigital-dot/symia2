import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/features/auth/hooks';

interface UsageLimits {
  subscription_tier: 'free' | 'premium' | 'standard';
  text_chats_used: number;
  live_demos_used: number;
  live_demos_limit: number;
}

export function useUsageLimits() {
  const [limits, setLimits] = useState<UsageLimits | null>(null);
  const [loading, setLoading] = useState(true);
  const { user, isAdmin } = useAuth();

  const fetchLimits = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from('usage_limits')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();
    
    setLimits(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchLimits();
  }, [user]);

  // Admins have unlimited access to all features
  if (isAdmin) {
    return {
      limits,
      loading: false,
      canUseTextChat: true,
      canUseLiveSession: true,
      remainingChats: Infinity,
      remainingLiveSessions: Infinity,
      refresh: fetchLimits
    };
  }

  const canUseTextChat = limits ? 
    (limits.subscription_tier === 'premium' || limits.text_chats_used < 1) : 
    false;

  const canUseLiveSession = limits?.subscription_tier === 'premium';

  const remainingChats = limits ? 
    (limits.subscription_tier === 'premium' 
      ? Infinity 
      : limits.subscription_tier === 'standard'
        ? Math.max(0, 10 - limits.text_chats_used)
        : Math.max(0, 1 - limits.text_chats_used)
    ) : 0;

  const remainingLiveSessions = limits ?
    (limits.subscription_tier === 'premium'
      ? Infinity
      : limits.subscription_tier === 'standard'
        ? Math.max(0, 5 - limits.live_demos_used)
        : 0
    ) : 0;

  return {
    limits,
    loading,
    canUseTextChat,
    canUseLiveSession,
    remainingChats,
    remainingLiveSessions,
    refresh: fetchLimits
  };
}
