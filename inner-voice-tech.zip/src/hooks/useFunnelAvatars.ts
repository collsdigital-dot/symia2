import { useQuery } from '@tanstack/react-query';
import { AvatarOption } from '@/core/config/avatarConfig';
import { fetchLiveAvatars } from '@/features/liveavatar/services/liveAvatarService';

export function useFunnelAvatars() {
  return useQuery<AvatarOption[]>({
    queryKey: ['liveavatar-avatars'],
    queryFn: fetchLiveAvatars,
    staleTime: 1000 * 60 * 60, // Cache for 1 hour
    retry: 2,
    retryDelay: 1000
  });
}
