export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      chat_conversations: {
        Row: {
          created_at: string | null
          id: string
          topic: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          topic: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          topic?: string
          user_id?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string | null
          id: string
          role: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string | null
          id?: string
          role: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string | null
          id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "chat_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      heygen_usage_logs: {
        Row: {
          category: string
          cost_usd: number
          created_at: string | null
          duration_seconds: number
          id: string
          user_id: string
          video_id: string
        }
        Insert: {
          category: string
          cost_usd?: number
          created_at?: string | null
          duration_seconds?: number
          id?: string
          user_id: string
          video_id: string
        }
        Update: {
          category?: string
          cost_usd?: number
          created_at?: string | null
          duration_seconds?: number
          id?: string
          user_id?: string
          video_id?: string
        }
        Relationships: []
      }
      live_session_transcripts: {
        Row: {
          content: string
          created_at: string | null
          id: string
          session_id: string
          speaker: string
          timestamp_offset_ms: number | null
          turn_index: number | null
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          session_id: string
          speaker: string
          timestamp_offset_ms?: number | null
          turn_index?: number | null
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          session_id?: string
          speaker?: string
          timestamp_offset_ms?: number | null
          turn_index?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_session_transcripts_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "live_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      live_sessions: {
        Row: {
          avatar_snapshot_json: Json | null
          conversation_id: string | null
          created_at: string | null
          ended_at: string | null
          id: string
          quality_metrics_json: Json | null
          seconds_used: number | null
          started_at: string | null
          track_id: string
          track_title: string
          user_id: string
        }
        Insert: {
          avatar_snapshot_json?: Json | null
          conversation_id?: string | null
          created_at?: string | null
          ended_at?: string | null
          id?: string
          quality_metrics_json?: Json | null
          seconds_used?: number | null
          started_at?: string | null
          track_id: string
          track_title: string
          user_id: string
        }
        Update: {
          avatar_snapshot_json?: Json | null
          conversation_id?: string | null
          created_at?: string | null
          ended_at?: string | null
          id?: string
          quality_metrics_json?: Json | null
          seconds_used?: number | null
          started_at?: string | null
          track_id?: string
          track_title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_sessions_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "chat_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      liveavatar_sessions: {
        Row: {
          avatar_id: string
          category: string | null
          context_id: string | null
          created_at: string | null
          duration_seconds: number | null
          ended_at: string | null
          error_message: string | null
          id: string
          session_id: string
          started_at: string | null
          status: string | null
          user_id: string
          voice_id: string | null
        }
        Insert: {
          avatar_id: string
          category?: string | null
          context_id?: string | null
          created_at?: string | null
          duration_seconds?: number | null
          ended_at?: string | null
          error_message?: string | null
          id?: string
          session_id: string
          started_at?: string | null
          status?: string | null
          user_id: string
          voice_id?: string | null
        }
        Update: {
          avatar_id?: string
          category?: string | null
          context_id?: string | null
          created_at?: string | null
          duration_seconds?: number | null
          ended_at?: string | null
          error_message?: string | null
          id?: string
          session_id?: string
          started_at?: string | null
          status?: string | null
          user_id?: string
          voice_id?: string | null
        }
        Relationships: []
      }
      otp_codes: {
        Row: {
          attempts: number
          created_at: string
          email: string
          expires_at: string
          id: string
          is_used: boolean
          otp_code: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          email: string
          expires_at?: string
          id?: string
          is_used?: boolean
          otp_code: string
        }
        Update: {
          attempts?: number
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          is_used?: boolean
          otp_code?: string
        }
        Relationships: []
      }
      personalization_responses: {
        Row: {
          ai_insights: Json | null
          answers: Json
          category: string
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ai_insights?: Json | null
          answers?: Json
          category: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ai_insights?: Json | null
          answers?: Json
          category?: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      subscription_events: {
        Row: {
          amount_usd: number
          created_at: string | null
          duration_minutes: number
          id: string
          payment_method: string | null
          payment_status: string
          stripe_payment_intent_id: string | null
          tier: string
          user_id: string
        }
        Insert: {
          amount_usd: number
          created_at?: string | null
          duration_minutes: number
          id?: string
          payment_method?: string | null
          payment_status: string
          stripe_payment_intent_id?: string | null
          tier: string
          user_id: string
        }
        Update: {
          amount_usd?: number
          created_at?: string | null
          duration_minutes?: number
          id?: string
          payment_method?: string | null
          payment_status?: string
          stripe_payment_intent_id?: string | null
          tier?: string
          user_id?: string
        }
        Relationships: []
      }
      usage_limits: {
        Row: {
          created_at: string
          id: string
          live_demos_limit: number
          live_demos_used: number
          reset_date: string
          subscription_tier: Database["public"]["Enums"]["subscription_tier"]
          text_chats_used: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          live_demos_limit?: number
          live_demos_used?: number
          reset_date?: string
          subscription_tier?: Database["public"]["Enums"]["subscription_tier"]
          text_chats_used?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          live_demos_limit?: number
          live_demos_used?: number
          reset_date?: string
          subscription_tier?: Database["public"]["Enums"]["subscription_tier"]
          text_chats_used?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_avatars: {
        Row: {
          avatar_type: string
          avatar_url: string | null
          config_json: Json | null
          created_at: string | null
          id: string
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          avatar_type?: string
          avatar_url?: string | null
          config_json?: Json | null
          created_at?: string | null
          id?: string
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          avatar_type?: string
          avatar_url?: string | null
          config_json?: Json | null
          created_at?: string | null
          id?: string
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          avatar_language: string | null
          avatar_provider: string
          communication_style: string | null
          created_at: string | null
          favorite_color: string | null
          full_name: string
          id: string
          liveavatar_context_id: string | null
          liveavatar_id: string
          liveavatar_voice_id: string | null
          preferred_language: string | null
          preferred_topics: string[] | null
          preferred_voice: string | null
          primary_goal: string | null
          updated_at: string | null
          user_id: string
          video_background: Json | null
        }
        Insert: {
          avatar_language?: string | null
          avatar_provider?: string
          communication_style?: string | null
          created_at?: string | null
          favorite_color?: string | null
          full_name: string
          id?: string
          liveavatar_context_id?: string | null
          liveavatar_id?: string
          liveavatar_voice_id?: string | null
          preferred_language?: string | null
          preferred_topics?: string[] | null
          preferred_voice?: string | null
          primary_goal?: string | null
          updated_at?: string | null
          user_id: string
          video_background?: Json | null
        }
        Update: {
          avatar_language?: string | null
          avatar_provider?: string
          communication_style?: string | null
          created_at?: string | null
          favorite_color?: string | null
          full_name?: string
          id?: string
          liveavatar_context_id?: string | null
          liveavatar_id?: string
          liveavatar_voice_id?: string | null
          preferred_language?: string | null
          preferred_topics?: string[] | null
          preferred_voice?: string | null
          primary_goal?: string | null
          updated_at?: string | null
          user_id?: string
          video_background?: Json | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      cleanup_expired_otps: { Args: never; Returns: undefined }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      subscription_tier: "free" | "standard" | "premium"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      subscription_tier: ["free", "standard", "premium"],
    },
  },
} as const
