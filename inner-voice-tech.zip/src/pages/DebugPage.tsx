import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/features/auth';
import { LiveAvatarDebugPanel } from '@/components/debug/LiveAvatarDebugPanel';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';

export default function DebugPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/auth');
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-7xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate('/dashboard')}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <Card className="p-6 mb-6">
          <h1 className="text-3xl font-bold mb-2">LiveAvatar Debug Console</h1>
          <p className="text-muted-foreground">
            Use this page to test and debug LiveAvatar integration. The debug panel below provides:
          </p>
          <ul className="list-disc list-inside mt-2 text-sm text-muted-foreground space-y-1">
            <li>Real-time logs of all LiveAvatar operations</li>
            <li>User profile inspection (cached avatar/context IDs)</li>
            <li>Current session state and LiveKit connection info</li>
            <li>API testing tools for avatars, voices, and session creation</li>
          </ul>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="space-y-3 text-sm">
            <div>
              <strong>Test Avatar API:</strong> Verify connection to LiveAvatar's public avatars endpoint
            </div>
            <div>
              <strong>Test Voice API:</strong> Check if voice options are loading correctly
            </div>
            <div>
              <strong>Test Session Create:</strong> Attempt to create a full session (requires profile to be loaded first)
            </div>
            <div>
              <strong>View Logs Tab:</strong> See all events, API calls, errors in chronological order
            </div>
            <div>
              <strong>Profile Tab:</strong> Inspect user_profiles data including cached avatar/context/persona IDs
            </div>
          </div>
        </Card>
      </div>

      {/* Debug Panel - will auto-expand on this page */}
      <LiveAvatarDebugPanel />
    </div>
  );
}
