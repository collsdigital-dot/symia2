import { useState, useEffect } from "react";
import { useAuth } from "@/features/auth/hooks";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { TopicCard } from "@/features/dashboard/components/TopicCard";
import { ChatInterface } from "@/features/chat/components/ChatInterface";
import { RecentConversations } from "@/features/dashboard/components/RecentConversations";
import { ConversationDialog } from "@/features/dashboard/components/ConversationDialog";
import { DashboardHero } from "@/features/dashboard/components/DashboardHero";
import { BottomNav } from "@/components/ui/BottomNav";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { LogOut, Settings, Shield } from "lucide-react";
import { FreeUserSalesPage } from "@/features/dashboard/components/FreeUserSalesPage";
import { useUsageCheck } from "@/features/subscription/hooks/useUsageCheck";
import { UpgradePrompt } from "@/features/subscription/components/UpgradePrompt";
import { useUsageLimits } from "@/hooks/useUsageLimits";
import { Sparkles } from "lucide-react";
import { LiveChat } from "@/features/liveavatar";
import { LiveAvatarDebugPanel } from "@/components/debug/LiveAvatarDebugPanel";

import { TOPICS, NEUTRAL_TOPIC } from "@/features/dashboard/config/topics";

export default function Dashboard() {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [liveTopicWithVoice, setLiveTopicWithVoice] = useState<{ id: string; title: string; voice: string } | null>(null);
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [pendingTopic, setPendingTopic] = useState<string | null>(null);
  const [existingConversations, setExistingConversations] = useState<any[]>([]);
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [liveTrackId, setLiveTrackId] = useState<string | null>(null);
  const [avatarConfig, setAvatarConfig] = useState<any>(null);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);
  const [upgradeFeature, setUpgradeFeature] = useState<'text_chat' | 'live_session'>('text_chat');
  const { user, loading, signOut, role, subscriptionTier, isFreeUser } = useAuth();
  const { canUseTextChat, canUseLiveSession, loading: usageLoading, refresh: refreshUsage } = useUsageCheck();
  const { remainingChats, remainingLiveSessions, limits } = useUsageLimits();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [showWelcome, setShowWelcome] = useState(searchParams.get('firstVisit') === 'true');

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
      return;
    }

    if (user) {
      loadProfile();
      loadAvatarConfig();
    }
  }, [user, loading]);

  // Refetch avatar when refresh parameter is present
  useEffect(() => {
    if (searchParams.get('refresh') && user) {
      console.log('[Dashboard] Refresh triggered, reloading avatar');
      loadAvatarConfig();
    }
  }, [searchParams, user]);

  const loadProfile = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from("user_profiles")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle();

    if (!data) {
      // Profile doesn't exist, create one
      console.log('[Dashboard] No profile found, creating default profile');
      const { data: newProfile, error } = await supabase
        .from("user_profiles")
        .insert({
          user_id: user.id,
        full_name: user.email?.split('@')[0] || 'User',
          preferred_voice: 'shimmer',
          liveavatar_id: 'Angela-inblackskirt-20220820',
          avatar_provider: 'liveavatar',
        })
        .select()
        .single();

      if (error) {
        console.error('[Dashboard] Profile creation error:', error);
        // Set default in-memory profile to prevent blocking
        setUserProfile({
          user_id: user.id,
          full_name: user.email?.split('@')[0] || 'User',
          preferred_voice: 'shimmer',
          liveavatar_id: 'Angela-inblackskirt-20220820',
          avatar_provider: 'liveavatar',
        });
      } else {
        setUserProfile(newProfile);
      }
    } else {
      setUserProfile(data);
    }
  };

  const loadAvatarConfig = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('user_avatars')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();
    
    setAvatarConfig(data || null);
  };

  if (loading || !userProfile || usageLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-muted to-background">
        <div className="animate-pulse text-muted-foreground">Loading your dashboard...</div>
      </div>
    );
  }

  const handleTopicClick = async (topicId: string) => {
    if (!user) return;
    
    // Check usage limits FIRST
    if (!canUseTextChat) {
      setUpgradeFeature('text_chat');
      setShowUpgradePrompt(true);
      return;
    }
    
    const topic = TOPICS.find(t => t.id === topicId);
    if (!topic) return;

    // Check for existing conversations for this topic
    const { data: conversations } = await supabase
      .from("chat_conversations")
      .select("id, created_at")
      .eq("user_id", user.id)
      .eq("topic", topic.title)
      .order("created_at", { ascending: false });

    if (conversations && conversations.length > 0) {
      // User has previous conversations for this topic
      setExistingConversations(conversations);
      setPendingTopic(topicId);
      setShowDialog(true);
    } else {
      // No previous conversations, start new
      setSelectedTopic(topicId);
      setSelectedConversationId(null);
    }
  };

  const handleContinueConversation = () => {
    if (existingConversations.length > 0 && pendingTopic) {
      setSelectedTopic(pendingTopic);
      setSelectedConversationId(existingConversations[0].id);
      setShowDialog(false);
    }
  };

  const handleStartNewConversation = () => {
    if (pendingTopic) {
      setSelectedTopic(pendingTopic);
      setSelectedConversationId(null);
      setShowDialog(false);
    }
  };

  const handleSelectRecentConversation = (conversationId: string, topic: string) => {
    const topicData = TOPICS.find(t => t.title === topic);
    if (topicData) {
      setSelectedTopic(topicData.id);
      setSelectedConversationId(conversationId);
    }
  };

  const handleBackToDashboard = () => {
    setSelectedTopic(null);
    setSelectedConversationId(null);
    refreshUsage(); // Refresh usage counts when returning from chat
  };

  const handleGoLive = async (voiceOrTopicId?: string, voice?: string) => {
    // Check usage limits FIRST
    if (!canUseLiveSession) {
      setUpgradeFeature('live_session');
      setShowUpgradePrompt(true);
      return;
    }
    
    // Check if first param is a voice
    const isVoice = ['shimmer', 'alloy', 'nova', 'ballad', 'coral', 'echo', 'sage', 'ash'].includes(voiceOrTopicId || '');
    const trackId = isVoice ? NEUTRAL_TOPIC.id : (voiceOrTopicId || NEUTRAL_TOPIC.id);
    const selectedVoice = isVoice ? voiceOrTopicId : (voice || userProfile?.preferred_voice || 'shimmer');
    
    const track = TOPICS.find(t => t.id === trackId) || NEUTRAL_TOPIC;
    setLiveTopicWithVoice({ id: track.id, title: track.title, voice: selectedVoice });
    setLiveTrackId(trackId);
    setIsLiveMode(true);
  };

  // Show live mode
  if (isLiveMode && liveTopicWithVoice) {
    return (
      <LiveChat
        topicId={liveTopicWithVoice.id}
        topicTitle={liveTopicWithVoice.title}
        voiceId={liveTopicWithVoice.voice}
        category={liveTopicWithVoice.id as 'mental_health' | 'life_coaching' | 'business' | 'relationships'}
        onClose={() => {
          setIsLiveMode(false);
          setLiveTopicWithVoice(null);
          refreshUsage();
        }}
      />
    );
  }

  if (selectedTopic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background p-4">
        <ChatInterface
          topic={TOPICS.find(t => t.id === selectedTopic)?.title || selectedTopic}
          conversationId={selectedConversationId || undefined}
          onBack={handleBackToDashboard}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-lg font-semibold">SYMIA</h1>
          <div className="flex gap-2">
            {role === 'admin' && (
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => navigate('/admin')}
                className="hidden md:flex border-primary/50 hover:bg-primary/10"
                title="Admin Dashboard"
              >
                <Shield className="w-5 h-5 text-primary" />
              </Button>
            )}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/settings')}
              className="hidden md:flex"
            >
              <Settings className="w-5 h-5" />
            </Button>
            <Button variant="outline" onClick={signOut} className="gap-2">
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Dynamic Usage Banner - Show for users with limited quota */}
      {subscriptionTier !== 'premium' && limits && (
        <div className={`border-b ${
          remainingChats < 3 && remainingChats > 0
            ? 'bg-gradient-to-r from-red-500/20 via-orange-500/20 to-amber-500/20 border-red-500/30'
            : remainingChats === 0
              ? 'bg-gradient-to-r from-red-600/30 via-red-500/20 to-red-400/20 border-red-600/40'
              : 'bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-red-500/20 border-amber-500/30'
        }`}>
          <div className="max-w-6xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                  remainingChats < 3 && remainingChats > 0
                    ? 'bg-orange-500/30 animate-pulse'
                    : remainingChats === 0
                      ? 'bg-red-500/30'
                      : 'bg-amber-500/20'
                }`}>
                  <Sparkles className={`w-5 h-5 ${
                    remainingChats < 3 && remainingChats > 0
                      ? 'text-orange-600'
                      : remainingChats === 0
                        ? 'text-red-600'
                        : 'text-amber-600'
                  }`} />
                </div>
                <div>
                  <h3 className="font-bold text-foreground">
                    {subscriptionTier === 'free' ? 'Free Plan' : 'Standard Plan'}
                  </h3>
                  <div className="text-sm text-muted-foreground space-y-0.5">
                    {/* Text Chat Count */}
                    <p className={remainingChats < 3 ? 'font-semibold' : ''}>
                      {remainingChats === 0 
                        ? "⚠️ No conversations remaining this month"
                        : remainingChats === 1
                          ? `⚠️ Only ${remainingChats} conversation remaining this month`
                          : remainingChats < 3
                            ? `⚠️ Only ${remainingChats} conversations remaining this month`
                            : `${remainingChats} conversation${remainingChats !== 1 ? 's' : ''} remaining this month`
                      }
                    </p>
                    
                    {/* Live Session Count for Standard Users */}
                    {subscriptionTier === 'standard' && remainingLiveSessions !== Infinity && (
                      <p className={remainingLiveSessions < 3 ? 'font-semibold' : ''}>
                        {remainingLiveSessions === 0
                          ? "⚠️ No live sessions remaining"
                          : remainingLiveSessions === 1
                            ? `⚠️ Only ${remainingLiveSessions} live session remaining`
                            : remainingLiveSessions < 3
                              ? `⚠️ Only ${remainingLiveSessions} live sessions remaining`
                              : `${remainingLiveSessions} live session${remainingLiveSessions !== 1 ? 's' : ''} remaining`
                        }
                      </p>
                    )}
                  </div>
                </div>
              </div>
              <Button 
                onClick={() => navigate('/pricing')}
                className={`shadow-lg hover:shadow-xl transition-all ${
                  remainingChats === 0
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-gradient-to-r from-primary to-secondary'
                }`}
              >
                {remainingChats === 0 ? 'Upgrade Now' : 'Upgrade for Unlimited'}
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto px-4 py-8 pb-24 md:pb-8">

        {/* Hero with Avatar */}
        <DashboardHero 
          userName={userProfile.full_name}
          avatarUrl={avatarConfig?.avatar_url || null}
          onStartLiveCall={handleGoLive}
          onCustomizeAvatar={() => navigate('/settings?tab=avatar')}
          isLiveLocked={!canUseLiveSession}
          onUpgrade={() => navigate('/pricing')}
        />

        {/* Topic Selection */}
        <section className="mt-12">
          <h2 className="text-2xl font-bold mb-2">Choose Your Mode</h2>
          <p className="text-muted-foreground mb-6">
            Select a coaching area to begin
          </p>
          <div className="grid sm:grid-cols-2 gap-4">
            {TOPICS.map((topic) => (
              <TopicCard
                key={topic.id}
                title={topic.title}
                description={topic.description}
                icon={topic.icon}
                onClick={() => handleTopicClick(topic.id)}
                onGoLive={() => handleGoLive(topic.id)}
                isTextChatLocked={!canUseTextChat}
                isLiveLocked={!canUseLiveSession}
                onUpgrade={() => navigate('/pricing')}
              />
            ))}
          </div>
        </section>

        {/* Recent Conversations */}
        {user && (
          <section className="mt-12">
            <h2 className="text-2xl font-bold mb-4">Recent Conversations</h2>
            <RecentConversations 
              userId={user.id} 
              onSelectConversation={handleSelectRecentConversation}
            />
          </section>
        )}

        <ConversationDialog
          open={showDialog}
          onOpenChange={setShowDialog}
          topic={TOPICS.find(t => t.id === pendingTopic)?.title || ""}
          conversationCount={existingConversations.length}
          onContinue={handleContinueConversation}
          onStartNew={handleStartNewConversation}
        />

        {/* Welcome Dialog */}
        <Dialog open={showWelcome} onOpenChange={setShowWelcome}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Welcome to SYMIA! 🎉</DialogTitle>
            </DialogHeader>
            <p className="text-muted-foreground">
              Your account is ready. Choose a wellness mode below to start your first session.
            </p>
            {isFreeUser && (
              <p className="text-sm text-primary font-medium">
                💡 You have 1 free conversation included with your account.
              </p>
            )}
            <Button onClick={() => setShowWelcome(false)}>
              Get Started
            </Button>
          </DialogContent>
        </Dialog>

        {/* Upgrade Prompt */}
        <UpgradePrompt
          open={showUpgradePrompt}
          onOpenChange={setShowUpgradePrompt}
          feature={upgradeFeature}
          currentTier={subscriptionTier || 'free'}
        />
      </div>

      {/* Mobile Bottom Navigation */}
      <BottomNav />
      <LiveAvatarDebugPanel />
    </div>
  );
}