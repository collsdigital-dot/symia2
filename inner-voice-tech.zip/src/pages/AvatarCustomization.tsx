import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/features/auth/hooks';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ArrowLeft, Check, Play, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { fetchLiveAvatars, fetchLiveVoices, isUsingFallbackAvatars } from '@/features/liveavatar';

interface LiveAvatar {
  avatar_id: string;
  name: string;
  preview_url?: string;
  thumbnail_url?: string;
  gender?: string;
  supported_languages?: string[];
}

interface LiveVoice {
  voice_id: string;
  name: string;
  language?: string;
  language_code?: string;
  gender?: string;
  preview_audio_url?: string;
  accent?: string;
}

export default function AvatarCustomization() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [avatars, setAvatars] = useState<LiveAvatar[]>([]);
  const [voices, setVoices] = useState<LiveVoice[]>([]);
  const [selectedAvatar, setSelectedAvatar] = useState<string>('');
  const [selectedVoice, setSelectedVoice] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [showFallbackWarning, setShowFallbackWarning] = useState(false);
  
  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    loadOptions();
  }, [user]);
  
  const loadOptions = async () => {
    try {
      setLoading(true);
      setLoadError(null);
      
      console.log('[AvatarCustomization] Fetching LiveAvatar options...');
      
      // Fetch avatars using our service (includes fallback support)
      const avatarOptions = await fetchLiveAvatars();
      const voiceOptions = await fetchLiveVoices();
      
      console.log('[AvatarCustomization] Fetched avatars:', avatarOptions.length);
      console.log('[AvatarCustomization] Fetched voices:', voiceOptions.length);
      
      // Map to page format
      const avatarResults = avatarOptions.map((a) => ({
        avatar_id: a.id,
        name: a.name,
        preview_url: a.thumbnail,
        thumbnail_url: a.thumbnail,
        gender: a.gender,
        supported_languages: a.supportedLanguages || []
      }));
      
      const voiceResults = voiceOptions.map((v) => ({
        voice_id: v.id,
        name: v.name,
        language: v.language,
        language_code: v.language,
        gender: v.gender,
        preview_audio_url: undefined, // LiveAvatar API doesn't provide preview URLs
        accent: v.description
      }));
      
      setAvatars(avatarResults);
      setVoices(voiceResults);
      
      // Check if we're using fallback avatars
      setShowFallbackWarning(isUsingFallbackAvatars());
      
      if (avatarResults.length === 0) {
        setLoadError('No avatars available. Please contact support.');
        toast.error('No avatars available');
      }
      if (voiceResults.length === 0) {
        setLoadError('No voices available. Please contact support.');
        toast.error('No voices available');
      }
      
      // Load user's existing selection
      const { data: profileData } = await supabase
        .from('user_profiles')
        .select('liveavatar_id, liveavatar_voice_id')
        .eq('user_id', user?.id)
        .single();
      
      if (profileData) {
        setSelectedAvatar(profileData.liveavatar_id || '');
        setSelectedVoice(profileData.liveavatar_voice_id || '');
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Failed to load avatar options';
      console.error('[AvatarCustomization] Error:', error);
      setLoadError(errorMsg);
      toast.error(errorMsg);
    } finally {
      setLoading(false);
    }
  };
  
  const handleSave = async () => {
    if (!selectedAvatar || !selectedVoice) {
      toast.error('Please select both an avatar and a voice');
      return;
    }
    
    try {
      setSaving(true);
      
      // Find the selected avatar and voice data
      const selectedAvatarData = avatars.find(a => a.avatar_id === selectedAvatar);
      const selectedVoiceData = voices.find(v => v.voice_id === selectedVoice);
      
      console.log('[AvatarCustomization] Saving avatar:', {
        avatar_id: selectedAvatar,
        avatar_name: selectedAvatarData?.name,
        voice_id: selectedVoice,
        voice_name: selectedVoiceData?.name
      });
      
      // Update user_profiles
      const { error: profileError } = await supabase
        .from('user_profiles')
        .update({
          avatar_provider: 'liveavatar',
          liveavatar_id: selectedAvatar,
          liveavatar_voice_id: selectedVoice,
        })
        .eq('user_id', user?.id);
      
      if (profileError) throw profileError;
      
      // Update user_avatars with the thumbnail and metadata
      const { error: avatarError } = await supabase
        .from('user_avatars')
        .upsert({
          user_id: user?.id,
          avatar_type: 'liveavatar',
          avatar_url: selectedAvatarData?.preview_url || selectedAvatarData?.thumbnail_url || null,
          status: 'customized',
          config_json: {
            avatar_id: selectedAvatar,
            avatar_name: selectedAvatarData?.name,
            voice_id: selectedVoice,
            voice_name: selectedVoiceData?.name,
            gender: selectedAvatarData?.gender,
            language: selectedVoiceData?.language_code || selectedVoiceData?.language
          }
        }, {
          onConflict: 'user_id'
        });
      
      if (avatarError) throw avatarError;
      
      toast.success('Avatar customization saved!');
      navigate('/dashboard?refresh=1');
    } catch (error) {
      console.error('Failed to save:', error);
      toast.error('Failed to save customization');
    } finally {
      setSaving(false);
    }
  };
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background p-8">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-8 w-64 mb-8" />
          <div className="text-muted-foreground mb-4">Fetching LiveAvatar options from API...</div>
          <div className="grid grid-cols-3 gap-4 mb-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </div>
    );
  }
  
  if (loadError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background p-8">
        <div className="max-w-6xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <Card className="p-8 text-center space-y-4">
            <AlertCircle className="w-16 h-16 text-destructive mx-auto" />
            <h2 className="text-2xl font-bold">Unable to Load Options</h2>
            <p className="text-muted-foreground">{loadError}</p>
            <Button onClick={loadOptions}>Try Again</Button>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
            Customize Your AI Companion
          </h1>
          <p className="text-muted-foreground">
            Choose how your AI wellness companion looks and sounds
          </p>
        </div>

        {/* Fallback Warning */}
        {showFallbackWarning && (
          <Alert className="mb-8 border-orange-500/50 bg-orange-500/10">
            <AlertCircle className="h-4 w-4 text-orange-500" />
            <AlertTitle>Using Curated Avatar Selection</AlertTitle>
            <AlertDescription>
              We're showing you a curated selection of high-quality avatars. For access to the full avatar library, please ensure your LiveAvatar API key has proper permissions or contact support.
            </AlertDescription>
          </Alert>
        )}

        {/* Avatar Selection */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">Choose Your Avatar</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {avatars.map((avatar) => (
              <motion.div
                key={avatar.avatar_id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card
                  onClick={() => setSelectedAvatar(avatar.avatar_id)}
                  className={`cursor-pointer transition-all p-4 ${
                    selectedAvatar === avatar.avatar_id
                      ? 'border-2 border-primary shadow-glow'
                      : 'border border-border hover:border-primary/50'
                  }`}
                >
                  <div className="relative aspect-square rounded-lg overflow-hidden bg-muted mb-3">
                    {avatar.preview_url || avatar.thumbnail_url ? (
                      <img
                        src={avatar.preview_url || avatar.thumbnail_url}
                        alt={avatar.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          // Fallback if image fails to load
                          (e.target as HTMLImageElement).style.display = 'none';
                          (e.target as HTMLImageElement).parentElement!.innerHTML = `
                            <div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10">
                              <span class="text-4xl">👤</span>
                            </div>
                          `;
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10">
                        <span className="text-4xl">👤</span>
                      </div>
                    )}
                    {selectedAvatar === avatar.avatar_id && (
                      <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
                        <Check className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                  <p className="font-semibold text-sm text-center truncate">
                    {avatar.name}
                  </p>
                  {avatar.gender && (
                    <p className="text-xs text-muted-foreground text-center">
                      {avatar.gender}
                    </p>
                  )}
                  {avatar.supported_languages && avatar.supported_languages.length > 0 && (
                    <p className="text-xs text-muted-foreground text-center truncate">
                      {avatar.supported_languages.slice(0, 2).join(', ')}
                      {avatar.supported_languages.length > 2 && ' +more'}
                    </p>
                  )}
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Voice Selection */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">Choose Your Voice</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {voices.map((voice) => (
              <motion.div
                key={voice.voice_id}
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
              >
                <Card
                  onClick={() => setSelectedVoice(voice.voice_id)}
                  className={`cursor-pointer transition-all p-4 ${
                    selectedVoice === voice.voice_id
                      ? 'border-2 border-primary shadow-glow'
                      : 'border border-border hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-semibold">{voice.name}</p>
                      <div className="flex gap-2 text-xs text-muted-foreground mt-1 flex-wrap">
                        {(voice.language || voice.language_code) && (
                          <span>{voice.language || voice.language_code}</span>
                        )}
                        {voice.gender && <span>• {voice.gender}</span>}
                        {voice.accent && <span>• {voice.accent}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {selectedVoice === voice.voice_id && (
                        <div className="bg-primary text-primary-foreground rounded-full p-2">
                          <Check className="w-4 h-4" />
                        </div>
                      )}
                      {voice.preview_audio_url && (
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            const audio = new Audio(voice.preview_audio_url);
                            audio.play().catch(err => {
                              console.error('Audio playback failed:', err);
                              toast.error('Unable to play preview');
                            });
                          }}
                        >
                          <Play className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Save Button */}
        <div className="flex justify-center pb-8">
          <Button
            onClick={handleSave}
            disabled={!selectedAvatar || !selectedVoice || saving}
            size="lg"
            className="px-12"
          >
            {saving ? 'Saving...' : 'Save & Continue'}
          </Button>
        </div>
      </div>
    </div>
  );
}
