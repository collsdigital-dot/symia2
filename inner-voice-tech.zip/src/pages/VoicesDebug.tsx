import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowLeft, RefreshCw, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useLiveVoices } from "@/features/liveavatar";
import { toast } from "sonner";

export default function VoicesDebug() {
  const navigate = useNavigate();
  const { voices, loading, error, refresh } = useLiveVoices();

  const copyVoiceId = (voiceId: string) => {
    navigator.clipboard.writeText(voiceId);
    toast.success('Voice ID copied to clipboard');
  };

  return (
    <div className="min-h-screen p-8 bg-background">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">LiveAvatar Voices</h1>
            <p className="text-muted-foreground mt-1">
              Available voices from LiveAvatar API - use these voice IDs in your configuration
            </p>
          </div>
          <Button onClick={refresh} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        <Card className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Available Voices ({voices.length})</h2>
              {loading && (
                <Badge variant="secondary">
                  <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                  Loading...
                </Badge>
              )}
            </div>

            {error && (
              <div className="p-4 bg-destructive/10 border border-destructive rounded-lg">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <ScrollArea className="h-[600px]">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {voices.map((voice) => (
                  <Card 
                    key={voice.id} 
                    className="p-4 hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => copyVoiceId(voice.id)}
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-lg truncate">{voice.name}</h3>
                          <p className="text-sm text-muted-foreground">{voice.language}</p>
                        </div>
                        <Badge variant={voice.gender === 'female' ? 'default' : 'secondary'}>
                          {voice.gender}
                        </Badge>
                      </div>

                      {voice.description && (
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {voice.description}
                        </p>
                      )}

                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Voice ID:</span>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-6 px-2"
                            onClick={(e) => {
                              e.stopPropagation();
                              copyVoiceId(voice.id);
                            }}
                          >
                            Copy
                          </Button>
                        </div>
                        <code className="block text-xs bg-muted p-2 rounded break-all">
                          {voice.id}
                        </code>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {voices.length === 0 && !loading && !error && (
                <div className="text-center py-12 text-muted-foreground">
                  <p>No voices available. Click "Refresh" to fetch voices from the API.</p>
                </div>
              )}
            </ScrollArea>
          </div>
        </Card>

        <Card className="p-6 bg-muted/50">
          <h3 className="font-semibold mb-3">How to Use These Voice IDs</h3>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>1. Click "Test Voices API" in the debug console to see available voices</p>
            <p>2. Copy the voice_id from the list above</p>
            <p>3. Update your configuration files with the correct voice IDs</p>
            <p>4. Use these IDs when creating LiveAvatar sessions</p>
          </div>
        </Card>
      </div>
    </div>
  );
}
