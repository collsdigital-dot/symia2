import { useState, useEffect } from "react";
import { useAuth } from "@/features/auth/hooks";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ProfileSettings } from "@/features/settings/components/ProfileSettings";
import { AvatarSettings } from "@/features/settings/components/AvatarSettings";
import { AccountSettings } from "@/features/settings/components/AccountSettings";
import { PrivacySettings } from "@/features/settings/components/PrivacySettings";
import { BackgroundSettings } from "@/features/settings/components/BackgroundSettings";
import { SubscriptionManager } from "@/features/subscription/components/SubscriptionManager";
import { UsageDisplay } from "@/features/subscription/components/UsageDisplay";
import { BillingHistory } from "@/features/subscription/components/BillingHistory";

export default function Settings() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const activeTab = searchParams.get('tab') || 'profile';
  const [userProfile, setUserProfile] = useState<any>(null);
  const [avatarConfig, setAvatarConfig] = useState<any>(null);
  const [usageLimits, setUsageLimits] = useState<any>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
      return;
    }

    if (user) {
      loadProfile();
      loadAvatarConfig();
      loadUsageLimits();
    }
  }, [user, loading]);

  const loadProfile = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("user_profiles")
      .select("*")
      .eq("user_id", user.id)
      .single();
    setUserProfile(data);
  };

  const loadAvatarConfig = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("user_avatars")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle();
    setAvatarConfig(data);
  };

  const handleProfileUpdate = () => {
    loadProfile();
  };

  const handleAvatarUpdate = () => {
    loadProfile();
    loadAvatarConfig();
  };

  const loadUsageLimits = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("usage_limits")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle();
    setUsageLimits(data);
  };

  if (loading || !userProfile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      <div className="max-w-4xl mx-auto px-4 py-8 pb-24 md:pb-8">
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate("/dashboard")}
            className="hover:bg-primary/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Settings
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Manage your profile, preferences, and account
            </p>
          </div>
        </div>

        <Tabs defaultValue={activeTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 gap-1">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="subscription">Subscription</TabsTrigger>
            <TabsTrigger value="avatar">Avatar</TabsTrigger>
            <TabsTrigger value="background">Background</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="privacy">Privacy</TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <ProfileSettings 
              profile={userProfile} 
              onUpdate={handleProfileUpdate} 
            />
          </TabsContent>

          <TabsContent value="subscription">
            <div className="space-y-6">
              <SubscriptionManager 
                usageLimits={usageLimits}
                onRefresh={loadUsageLimits}
              />
              <UsageDisplay usageLimits={usageLimits} />
              <BillingHistory />
            </div>
          </TabsContent>

          <TabsContent value="avatar">
            <AvatarSettings
              avatarConfig={avatarConfig}
              profile={userProfile}
              onUpdate={handleAvatarUpdate}
            />
          </TabsContent>

          <TabsContent value="background">
            <BackgroundSettings
              profile={userProfile}
              onUpdate={handleProfileUpdate}
            />
          </TabsContent>

          <TabsContent value="account">
            <AccountSettings user={user} />
          </TabsContent>

          <TabsContent value="privacy">
            <PrivacySettings userId={user.id} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
