import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/features/auth/hooks";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { WelcomeStep } from "@/features/funnel/components/WelcomeStep";
import { QuizStep } from "@/features/funnel/components/QuizStep";
import { RegistrationStep } from "@/features/funnel/components/RegistrationStep";
import { AvatarLanguageStep } from "@/features/funnel/components/AvatarLanguageStep";
import { TrialStep } from "@/features/funnel/components/TrialStep";
import { PaymentStep } from "@/features/funnel/components/PaymentStep";

export type FunnelStepType = 'welcome' | 'quiz' | 'registration' | 'avatar-language' | 'trial' | 'payment';

export interface FunnelState {
  step: FunnelStepType;
  quizAnswers: Record<string, any>;
  selectedCategory: 'mental_health' | 'life_coaching' | 'business' | 'relationships' | null;
  email: string;
  selectedAvatar: string;
  selectedLanguage: string;
  trialComplete: boolean;
  paymentComplete: boolean;
  purchasedMinutes: number;
}

export default function SimiaFunnel() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  
  const [state, setState] = useState<FunnelState>({
    step: 'welcome',
    quizAnswers: {},
    selectedCategory: null,
    email: '',
    selectedAvatar: '',
    selectedLanguage: 'en-US',
    trialComplete: false,
    paymentComplete: false,
    purchasedMinutes: 0,
  });

  // Redirect authenticated users to dashboard (unless they're in the funnel)
  useEffect(() => {
    const checkAndRedirect = async () => {
      const inProgress = sessionStorage.getItem('funnelInProgress');
      
      if (!loading && user && !inProgress) {
        // Check if user has a profile before redirecting
        const { data: profile } = await supabase
          .from('user_profiles')
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();

        if (profile) {
          navigate("/dashboard");
        }
      }
    };

    checkAndRedirect();
  }, [user, loading, navigate]);

  // Handle OAuth return - resume funnel after social auth with retry logic
  useEffect(() => {
    const handleOAuthReturn = async () => {
      const params = new URLSearchParams(window.location.search);
      if (params.get('resumeFunnel') === 'true' && user) {
        sessionStorage.setItem('funnelInProgress', 'true');
        
        // Create profile for OAuth users with retry
        let attempts = 0;
        const maxAttempts = 3;
        
        while (attempts < maxAttempts) {
          try {
            const { data: existingProfile } = await supabase
              .from('user_profiles')
              .select('id')
              .eq('user_id', user.id)
              .maybeSingle();

            if (!existingProfile) {
              const { error } = await supabase
                .from('user_profiles')
                .insert({
                  user_id: user.id,
                  full_name: user.email?.split('@')[0] || user.user_metadata?.full_name || 'User',
                  preferred_voice: 'shimmer',
                  heygen_avatar_id: 'Angela-inblackskirt-20220820',
                  avatar_provider: 'heygen',
                });
              
              if (error && !error.message.includes('duplicate')) {
                throw error;
              }
            }
            break; // Success, exit loop
          } catch (error) {
            attempts++;
            console.error(`Profile creation attempt ${attempts} failed:`, error);
            if (attempts >= maxAttempts) {
              console.error('Failed to create profile after max attempts');
            }
            await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1s before retry
          }
        }

        setState(prev => ({ ...prev, step: 'avatar-language' }));
        // Clean up URL
        window.history.replaceState({}, '', '/');
      }
    };

    handleOAuthReturn();
  }, [user]);

  const handleStepComplete = (updates: Partial<FunnelState>) => {
    // Set flag when user moves to trial (just registered)
    if (updates.step === 'trial') {
      sessionStorage.setItem('funnelInProgress', 'true');
    }
    
    // Clear flag and navigate when payment completes
    if (updates.paymentComplete) {
      sessionStorage.removeItem('funnelInProgress');
      navigate("/dashboard?firstVisit=true");
    }
    
    setState(prev => ({ ...prev, ...updates }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <AnimatePresence mode="wait">
          {state.step === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <WelcomeStep onComplete={() => handleStepComplete({ step: 'quiz' })} />
            </motion.div>
          )}

          {state.step === 'quiz' && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <QuizStep
                onComplete={(answers, category) =>
                  handleStepComplete({
                    step: 'registration',
                    quizAnswers: answers,
                    selectedCategory: category,
                  })
                }
              />
            </motion.div>
          )}

          {state.step === 'registration' && (
            <motion.div
              key="registration"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <RegistrationStep
                category={state.selectedCategory}
                onComplete={(email) => handleStepComplete({ step: 'avatar-language', email })}
              />
            </motion.div>
          )}

          {state.step === 'avatar-language' && (
            <motion.div
              key="avatar-language"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <AvatarLanguageStep
                onComplete={(avatar, language) =>
                  handleStepComplete({
                    step: 'trial',
                    selectedAvatar: avatar,
                    selectedLanguage: language,
                  })
                }
              />
            </motion.div>
          )}

          {state.step === 'trial' && (
            <motion.div
              key="trial"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <TrialStep
                category={state.selectedCategory!}
                avatarId={state.selectedAvatar}
                language={state.selectedLanguage}
                onComplete={() => handleStepComplete({ step: 'payment', trialComplete: true })}
              />
            </motion.div>
          )}

          {state.step === 'payment' && (
            <motion.div
              key="payment"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <PaymentStep
                onComplete={(minutes) => {
                  handleStepComplete({ paymentComplete: true, purchasedMinutes: minutes });
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
