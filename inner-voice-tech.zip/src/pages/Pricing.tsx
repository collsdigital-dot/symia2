import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/features/auth/hooks";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Confetti } from "@/components/visual/Confetti";
import { useState } from "react";
import { motion } from "framer-motion";

export default function Pricing() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const [showConfetti, setShowConfetti] = useState(false);

  const handleUpgrade = async (tier: string, price: number, minutes: number) => {
    if (!user) {
      toast({
        title: "Please sign in",
        description: "You need to be signed in to purchase a plan.",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    try {
      const tierMapping: Record<string, "free" | "standard" | "premium"> = {
        basic: "standard",
        recommended: "standard",
        premium: "premium"
      };

      const dbTier = tierMapping[tier] || "standard";

      // Log subscription event
      const { error: logError } = await supabase
        .from('subscription_events')
        .insert({
          user_id: user.id,
          tier: dbTier,
          duration_minutes: minutes,
          payment_status: 'success',
          amount_usd: price,
          payment_method: 'test'
        });

      if (logError) console.error('Failed to log subscription:', logError);

      // Update user limits
      const { error } = await supabase
        .from('usage_limits')
        .update({
          subscription_tier: dbTier,
          live_demos_limit: minutes
        })
        .eq('user_id', user.id);

      if (error) throw error;

      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 3000);

      toast({
        title: "Payment Successful!",
        description: `You now have ${minutes} minutes of AI interaction.`,
      });

      setTimeout(() => navigate('/dashboard'), 1500);
    } catch (error: any) {
      console.error('Payment error:', error);
      toast({
        title: "Payment Failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    }
  };

  const plans = [
    {
      name: "Basic",
      tier: "basic",
      price: "$15",
      minutes: 15,
      features: [
        "15 minutes of AI interaction per month",
        "Access to all 4 wellness categories",
        "Text-based chat support",
        "Progress tracking dashboard",
        "Email support"
      ]
    },
    {
      name: "Standard",
      tier: "recommended",
      price: "$30",
      minutes: 30,
      popular: true,
      features: [
        "30 minutes of AI interaction per month",
        "Everything in Basic, plus:",
        "Priority AI responses",
        "Live video avatar sessions",
        "Advanced analytics & insights",
        "Goal setting & tracking tools",
        "Priority email support"
      ]
    },
    {
      name: "Premium",
      tier: "premium",
      price: "$60",
      minutes: 60,
      features: [
        "60 minutes of AI interaction per month",
        "Everything in Standard, plus:",
        "Unlimited category access",
        "Custom avatar personalization",
        "Real-time voice & video",
        "Dedicated wellness coach",
        "24/7 priority support",
        "Exclusive wellness content"
      ]
    }
  ];

  const gradients = {
    basic: "from-[#c4b5fd] to-[#a78bfa]",
    recommended: "from-[#f9a8d4] to-[#f472b6]",
    premium: "from-[#5eead4] to-[#0ea5e9]"
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#ffffff_0%,#faf5ff_50%,#ede9fe_100%)] p-4">
      <Confetti show={showConfetti} />
      <div className="max-w-6xl mx-auto py-12">
        <div className="text-center mb-8 p-6 bg-primary/5 rounded-2xl border-2 border-primary/20">
          <h2 className="text-2xl font-semibold text-foreground mb-2">
            Your free AI wellness session has ended
          </h2>
          <p className="text-lg text-muted-foreground">
            Continue your journey and unlock full access to personalized support
          </p>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl text-muted-foreground">
            Select the plan that fits your wellness journey
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.tier}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.4 }}
              whileHover={{ y: -6 }}
            >
              <Card
                className={`p-8 relative transition-all duration-300
                  rounded-[20px] overflow-hidden
                  bg-gradient-to-br ${gradients[plan.tier as keyof typeof gradients]}
                  hover:shadow-[0_20px_50px_rgba(0,0,0,0.15)]
                  ${plan.popular ? 'border-2 border-white/40 shadow-xl' : 'border border-white/20'}`}
              >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white text-foreground">
                  Most Popular
                </Badge>
              )}

              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="text-5xl font-bold text-white mb-2">
                  {plan.price}
                </div>
                <p className="text-white/90">
                  {plan.minutes} minutes
                </p>
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-white shrink-0 mt-0.5" />
                    <span className="text-sm text-white/90">{feature}</span>
                  </li>
                ))}
              </ul>

              <motion.div
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  onClick={() => handleUpgrade(plan.tier, parseInt(plan.price.replace('$', '')), plan.minutes)}
                  className="w-full h-12 bg-white text-foreground hover:bg-white/90"
                >
                  <motion.span
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.2 }}
                  >
                    Choose {plan.name}
                  </motion.span>
                </Button>
              </motion.div>
            </Card>
          </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="text-muted-foreground"
          >
            Skip for now →
          </Button>
        </div>
      </div>
    </div>
  );
}
