import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/features/auth/hooks';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { MessageSquare, Video, Calendar, Clock, Loader2, ArrowLeft, User } from 'lucide-react';
import { LiveSessionDialog } from '@/features/dashboard/components/LiveSessionDialog';
import { BottomNav } from '@/components/ui/BottomNav';
import { ConversationActions } from '@/components/conversations/ConversationActions';
import { useInfiniteQuery } from '@tanstack/react-query';
import { useInView } from 'react-intersection-observer';
import { toast } from 'sonner';

interface Conversation {
  id: string;
  topic: string;
  type: 'text' | 'live';
  created_at: string;
  last_message?: string;
  duration?: number;
}

export default function Conversations() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'all' | 'text' | 'live'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [selectedLiveSession, setSelectedLiveSession] = useState<string | null>(null);
  const ITEMS_PER_PAGE = 20;

  const { ref: loadMoreRef, inView } = useInView();

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    loadAvatar();
  }, [user]);

  const loadAvatar = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_avatars')
      .select('avatar_url')
      .eq('user_id', user.id)
      .single();

    if (data?.avatar_url) {
      setAvatarUrl(data.avatar_url);
    }
  };

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
  } = useInfiniteQuery({
    queryKey: ['all-conversations', user?.id, filter, searchQuery],
    queryFn: async ({ pageParam = 0 }) => {
      if (!user) return [];
      
      const from = pageParam * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;

      let textConversations: Conversation[] = [];
      let liveSessions: Conversation[] = [];

      if (filter === 'all' || filter === 'text') {
        const { data: textData } = await supabase
          .from('chat_conversations')
          .select(`
            id,
            topic,
            created_at,
            chat_messages(content)
          `)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .range(from, to);

        if (textData) {
          textConversations = textData.map(conv => ({
            id: conv.id,
            topic: conv.topic,
            type: 'text' as const,
            created_at: conv.created_at,
            last_message: (conv.chat_messages as any)?.[0]?.content || '',
          }));
        }
      }

      if (filter === 'all' || filter === 'live') {
        const { data: liveData } = await supabase
          .from('live_sessions')
          .select('id, track_title, started_at, seconds_used')
          .eq('user_id', user.id)
          .order('started_at', { ascending: false })
          .range(from, to);

        if (liveData) {
          liveSessions = liveData.map(session => ({
            id: session.id,
            topic: session.track_title,
            type: 'live' as const,
            created_at: session.started_at,
            duration: session.seconds_used || 0,
          }));
        }
      }

      return [...textConversations, ...liveSessions]
        .filter(conv => {
          if (!searchQuery) return true;
          return conv.topic.toLowerCase().includes(searchQuery.toLowerCase());
        })
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    },
    getNextPageParam: (lastPage, allPages) => {
      return lastPage.length === ITEMS_PER_PAGE ? allPages.length : undefined;
    },
    enabled: !!user,
    initialPageParam: 0,
  });

  useEffect(() => {
    if (inView && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [inView, hasNextPage, isFetchingNextPage, fetchNextPage]);

  const conversations = data?.pages.flat() || [];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

    if (diffInDays === 0) return 'Today';
    if (diffInDays === 1) return 'Yesterday';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    return date.toLocaleDateString();
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleConversationClick = (conversation: Conversation) => {
    if (conversation.type === 'live') {
      setSelectedLiveSession(conversation.id);
    } else {
      navigate(`/dashboard?conversation=${conversation.id}&topic=${encodeURIComponent(conversation.topic)}`);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Sougen-style Full-scene Avatar Sidebar */}
      <aside className="hidden lg:block fixed left-0 top-0 bottom-0 w-80 overflow-hidden">
        {/* Full-bleed avatar background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 flex items-center justify-center">
          {avatarUrl ? (
            <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
          ) : (
            <User className="w-32 h-32 text-primary/20" />
          )}
        </div>
        
        {/* Atmospheric overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-secondary/10 pointer-events-none" />
        <div className="absolute inset-0 backdrop-blur-[2px] pointer-events-none" />
        
        {/* Content overlay */}
        <div className="relative z-10 h-full flex flex-col p-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="mb-6 self-start bg-background/80 backdrop-blur-sm"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <div className="flex-1" />
          
          <div className="bg-background/80 backdrop-blur-sm rounded-xl p-4 border border-primary/20">
            <p className="text-center text-sm text-muted-foreground">
              Your AI companion is ready to chat
            </p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-80 min-h-screen pb-20 lg:pb-8">
        <div className="max-w-4xl mx-auto p-6">
          <header className="mb-8">
            <div className="flex items-center gap-4 mb-4 lg:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/dashboard')}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-3xl font-bold">Conversations</h1>
            </div>
            <h1 className="hidden lg:block text-3xl font-bold mb-2">All Conversations</h1>
            <p className="text-muted-foreground">Your complete conversation history</p>
          </header>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <Select value={filter} onValueChange={(value: any) => setFilter(value)}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="text">Text Chat</SelectItem>
                <SelectItem value="live">Live Sessions</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Conversation List */}
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : conversations.length === 0 ? (
            <Card className="p-12 text-center">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No conversations yet</h3>
              <p className="text-muted-foreground mb-4">
                Start a conversation from your dashboard
              </p>
              <Button onClick={() => navigate('/dashboard')}>
                Go to Dashboard
              </Button>
            </Card>
          ) : (
            <div className="space-y-3">
              {conversations.map((conversation) => (
                <Card
                  key={conversation.id}
                  className="p-4 hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => handleConversationClick(conversation)}
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      {conversation.type === 'live' ? (
                        <Video className="w-5 h-5 text-primary" />
                      ) : (
                        <MessageSquare className="w-5 h-5 text-primary" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold mb-1 truncate">{conversation.topic}</h3>
                      {conversation.type === 'text' && conversation.last_message && (
                        <p className="text-sm text-muted-foreground truncate">
                          {conversation.last_message}
                        </p>
                      )}
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(conversation.created_at)}
                        </span>
                        {conversation.type === 'live' && conversation.duration !== undefined && (
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatDuration(conversation.duration)}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <ConversationActions
                      conversation={conversation}
                      onContinue={() => {
                        navigate(`/dashboard?conversation=${conversation.id}&topic=${encodeURIComponent(conversation.topic)}`);
                      }}
                      onStartLiveCall={() => {
                        navigate(`/dashboard?startLiveCall=true&topic=${encodeURIComponent(conversation.topic)}`);
                      }}
                      onStartVoiceChat={() => {
                        toast.info('Voice chat coming soon!');
                      }}
                    />
                  </div>
                </Card>
              ))}
            </div>
          )}

          {/* Infinite Scroll Trigger */}
          {hasNextPage && (
            <div ref={loadMoreRef} className="flex justify-center py-8">
              {isFetchingNextPage && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Loading more...</span>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      <BottomNav />

      {selectedLiveSession && (
        <LiveSessionDialog
          open={!!selectedLiveSession}
          sessionId={selectedLiveSession}
          onClose={() => setSelectedLiveSession(null)}
        />
      )}
    </div>
  );
}
