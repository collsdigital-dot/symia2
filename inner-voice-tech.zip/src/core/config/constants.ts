export const APP_CONFIG = {
  name: 'SYMIA',
  fullName: 'Inner Voice Tech',
  version: '2.0.0',
  environment: import.meta.env.MODE,
} as const;

// Operational roles (platform management)
export const ROLES = {
  ADMIN: 'admin',
  MODERATOR: 'moderator',
  USER: 'user',
} as const;

// Subscription tiers (customer access)
export const SUBSCRIPTION_TIERS = {
  FREE: 'free',
  STANDARD: 'standard',
  PREMIUM: 'premium',
} as const;

// Usage limits by tier
export const USAGE_LIMITS = {
  FREE: {
    TEXT_CHATS: 1,
    LIVE_DEMOS: 0,
  },
  STANDARD: {
    TEXT_CHATS: 10,
    LIVE_DEMOS: 5,
  },
  PREMIUM: {
    TEXT_CHATS: Infinity,
    LIVE_DEMOS: Infinity,
  },
} as const;

export const SESSION_LIMITS = {
  TRIAL_DURATION_SECONDS: 60,
  FREE_LIVE_DURATION_SECONDS: 0,
  PREMIUM_LIVE_DURATION_SECONDS: Infinity,
} as const;
