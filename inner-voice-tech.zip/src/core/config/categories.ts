// ============================================
// SINGLE SOURCE OF TRUTH FOR ALL CATEGORIES
// ============================================

import { Heart, Target, Briefcase, Users } from "lucide-react";

export type CategoryId = 'mental_health' | 'life_coaching' | 'business' | 'relationships';

export interface CategoryConfig {
  id: CategoryId;
  slug: string;
  title: string;
  shortName: string;
  description: string;
  icon: any;
  gradient: string;
  backgroundColor: string;
  backgroundImage: string;
  greeting: string;
  introMessage: string;
  features: string[];
  defaultAvatarId: string;
  systemPrompts: Record<string, string>;
  personalizationQuestions: QuestionSet;
}

export interface QuestionSet {
  questions: Array<{
    id: string;
    question: string;
    type: 'multiple_choice' | 'scale' | 'yes_no';
    options?: string[];
  }>;
}

// Complete category configurations
export const CATEGORIES: Record<CategoryId, CategoryConfig> = {
  mental_health: {
    id: 'mental_health',
    slug: 'mental-health',
    title: 'Mental Health Support',
    shortName: 'Mental Health',
    description: 'Professional mental wellness guidance with evidence-based techniques for managing stress, anxiety, and emotional well-being',
    icon: Heart,
    gradient: 'from-blue-500/20 to-purple-500/20',
    backgroundColor: 'from-pink-500 to-rose-500',
    backgroundImage: '/backgrounds/mental-health-office.jpg',
    greeting: "Hi, I'm here to support you. Let's take a moment to breathe together. What's been on your mind lately? Remember, this is a safe space just for you.",
    introMessage: "Hi, I'm your Mental Health Companion. I'm here to help you slow down, find peace, and regain balance. Let's take a moment to focus on your wellbeing together.",
    features: ['Confidential & Safe', '24/7 Available', 'Evidence-Based Support'],
    defaultAvatarId: 'Lina_Dress_Sitting_Side_public',
    systemPrompts: {
      'en-US': 'You are a compassionate mental health counselor. Keep responses warm, conversational, and under 3 sentences. Focus on being supportive and actionable.',
      'en-GB': 'You are a compassionate mental health counsellor. Keep responses warm, conversational, and under 3 sentences. Focus on being supportive and actionable.',
      'es': 'Eres un consejero de salud mental compasivo. Mantén las respuestas cálidas, conversacionales y de menos de 3 oraciones. Enfócate en ser comprensivo y práctico.',
      'fr': 'Vous êtes un conseiller en santé mentale compatissant. Gardez les réponses chaleureuses, conversationnelles et de moins de 3 phrases. Concentrez-vous sur être solidaire et pragmatique.',
      'de': 'Sie sind ein mitfühlender Berater für psychische Gesundheit. Halten Sie die Antworten warm, gesprächig und unter 3 Sätzen. Konzentrieren Sie sich darauf, unterstützend und handlungsorientiert zu sein.',
    },
    personalizationQuestions: {
      questions: [
        {
          id: 'reason',
          question: 'What brings you here today?',
          type: 'multiple_choice',
          options: ['Anxiety', 'Depression', 'Stress Management', 'General Wellness']
        },
        {
          id: 'mood',
          question: 'How would you describe your current mood?',
          type: 'scale'
        },
        {
          id: 'experience',
          question: 'Have you tried therapy or coaching before?',
          type: 'yes_no'
        },
        {
          id: 'time',
          question: 'What time of day do you feel most overwhelmed?',
          type: 'multiple_choice',
          options: ['Morning', 'Afternoon', 'Evening', 'Night']
        }
      ]
    }
  },

  life_coaching: {
    id: 'life_coaching',
    slug: 'life-coaching',
    title: 'Life Coaching',
    shortName: 'Life Coaching',
    description: 'Achieve your personal goals with personalized guidance on relationships, career growth, and life direction',
    icon: Target,
    gradient: 'from-orange-500/20 to-yellow-500/20',
    backgroundColor: 'from-purple-500 to-indigo-500',
    backgroundImage: '/backgrounds/life-coaching-office.jpg',
    greeting: "Welcome! I'm excited to be part of your journey. What dreams or goals are you working on right now? Let's explore them together and create a path forward.",
    introMessage: "Welcome! I'm your AI Life Coach. Together, we'll explore your dreams, build confidence, and take the steps toward the life you want to create.",
    features: ['Goal Setting & Achievement', 'Personal Growth', 'Accountability Partner'],
    defaultAvatarId: 'Sophia_Modern_Sitting_public',
    systemPrompts: {
      'en-US': 'You are an inspiring life coach. Keep responses energetic, motivational, and under 3 sentences. Focus on empowerment and actionable steps.',
      'es': 'Eres un entrenador de vida inspirador. Mantén las respuestas enérgicas, motivacionales y de menos de 3 oraciones. Enfócate en el empoderamiento y pasos prácticos.',
      'fr': 'Vous êtes un coach de vie inspirant. Gardez les réponses énergiques, motivantes et de moins de 3 phrases. Concentrez-vous sur l\'autonomisation et les étapes concrètes.',
    },
    personalizationQuestions: {
      questions: [
        {
          id: 'goals',
          question: 'What area of your life would you like to focus on?',
          type: 'multiple_choice',
          options: ['Career Growth', 'Personal Development', 'Health & Fitness', 'Work-Life Balance']
        },
        {
          id: 'motivation',
          question: 'How motivated do you feel right now?',
          type: 'scale'
        },
        {
          id: 'support',
          question: 'Do you currently have a support system?',
          type: 'yes_no'
        },
        {
          id: 'timeframe',
          question: 'When would you like to see results?',
          type: 'multiple_choice',
          options: ['1-3 months', '3-6 months', '6-12 months', 'I\'m patient, long-term']
        }
      ]
    }
  },

  business: {
    id: 'business',
    slug: 'business-strategy',
    title: 'Business Strategy',
    shortName: 'Business',
    description: 'Scale your business with strategic planning, leadership development, and actionable growth strategies',
    icon: Briefcase,
    gradient: 'from-green-500/20 to-emerald-500/20',
    backgroundColor: 'from-blue-500 to-cyan-500',
    backgroundImage: '/backgrounds/business-strategy-office.jpg',
    greeting: "Hello! Ready to elevate your business? What's your biggest challenge or opportunity right now? Let's think strategically and turn your vision into results.",
    introMessage: "Hello! I'm your Business Strategy Mentor. Let's think smart, plan bold, and turn your ideas into results. I'll guide you toward growth and success.",
    features: ['Strategic Planning', 'Growth Consulting', 'Leadership Development'],
    defaultAvatarId: 'Maya_Professional_public',
    systemPrompts: {
      'en-US': 'You are a strategic business advisor. Keep responses clear, professional, and under 3 sentences. Focus on practical solutions and growth strategies.',
      'es': 'Eres un asesor de negocios estratégico. Mantén las respuestas claras, profesionales y de menos de 3 oraciones. Enfócate en soluciones prácticas y estrategias de crecimiento.',
      'de': 'Sie sind ein strategischer Unternehmensberater. Halten Sie die Antworten klar, professionell und unter 3 Sätzen. Konzentrieren Sie sich auf praktische Lösungen und Wachstumsstrategien.',
    },
    personalizationQuestions: {
      questions: [
        {
          id: 'stage',
          question: 'What stage is your business at?',
          type: 'multiple_choice',
          options: ['Idea Stage', 'Starting Up', 'Growing', 'Established']
        },
        {
          id: 'challenge',
          question: 'What\'s your biggest business challenge?',
          type: 'multiple_choice',
          options: ['Strategy', 'Marketing', 'Team Management', 'Financial Planning']
        },
        {
          id: 'confidence',
          question: 'How confident do you feel about your business decisions?',
          type: 'scale'
        },
        {
          id: 'mentor',
          question: 'Have you worked with a business advisor before?',
          type: 'yes_no'
        }
      ]
    }
  },

  relationships: {
    id: 'relationships',
    slug: 'relationships',
    title: 'Relationship Guidance',
    shortName: 'Relationships',
    description: 'Strengthen your connections through improved communication, conflict resolution, and deeper understanding',
    icon: Users,
    gradient: 'from-pink-500/20 to-rose-500/20',
    backgroundColor: 'from-emerald-500 to-teal-500',
    backgroundImage: '/backgrounds/relationships-office.jpg',
    greeting: "Hi! Every relationship is unique and valuable. What relationship in your life would you like to focus on today? Let's work on building stronger, healthier connections together.",
    introMessage: "Hi there! I'm your Relationship Coach. Together, we'll work on better communication, deeper connection, and more understanding in your relationships.",
    features: ['Communication Skills', 'Conflict Resolution', 'Emotional Intelligence'],
    defaultAvatarId: 'Emily_Relaxed_Sitting_public',
    systemPrompts: {
      'en-US': 'You are a relationship coach and mediator. Keep responses empathetic, understanding, and under 3 sentences. Focus on healthy communication and connection.',
      'es': 'Eres un coach de relaciones y mediador. Mantén las respuestas empáticas, comprensivas y de menos de 3 oraciones. Enfócate en comunicación saludable y conexión.',
      'fr': 'Vous êtes un coach relationnel et médiateur. Gardez les réponses empathiques, compréhensives et de moins de 3 phrases. Concentrez-vous sur une communication saine et la connexion.',
    },
    personalizationQuestions: {
      questions: [
        {
          id: 'focus',
          question: 'Which relationship area needs the most attention?',
          type: 'multiple_choice',
          options: ['Romantic Partner', 'Family', 'Friends', 'Professional Relationships']
        },
        {
          id: 'satisfaction',
          question: 'How satisfied are you with your relationships?',
          type: 'scale'
        },
        {
          id: 'communication',
          question: 'Do you feel comfortable expressing your feelings?',
          type: 'yes_no'
        },
        {
          id: 'conflict',
          question: 'How do you typically handle conflicts?',
          type: 'multiple_choice',
          options: ['Avoid them', 'Address directly', 'Seek compromise', 'Get help from others']
        }
      ]
    }
  }
};

// Helper functions
export const getCategoryById = (id: CategoryId): CategoryConfig => CATEGORIES[id];

export const getAllCategories = (): CategoryConfig[] => Object.values(CATEGORIES);

export const getCategorySlug = (id: CategoryId): string => CATEGORIES[id].slug;

export const getCategoryBySlug = (slug: string): CategoryConfig | undefined => 
  Object.values(CATEGORIES).find(cat => cat.slug === slug);

export const getSystemPrompt = (categoryId: CategoryId, language: string): string => {
  const category = CATEGORIES[categoryId];
  return category.systemPrompts[language] || category.systemPrompts['en-US'];
};

export const getBackgroundImage = (categoryId: CategoryId): string => 
  CATEGORIES[categoryId].backgroundImage;

export const getCategoryGradient = (categoryId: CategoryId): string => 
  CATEGORIES[categoryId].gradient;
