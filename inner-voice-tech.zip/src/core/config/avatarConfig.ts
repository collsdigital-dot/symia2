// Avatar option interface
export interface AvatarOption {
  id: string;
  name: string;
  gender: 'male' | 'female';
  thumbnail: string;
  description: string;
  supportedLanguages: string[];
  defaultVoiceId: string;
}

// Language option interface
export interface LanguageOption {
  code: string;
  name: string;
  flag: string;
  nativeName: string;
  liveAvatarVoiceId: string;
}

// Avatar data is now fetched dynamically from LiveAvatar API using useFunnelAvatars hook
// No hardcoded avatars - use /debug-liveavatar to see available Interactive Avatars

// Default LiveAvatar voice ID (used across languages until specific IDs are configured)
const DEFAULT_LIVEAVATAR_VOICE_ID = '119caed25533477ba63822d5d1552d25';

// 10 popular languages with LiveAvatar voice mappings
export const LANGUAGE_OPTIONS: LanguageOption[] = [
  {
    code: 'en-US',
    name: 'English (US)',
    flag: '🇺🇸',
    nativeName: 'English',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID
  },
  {
    code: 'en-GB',
    name: 'English (UK)',
    flag: '🇬🇧',
    nativeName: 'English',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual UK voice ID
  },
  {
    code: 'es',
    name: 'Spanish',
    flag: '🇪🇸',
    nativeName: 'Español',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual Spanish voice ID
  },
  {
    code: 'es-MX',
    name: 'Spanish (Mexico)',
    flag: '🇲🇽',
    nativeName: 'Español',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual Mexican Spanish voice ID
  },
  {
    code: 'fr',
    name: 'French',
    flag: '🇫🇷',
    nativeName: 'Français',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual French voice ID
  },
  {
    code: 'de',
    name: 'German',
    flag: '🇩🇪',
    nativeName: 'Deutsch',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual German voice ID
  },
  {
    code: 'it',
    name: 'Italian',
    flag: '🇮🇹',
    nativeName: 'Italiano',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual Italian voice ID
  },
  {
    code: 'pt',
    name: 'Portuguese (Brazil)',
    flag: '🇧🇷',
    nativeName: 'Português',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual Portuguese voice ID
  },
  {
    code: 'zh',
    name: 'Chinese (Mandarin)',
    flag: '🇨🇳',
    nativeName: '中文',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual Chinese voice ID
  },
  {
    code: 'ja',
    name: 'Japanese',
    flag: '🇯🇵',
    nativeName: '日本語',
    liveAvatarVoiceId: DEFAULT_LIVEAVATAR_VOICE_ID // TODO: Replace with actual Japanese voice ID
  }
];
