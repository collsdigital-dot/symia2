export const ROUTES = {
  HOME: '/',
  FUNNEL: '/funnel',
  AUTH: '/auth',
  DASHBOARD: '/dashboard',
  SETTINGS: '/settings',
  AVATAR_CUSTOMIZATION: '/avatar-customization',
  CONVERSATIONS: '/conversations',
  PRICING: '/pricing',
  
  // Admin routes
  ADMIN: '/admin',
  ADMIN_USERS: '/admin/users',
  ADMIN_ANALYTICS: '/admin/analytics',
  ADMIN_SYSTEM: '/admin/system',
  
  DEBUG_LIVEAVATAR: '/debug-liveavatar',
} as const;

export type RoutePath = typeof ROUTES[keyof typeof ROUTES];
