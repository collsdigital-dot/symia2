import { User, Session } from '@supabase/supabase-js';

// Operational role (platform management)
export type AppRole = 'admin' | 'moderator' | 'user';

// Subscription tier (customer access)
export type SubscriptionTier = 'free' | 'standard' | 'premium';

export interface UserRole {
  id: string;
  user_id: string;
  role: AppRole;
  created_at: string;
  updated_at: string;
}

export interface AuthUser extends User {
  role?: AppRole;
  subscriptionTier?: SubscriptionTier;
}

export interface AuthContextType {
  session: Session | null;
  user: AuthUser | null;
  role: AppRole | null;
  subscriptionTier: SubscriptionTier | null;
  loading: boolean;
  
  // Role checks (operational)
  isAdmin: boolean;
  isModerator: boolean;
  
  // Subscription checks (customer)
  isFreeUser: boolean;
  isPremiumUser: boolean;
  
  signOut: () => Promise<void>;
  refreshRole: () => Promise<void>;
  refreshSubscription: () => Promise<void>;
}
