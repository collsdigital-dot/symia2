import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/features/auth/hooks";
import { SubscriptionTier } from "@/core/types/auth";
import { ROUTES } from "@/core/routes/paths";
import { Loader2 } from "lucide-react";

interface SubscriptionGuardProps {
  children: ReactNode;
  requiredTier: SubscriptionTier | SubscriptionTier[];
}

export function SubscriptionGuard({ children, requiredTier }: SubscriptionGuardProps) {
  const { subscriptionTier, loading, isAdmin } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Admins bypass all subscription checks
  if (isAdmin) {
    return <>{children}</>;
  }

  const allowedTiers = Array.isArray(requiredTier) ? requiredTier : [requiredTier];
  const hasAccess = subscriptionTier && allowedTiers.includes(subscriptionTier);

  if (!hasAccess) {
    return <Navigate to={ROUTES.PRICING} replace />;
  }

  return <>{children}</>;
}
