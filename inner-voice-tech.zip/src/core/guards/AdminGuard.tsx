import { ReactNode } from "react";
import { RoleGuard } from "./RoleGuard";

interface AdminGuardProps {
  children: ReactNode;
}

export function AdminGuard({ children }: AdminGuardProps) {
  return <RoleGuard requiredRole="admin">{children}</RoleGuard>;
}
