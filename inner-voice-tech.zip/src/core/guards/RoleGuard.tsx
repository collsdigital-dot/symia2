import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/features/auth/hooks";
import { AppRole } from "@/core/types/auth";
import { Loader2 } from "lucide-react";
import { ROUTES } from "@/core/routes/paths";

interface RoleGuardProps {
  children: ReactNode;
  requiredRole: AppRole | AppRole[];
  fallbackPath?: string;
}

export function RoleGuard({ 
  children, 
  requiredRole, 
  fallbackPath = ROUTES.DASHBOARD 
}: RoleGuardProps) {
  const { user, role, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to={ROUTES.AUTH} replace />;
  }

  const allowedRoles = Array.isArray(requiredRole) ? requiredRole : [requiredRole];
  const hasRequiredRole = role && allowedRoles.includes(role);

  if (!hasRequiredRole) {
    return <Navigate to={fallbackPath} replace />;
  }

  return <>{children}</>;
}
