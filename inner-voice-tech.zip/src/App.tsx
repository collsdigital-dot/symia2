import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "@/features/auth/hooks";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AdminGuard } from "@/core/guards/AdminGuard";
import { ErrorBoundary } from "@/core/components/ErrorBoundary";
import { ROUTES } from "@/core/routes/paths";
import { PageTransition } from "@/components/ui/PageTransition";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Settings from "./pages/Settings";
import AvatarCustomization from "./pages/AvatarCustomization";
import Conversations from "./pages/Conversations";
import Pricing from "./pages/Pricing";
import NotFound from "./pages/NotFound";
import SimiaFunnel from "./pages/SimiaFunnel";
import AdminDashboard from "./pages/AdminDashboard";
import DebugPage from "./pages/DebugPage";
import VoicesDebug from "./pages/VoicesDebug";

const queryClient = new QueryClient();

const AnimatedRoutes = () => {
  const location = useLocation();
  
  return (
    <PageTransition>
      <Routes location={location} key={location.pathname}>
        <Route path={ROUTES.HOME} element={<Index />} />
        <Route path={ROUTES.FUNNEL} element={<SimiaFunnel />} />
        <Route path={ROUTES.AUTH} element={<Auth />} />
        <Route path={ROUTES.DASHBOARD} element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path={ROUTES.SETTINGS} element={<ProtectedRoute><Settings /></ProtectedRoute>} />
        <Route path={ROUTES.AVATAR_CUSTOMIZATION} element={<ProtectedRoute><AvatarCustomization /></ProtectedRoute>} />
        <Route path={ROUTES.CONVERSATIONS} element={<ProtectedRoute><Conversations /></ProtectedRoute>} />
        <Route path={ROUTES.PRICING} element={<ProtectedRoute><Pricing /></ProtectedRoute>} />
        <Route path="/debug" element={<ProtectedRoute><DebugPage /></ProtectedRoute>} />
        <Route path="/debug/voices" element={<ProtectedRoute><VoicesDebug /></ProtectedRoute>} />
        
        {/* Admin routes */}
        <Route 
          path={ROUTES.ADMIN} 
          element={
            <ProtectedRoute>
              <AdminGuard>
                <AdminDashboard />
              </AdminGuard>
            </ProtectedRoute>
          } 
        />
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </PageTransition>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <ErrorBoundary>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <AnimatedRoutes />
          </AuthProvider>
        </BrowserRouter>
      </ErrorBoundary>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
