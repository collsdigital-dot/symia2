import { supabase } from "@/integrations/supabase/client";

export async function uploadBackgroundsToStorage() {
  try {
    console.log("Starting background upload...");
    
    const { data, error } = await supabase.functions.invoke('upload-backgrounds');
    
    if (error) {
      console.error("Failed to upload backgrounds:", error);
      return { success: false, error };
    }
    
    console.log("Background upload results:", data);
    return { success: true, data };
  } catch (error) {
    console.error("Upload backgrounds error:", error);
    return { success: false, error };
  }
}
