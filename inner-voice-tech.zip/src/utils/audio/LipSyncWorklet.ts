export const lipSyncWorkletCode = `
class LipSyncProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.bufferSize = 128;
  }

  process(inputs, outputs, parameters) {
    const input = inputs[0];
    if (!input || !input[0]) return true;

    const samples = input[0];
    
    let sum = 0;
    for (let i = 0; i < samples.length; i++) {
      sum += samples[i] * samples[i];
    }
    const rms = Math.sqrt(sum / samples.length);
    
    const lowFreq = this.calculateBandEnergy(samples, 0, 50);
    const midFreq = this.calculateBandEnergy(samples, 50, 100);
    const highFreq = this.calculateBandEnergy(samples, 100, samples.length);
    
    const visemes = {
      jawOpen: Math.min(rms * 30, 1), // Increased from 15 to 30
      mouthSmile: Math.min(highFreq * 4, 0.7), // Increased from 2 to 4
      mouthFunnel: Math.min(lowFreq * 3, 0.7), // Increased from 2 to 3
      mouthPucker: Math.min(midFreq * 3, 0.7), // Increased from 1.5 to 3
    };
    
    this.port.postMessage(visemes);
    
    return true;
  }
  
  calculateBandEnergy(samples, startIdx, endIdx) {
    let energy = 0;
    for (let i = startIdx; i < endIdx && i < samples.length; i++) {
      energy += Math.abs(samples[i]);
    }
    return energy / (endIdx - startIdx);
  }
}

registerProcessor('lip-sync-processor', LipSyncProcessor);
`;

export class LipSyncAnalyzer {
  private audioContext: AudioContext | null = null;
  private workletNode: AudioWorkletNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;

  async initialize(audioStream: MediaStream, onVisemeUpdate: (visemes: any) => void) {
    try {
      this.audioContext = new AudioContext({ sampleRate: 24000 });
      
      const blob = new Blob([lipSyncWorkletCode], { type: 'application/javascript' });
      const workletUrl = URL.createObjectURL(blob);
      
      await this.audioContext.audioWorklet.addModule(workletUrl);
      URL.revokeObjectURL(workletUrl);
      
      this.workletNode = new AudioWorkletNode(this.audioContext, 'lip-sync-processor');
      
      this.workletNode.port.onmessage = (event) => {
        onVisemeUpdate(event.data);
      };
      
      this.sourceNode = this.audioContext.createMediaStreamSource(audioStream);
      this.sourceNode.connect(this.workletNode);
      this.workletNode.connect(this.audioContext.destination);
      
      console.log('[LipSync] Analyzer initialized');
    } catch (error) {
      console.error('[LipSync] Error initializing:', error);
      throw error;
    }
  }

  cleanup() {
    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }
    if (this.workletNode) {
      this.workletNode.disconnect();
      this.workletNode = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
  }
}
