// ============================================
// BACKGROUND HELPERS - Centralized Background Management
// ============================================

import { CategoryId, CATEGORIES } from '@/core/config/categories';

/**
 * Gets the background image path for a category
 */
export function getBackgroundForCategory(categoryId: CategoryId): string {
  return CATEGORIES[categoryId].backgroundImage;
}

/**
 * Gets the gradient classes for a category
 */
export function getCategoryGradient(categoryId: CategoryId): string {
  return CATEGORIES[categoryId].gradient;
}

/**
 * Gets the background color gradient for a category (used in cards/buttons)
 */
export function getCategoryBackgroundColor(categoryId: CategoryId): string {
  return CATEGORIES[categoryId].backgroundColor;
}

/**
 * Preloads a background image for smooth transitions
 */
export function preloadBackground(categoryId: CategoryId): Promise<void> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve();
    img.onerror = reject;
    img.src = getBackgroundForCategory(categoryId);
  });
}

/**
 * Preloads all category backgrounds
 */
export async function preloadAllBackgrounds(): Promise<void> {
  const categories: CategoryId[] = ['mental_health', 'life_coaching', 'business', 'relationships'];
  await Promise.all(categories.map(preloadBackground));
}
