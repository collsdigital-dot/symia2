import { LANGUAGE_OPTIONS } from '@/core/config/avatarConfig';

export const getLanguageByCode = (code: string) =>
  LANGUAGE_OPTIONS.find(l => l.code === code) || LANGUAGE_OPTIONS[0];

export const getLanguageName = (code: string) =>
  getLanguageByCode(code).name;

export const getLanguageFlag = (code: string) =>
  getLanguageByCode(code).flag;

export const getLanguageNativeName = (code: string) =>
  getLanguageByCode(code).nativeName;

export const getLiveAvatarVoiceId = (code: string) =>
  getLanguageByCode(code).liveAvatarVoiceId;
