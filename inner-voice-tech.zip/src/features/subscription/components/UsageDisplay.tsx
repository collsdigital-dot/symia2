import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { MessageSquare, Video, TrendingUp } from "lucide-react";
import { useAuth } from "@/features/auth/hooks";

interface UsageDisplayProps {
  usageLimits: any;
}

export function UsageDisplay({ usageLimits }: UsageDisplayProps) {
  const { subscriptionTier, isAdmin } = useAuth();

  if (!usageLimits) {
    return null;
  }

  const textChatLimit = subscriptionTier === 'premium' ? Infinity : 
    subscriptionTier === 'standard' ? 10 : 1;
  
  const liveDemoLimit = subscriptionTier === 'premium' ? Infinity : 
    subscriptionTier === 'standard' ? 5 : 0;

  const textChatPercent = textChatLimit === Infinity ? 0 : 
    (usageLimits.text_chats_used / textChatLimit) * 100;
  
  const liveDemoPercent = liveDemoLimit === Infinity || liveDemoLimit === 0 ? 0 : 
    (usageLimits.live_demos_used / liveDemoLimit) * 100;

  const getUsageColor = (percent: number) => {
    if (percent >= 90) return "text-destructive";
    if (percent >= 70) return "text-yellow-500";
    return "text-primary";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Usage Statistics
        </CardTitle>
        <CardDescription>
          Track your current usage and limits
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Text Chats */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">Text Chat Sessions</span>
            </div>
            <span className={`text-sm font-semibold ${getUsageColor(textChatPercent)}`}>
              {isAdmin ? "∞" : 
                textChatLimit === Infinity ? "Unlimited" : 
                `${usageLimits.text_chats_used} / ${textChatLimit}`
              }
            </span>
          </div>
          {!isAdmin && textChatLimit !== Infinity && (
            <Progress value={textChatPercent} className="h-2" />
          )}
        </div>

        {/* Live Demos */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Video className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">Live Demo Sessions</span>
            </div>
            <span className={`text-sm font-semibold ${getUsageColor(liveDemoPercent)}`}>
              {isAdmin ? "∞" : 
                liveDemoLimit === Infinity ? "Unlimited" : 
                liveDemoLimit === 0 ? "Not Available" :
                `${usageLimits.live_demos_used} / ${liveDemoLimit}`
              }
            </span>
          </div>
          {!isAdmin && liveDemoLimit !== Infinity && liveDemoLimit > 0 && (
            <Progress value={liveDemoPercent} className="h-2" />
          )}
        </div>

        {/* Admin Notice */}
        {isAdmin && (
          <div className="text-xs text-muted-foreground italic">
            Admin accounts have unlimited usage
          </div>
        )}
      </CardContent>
    </Card>
  );
}
