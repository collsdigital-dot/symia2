import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/features/auth/hooks";
import { useNavigate } from "react-router-dom";
import { Check, Crown, Zap, ArrowUpCircle } from "lucide-react";
import { SUBSCRIPTION_TIERS } from "@/core/config/constants";

interface SubscriptionManagerProps {
  usageLimits: any;
  onRefresh: () => void;
}

export function SubscriptionManager({ usageLimits, onRefresh }: SubscriptionManagerProps) {
  const { subscriptionTier, isAdmin } = useAuth();
  const navigate = useNavigate();

  const tierInfo = {
    free: {
      name: "Free Tier",
      icon: Zap,
      color: "text-muted-foreground",
      bgColor: "bg-muted",
      features: [
        "1 text chat session",
        "Basic avatar interactions",
        "Community support"
      ]
    },
    standard: {
      name: "Standard Plan",
      icon: Zap,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      features: [
        "10 text chat sessions",
        "5 live demo sessions",
        "Priority support",
        "Advanced avatar customization"
      ]
    },
    premium: {
      name: "Premium Plan",
      icon: Crown,
      color: "text-primary",
      bgColor: "bg-primary/10",
      features: [
        "Unlimited text chats",
        "Unlimited live sessions",
        "Priority support",
        "All avatar features",
        "Custom backgrounds",
        "Advanced analytics"
      ]
    }
  };

  const currentTier = tierInfo[subscriptionTier as keyof typeof tierInfo] || tierInfo.free;
  const Icon = currentTier.icon;

  const handleUpgrade = () => {
    navigate("/pricing");
  };

  const handleManageSubscription = () => {
    // In future, this will open a Stripe customer portal
    navigate("/settings/subscription/billing");
  };

  return (
    <div className="space-y-6">
      {/* Current Plan Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="flex items-center gap-2">
                <Icon className={`w-5 h-5 ${currentTier.color}`} />
                {currentTier.name}
              </CardTitle>
              <CardDescription>
                Your current subscription plan
              </CardDescription>
            </div>
            <Badge className={currentTier.bgColor}>
              {subscriptionTier?.toUpperCase()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Features */}
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Plan Features</h4>
            <div className="grid gap-2">
              {currentTier.features.map((feature, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Admin Badge */}
          {isAdmin && (
            <div className="rounded-lg bg-primary/10 p-3 border border-primary/20">
              <p className="text-sm font-medium text-primary flex items-center gap-2">
                <Crown className="w-4 h-4" />
                Admin Access - Unlimited Features
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            {subscriptionTier !== 'premium' && !isAdmin && (
              <Button onClick={handleUpgrade} className="gap-2">
                <ArrowUpCircle className="w-4 h-4" />
                Upgrade Plan
              </Button>
            )}
            {subscriptionTier !== 'free' && (
              <Button variant="outline" onClick={handleManageSubscription}>
                Manage Subscription
              </Button>
            )}
          </div>

          {/* Next Reset */}
          {usageLimits?.reset_date && subscriptionTier !== 'premium' && (
            <div className="text-sm text-muted-foreground">
              Usage resets on: {new Date(usageLimits.reset_date).toLocaleDateString()}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
