import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Crown, Sparkles, Zap } from "lucide-react";

interface UpgradePromptProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  feature: "text_chat" | "live_session";
  currentTier: string;
}

export function UpgradePrompt({ open, onOpenChange, feature, currentTier }: UpgradePromptProps) {
  const navigate = useNavigate();

  const featureInfo = {
    text_chat: {
      title: "Text Chat Limit Reached",
      description: currentTier === 'free' 
        ? "You've used your 1 free text chat session. Upgrade to continue chatting with your AI companion."
        : "You've reached your text chat limit. Upgrade to premium for unlimited conversations.",
      icon: Sparkles,
    },
    live_session: {
      title: "Live Sessions Unavailable",
      description: currentTier === 'free'
        ? "Live sessions are available with Standard and Premium plans. Upgrade to experience real-time AI interactions."
        : "You've used all your live demo sessions. Upgrade to premium for unlimited access.",
      icon: Zap,
    }
  };

  const info = featureInfo[feature];
  const Icon = info.icon;

  const handleUpgrade = () => {
    onOpenChange(false);
    navigate("/pricing");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon className="w-8 h-8 text-primary" />
            </div>
          </div>
          <DialogTitle className="text-center">{info.title}</DialogTitle>
          <DialogDescription className="text-center">
            {info.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 mt-4">
          <div className="rounded-lg bg-muted p-4 space-y-2">
            <h4 className="font-semibold text-sm flex items-center gap-2">
              <Crown className="w-4 h-4 text-primary" />
              Premium Benefits
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1 ml-6 list-disc">
              <li>Unlimited text chat sessions</li>
              <li>Unlimited live demo sessions</li>
              <li>Priority support</li>
              <li>Advanced customization</li>
            </ul>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Maybe Later
            </Button>
            <Button onClick={handleUpgrade} className="flex-1 gap-2">
              <Crown className="w-4 h-4" />
              View Plans
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
