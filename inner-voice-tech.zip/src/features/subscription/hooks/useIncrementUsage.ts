import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/features/auth/hooks';
import { toast } from 'sonner';

export function useIncrementUsage() {
  const { user } = useAuth();

  const incrementTextChat = async () => {
    if (!user) return false;

    try {
      const { data: limits } = await supabase
        .from('usage_limits')
        .select('text_chats_used')
        .eq('user_id', user.id)
        .single();

      if (!limits) return false;

      const { error } = await supabase
        .from('usage_limits')
        .update({ text_chats_used: limits.text_chats_used + 1 })
        .eq('user_id', user.id);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error incrementing text chat usage:', error);
      toast.error('Failed to track usage');
      return false;
    }
  };

  const incrementLiveDemo = async () => {
    if (!user) return false;

    try {
      const { data: limits } = await supabase
        .from('usage_limits')
        .select('live_demos_used')
        .eq('user_id', user.id)
        .single();

      if (!limits) return false;

      const { error } = await supabase
        .from('usage_limits')
        .update({ live_demos_used: limits.live_demos_used + 1 })
        .eq('user_id', user.id);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error incrementing live demo usage:', error);
      toast.error('Failed to track usage');
      return false;
    }
  };

  return {
    incrementTextChat,
    incrementLiveDemo,
  };
}
