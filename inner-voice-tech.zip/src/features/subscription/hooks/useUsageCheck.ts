import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/features/auth/hooks';

export function useUsageCheck() {
  const { user, subscriptionTier, isAdmin } = useAuth();
  const [canUseTextChat, setCanUseTextChat] = useState(false);
  const [canUseLiveSession, setCanUseLiveSession] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isAdmin) {
      setCanUseTextChat(true);
      setCanUseLiveSession(true);
      setLoading(false);
      return;
    }

    if (user) {
      checkUsage();
    }
  }, [user, subscriptionTier, isAdmin]);

  const checkUsage = async () => {
    if (!user) return;

    setLoading(true);

    try {
      const { data: limits } = await supabase
        .from('usage_limits')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!limits) {
        setCanUseTextChat(false);
        setCanUseLiveSession(false);
        setLoading(false);
        return;
      }

      // Check text chat limits
      if (subscriptionTier === 'premium') {
        setCanUseTextChat(true);
      } else if (subscriptionTier === 'standard') {
        setCanUseTextChat(limits.text_chats_used < 10);
      } else {
        setCanUseTextChat(limits.text_chats_used < 1);
      }

      // Check live session limits
      if (subscriptionTier === 'premium') {
        setCanUseLiveSession(true);
      } else if (subscriptionTier === 'standard') {
        setCanUseLiveSession(limits.live_demos_used < 5);
      } else {
        setCanUseLiveSession(false);
      }

    } catch (error) {
      console.error('Error checking usage:', error);
      setCanUseTextChat(false);
      setCanUseLiveSession(false);
    } finally {
      setLoading(false);
    }
  };

  return {
    canUseTextChat,
    canUseLiveSession,
    loading,
    refresh: checkUsage,
  };
}
