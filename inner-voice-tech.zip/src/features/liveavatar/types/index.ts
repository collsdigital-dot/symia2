export interface LiveAvatarConfig {
  avatarId: string;
  voiceId?: string;
  language?: string;
  category: 'mental_health' | 'life_coaching' | 'business' | 'relationships' | 'general-wellness';
  onSpeakingChange?: (isSpeaking: boolean) => void;
  onFirstSpeak?: () => void;
  onTranscription?: (text: string, speaker: 'user' | 'avatar') => void;
  onError?: (error: string) => void;
}

export interface LiveAvatarState {
  status: 'idle' | 'connecting' | 'connected' | 'speaking' | 'error';
  sessionId: string | null;
  error: string | null;
}

export interface LiveAvatarSessionData {
  sessionId: string;
  sessionToken: string;
  livekitUrl: string;
  livekitClientToken: string;
  maxSessionDuration: number;
  wsUrl: string;
  expiresAt?: string;
}
