import { useCallback } from "react";
import { useLiveAvatarContext } from "../context";

export const useSession = () => {
  const { sessionRef, sessionState, isStreamReady, connectionQuality } = useLiveAvatarContext();

  const startSession = useCallback(async () => {
    console.log('[useSession] Starting session...');
    return await sessionRef.current.start();
  }, [sessionRef]);

  const stopSession = useCallback(async () => {
    console.log('[useSession] Stopping session...');
    return await sessionRef.current.stop();
  }, [sessionRef]);

  const keepAlive = useCallback(async () => {
    console.log('[useSession] Sending keep alive...');
    return await sessionRef.current.keepAlive();
  }, [sessionRef]);

  const attachElement = useCallback(
    (element: HTMLMediaElement) => {
      console.log('[useSession] Attaching video element');
      return sessionRef.current.attach(element);
    },
    [sessionRef],
  );

  return {
    sessionState,
    isStreamReady,
    connectionQuality,
    startSession,
    stopSession,
    keepAlive,
    attachElement,
  };
};
