import { useState, useRef, useCallback, useEffect } from 'react';
import { LiveAvatarSession } from '@heygen/liveavatar-web-sdk';
import { supabase } from '@/integrations/supabase/client';
import type { LiveAvatarConfig, LiveAvatarState } from '../types';
import { toast } from 'sonner';
import { logDebug } from '@/components/debug/LiveAvatarDebugPanel';

export function useLiveAvatar(config: LiveAvatarConfig) {
  const [state, setState] = useState<LiveAvatarState>({
    status: 'idle',
    sessionId: null,
    error: null
  });

  const sessionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const firstSpeakCalledRef = useRef(false);

  const startSession = useCallback(async () => {
    try {
      console.log('[useLiveAvatar] Starting session with avatarId:', config.avatarId);
      logDebug('info', 'Session', 'Starting session with LiveAvatar SDK...', { 
        avatarId: config.avatarId, 
        category: config.category,
        language: config.language 
      });

      setState({ status: 'connecting', sessionId: null, error: null });
      firstSpeakCalledRef.current = false;

      // Create session credentials via backend
      const { data, error } = await supabase.functions.invoke('liveavatar-create-session', {
        body: {
          avatarId: config.avatarId,
          category: config.category,
          language: config.language || 'en-US'
        }
      });

      console.log('[useLiveAvatar] Edge function response:', { success: data?.success, error, avatarId: config.avatarId });

      if (error || !data?.success) {
        const errorMsg = data?.error || error?.message || 'Failed to create session';
        throw new Error(errorMsg);
      }

      logDebug('success', 'Session', `Session created: ${data.data.session_id}`);

      // Initialize LiveAvatar SDK session with any casting to bypass TypeScript
      const SessionClass: any = LiveAvatarSession;
      const session: any = new SessionClass(
        data.data.session_id,
        data.data.session_token
      );

      sessionRef.current = session;

      // Attach video stream to video element
      session.on?.('video', (stream: MediaStream) => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(err => {
            logDebug('error', 'Video', 'Video playback failed', err);
          });
          logDebug('success', 'Video', 'Video stream attached and playing');
        }
      });

      // Listen to speaking state changes
      session.on?.('speaking', (isSpeaking: boolean) => {
        setState(prev => ({ ...prev, status: isSpeaking ? 'speaking' : 'connected' }));
        config.onSpeakingChange?.(isSpeaking);
        
        logDebug('info', 'Avatar State', isSpeaking ? 'Speaking' : 'Stopped speaking');
        
        if (isSpeaking && !firstSpeakCalledRef.current) {
          config.onFirstSpeak?.();
          firstSpeakCalledRef.current = true;
          logDebug('success', 'Avatar State', 'First speak triggered');
        }
      });

      // Listen to transcription events
      session.on?.('transcription', ({ text, speaker }: { text: string; speaker: 'user' | 'avatar' }) => {
        config.onTranscription?.(text, speaker);
        logDebug('info', 'Transcription', `${speaker}: ${text}`);
      });

      // Listen to error events
      session.on?.('error', (err: Error) => {
        logDebug('error', 'Session Error', err.message);
        config.onError?.(err.message);
      });

      // Start the session
      await session.start?.();
      
      setState({
        status: 'connected',
        sessionId: data.data.session_id,
        error: null
      });

      logDebug('success', 'Session', 'LiveAvatar session started successfully');

    } catch (error) {
      let errorMsg = error instanceof Error ? error.message : 'Failed to start session';
      let detailedError = errorMsg;
      
      // Try to parse LiveAvatar-specific errors for better debugging
      if (errorMsg.includes('details') || errorMsg.includes('{')) {
        try {
          const match = errorMsg.match(/\{.*\}/);
          if (match) {
            const parsed = JSON.parse(match[0]);
            if (parsed.data?.[0]?.message) {
              detailedError = parsed.data[0].message;
              errorMsg = `LiveAvatar error: ${detailedError}`;
            }
          }
        } catch (parseError) {
          // Keep original error if parsing fails
        }
      }
      
      logDebug('error', 'Session', 'Session start failed', { error, errorMsg, detailedError });
      setState({ status: 'error', sessionId: null, error: errorMsg });
      config.onError?.(errorMsg);
      toast.error('Connection Failed', { description: 'Unable to connect to live session. Please try again.' });
    }
  }, [config]);

  const endSession = useCallback(async () => {
    const currentSessionId = state.sessionId;
    logDebug('info', 'Session', 'Ending session...', { sessionId: currentSessionId });

    // Stop SDK session
    if (sessionRef.current) {
      try {
        await sessionRef.current.stop?.();
        logDebug('success', 'SDK', 'Session stopped via SDK');
      } catch (err) {
        logDebug('error', 'SDK', 'Error stopping session', err);
      }
      sessionRef.current = null;
    }

    // Clean up video element
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    // Notify backend
    if (currentSessionId) {
      try {
        await supabase.functions.invoke('liveavatar-end-session', {
          body: { sessionId: currentSessionId }
        });
        logDebug('success', 'Session', 'Backend notified of session end');
      } catch (err) {
        logDebug('error', 'Session', 'Failed to notify backend', err);
      }
    }

    setState({ status: 'idle', sessionId: null, error: null });
    firstSpeakCalledRef.current = false;
  }, [state.sessionId]);

  const sendMessage = useCallback((text: string) => {
    if (sessionRef.current) {
      sessionRef.current.sendMessage?.(text);
      logDebug('info', 'Message', `Sent: ${text}`);
    }
  }, []);

  const interrupt = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.interrupt?.();
      logDebug('info', 'Control', 'Interrupted avatar');
    }
  }, []);

  const muteAudio = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.mute?.();
      logDebug('info', 'Audio', 'Microphone muted');
    }
  }, []);

  const unmuteAudio = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.unmute?.();
      logDebug('info', 'Audio', 'Microphone unmuted');
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (sessionRef.current) {
        sessionRef.current.stop?.();
        sessionRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    };
  }, []);

  return {
    state,
    videoRef,
    startSession,
    endSession,
    muteAudio,
    unmuteAudio,
    interrupt,
    sendMessage,
    // Compatibility methods for existing components
    speakText: sendMessage,
    startListening: () => logDebug('info', 'SDK', 'Voice chat is always active with LiveAvatar SDK'),
    stopListening: () => logDebug('info', 'SDK', 'Voice chat is always active with LiveAvatar SDK'),
  };
}
