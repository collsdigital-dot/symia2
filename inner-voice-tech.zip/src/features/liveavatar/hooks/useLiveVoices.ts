import { useState, useEffect } from 'react';
import { fetchLiveVoices, VoiceOption } from '../services/voiceService';

/**
 * Hook to fetch and manage LiveAvatar voices
 */
export function useLiveVoices() {
  const [voices, setVoices] = useState<VoiceOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadVoices();
  }, []);

  const loadVoices = async () => {
    try {
      setLoading(true);
      setError(null);
      const fetchedVoices = await fetchLiveVoices();
      setVoices(fetchedVoices);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load voices';
      setError(errorMessage);
      console.error('[useLiveVoices] Error:', err);
    } finally {
      setLoading(false);
    }
  };

  return {
    voices,
    loading,
    error,
    refresh: loadVoices
  };
}
