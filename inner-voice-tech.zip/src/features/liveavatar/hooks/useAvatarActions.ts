import { useCallback } from "react";
import { useLiveAvatarContext } from "../context";

export const useAvatarActions = () => {
  const { sessionRef } = useLiveAvatarContext();

  const interrupt = useCallback(() => {
    console.log('[useAvatarActions] Interrupting...');
    return sessionRef.current.interrupt();
  }, [sessionRef]);

  const repeat = useCallback(
    async (message: string) => {
      console.log('[useAvatarActions] Repeating message:', message);
      return sessionRef.current.repeat(message);
    },
    [sessionRef],
  );

  const startListening = useCallback(() => {
    console.log('[useAvatarActions] Start listening...');
    return sessionRef.current.startListening();
  }, [sessionRef]);

  const stopListening = useCallback(() => {
    console.log('[useAvatarActions] Stop listening...');
    return sessionRef.current.stopListening();
  }, [sessionRef]);

  return {
    interrupt,
    repeat,
    startListening,
    stopListening,
  };
};
