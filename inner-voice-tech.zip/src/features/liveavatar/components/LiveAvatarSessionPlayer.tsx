import { useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Square, Volume2, VolumeX } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { LiveAvatarContextProvider } from '../context';
import { useSession } from '../hooks/useSession';
import { useVoiceChat } from '../hooks/useVoiceChat';
import { useAvatarActions } from '../hooks/useAvatarActions';
import { SessionState } from '@heygen/liveavatar-web-sdk';

interface LiveAvatarSessionPlayerProps {
  avatarId: string;
  category?: string;
  language?: string;
  voiceId?: string;
  autoStart?: boolean;
  showControls?: boolean;
  showTimer?: boolean;
  maxDuration?: number;
  onSessionEnd?: (duration: number) => void;
  onError?: (error: string) => void;
}

const LiveAvatarSessionComponent = ({
  showControls = true,
  showTimer = true,
  maxDuration = 3600,
  onSessionEnd,
}: {
  showControls?: boolean;
  showTimer?: boolean;
  maxDuration?: number;
  onSessionEnd?: (duration: number) => void;
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [duration, setDuration] = useState(0);

  const {
    sessionState,
    isStreamReady,
    startSession,
    stopSession,
    attachElement,
  } = useSession();

  const {
    isMuted,
    isUserTalking,
    isAvatarTalking,
    mute,
    unmute,
    start: startVoiceChat,
    stop: stopVoiceChat,
    isActive: isVoiceChatActive,
  } = useVoiceChat();

  const { interrupt, startListening, stopListening } = useAvatarActions();

  // Auto-start session
  useEffect(() => {
    if (sessionState === SessionState.INACTIVE) {
      console.log('[LiveAvatarSessionPlayer] Auto-starting session...');
      startSession();
    }
  }, [sessionState, startSession]);

  // Attach video element when stream is ready
  useEffect(() => {
    if (isStreamReady && videoRef.current) {
      console.log('[LiveAvatarSessionPlayer] Attaching video element');
      attachElement(videoRef.current);
    }
  }, [isStreamReady, attachElement]);

  // Auto-start voice chat when session is connected
  useEffect(() => {
    if (sessionState === SessionState.CONNECTED && !isVoiceChatActive) {
      console.log('[LiveAvatarSessionPlayer] Auto-starting voice chat...');
      startVoiceChat();
    }
  }, [sessionState, isVoiceChatActive, startVoiceChat]);

  // Session timer
  useEffect(() => {
    if (sessionState !== SessionState.CONNECTED) return;

    const timer = setInterval(() => {
      setDuration((prev) => {
        const newDuration = prev + 1;
        if (newDuration >= maxDuration) {
          handleEndSession();
        }
        return newDuration;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [sessionState, maxDuration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleMute = async () => {
    if (isMuted) {
      await unmute();
    } else {
      await mute();
    }
  };

  const toggleListening = async () => {
    if (isUserTalking) {
      await stopListening();
    } else {
      await startListening();
    }
  };

  const handleInterrupt = async () => {
    await interrupt();
  };

  const handleEndSession = async () => {
    await stopVoiceChat();
    await stopSession();
    onSessionEnd?.(duration);
  };

  return (
    <div className="relative w-full h-full">
      <Card className="relative w-full aspect-video overflow-hidden bg-background">
        {/* Video Stream */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          className="w-full h-full object-contain"
        />

        {/* Status Overlays */}
        {sessionState === SessionState.CONNECTING && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-foreground">Connecting to avatar...</p>
            </div>
          </div>
        )}

        {sessionState === SessionState.DISCONNECTED && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80">
            <p className="text-foreground">Session ended</p>
          </div>
        )}

        {/* Speaking Indicator */}
        {isAvatarTalking && (
          <div className="absolute top-4 left-4 px-3 py-1 bg-primary/90 text-primary-foreground rounded-full text-sm">
            Avatar speaking...
          </div>
        )}

        {/* Muted Indicator */}
        {isMuted && sessionState === SessionState.CONNECTED && (
          <div className="absolute top-4 right-4 px-3 py-1 bg-destructive/90 text-destructive-foreground rounded-full text-sm">
            Microphone muted
          </div>
        )}

        {/* Timer */}
        {showTimer && sessionState === SessionState.CONNECTED && (
          <div className="absolute bottom-4 left-4 px-3 py-1 bg-background/90 text-foreground rounded-full text-sm font-mono">
            {formatTime(duration)}
          </div>
        )}

        {/* Controls */}
        {showControls && sessionState === SessionState.CONNECTED && (
          <div className="absolute bottom-4 right-4 flex gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={toggleMute}
              title={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </Button>
            
            <Button
              size="sm"
              variant="secondary"
              onClick={toggleListening}
              title={isUserTalking ? "Stop Listening" : "Start Listening"}
            >
              {isUserTalking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            
            <Button
              size="sm"
              variant="secondary"
              onClick={handleInterrupt}
              title="Interrupt"
            >
              Interrupt
            </Button>
            
            <Button
              size="sm"
              variant="destructive"
              onClick={handleEndSession}
              title="End Session"
            >
              <Square className="w-4 h-4" />
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
};

export const LiveAvatarSessionPlayer = ({
  avatarId,
  category = 'general-wellness',
  language = 'en-US',
  voiceId,
  autoStart = true,
  showControls = true,
  showTimer = true,
  maxDuration = 3600,
  onSessionEnd,
  onError,
}: LiveAvatarSessionPlayerProps) => {
  const [sessionToken, setSessionToken] = useState<string>('');
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    const createSession = async () => {
      setIsCreating(true);
      console.log('[LiveAvatarSessionPlayer] Creating session for avatar:', avatarId);

      try {
        const { data, error } = await supabase.functions.invoke('liveavatar-create-session', {
          body: { avatarId, category, language, voiceId }
        });

        if (error) {
          console.error('[LiveAvatarSessionPlayer] Session creation error:', error);
          onError?.(error.message);
          return;
        }

        if (!data?.success || !data?.data?.session_token) {
          console.error('[LiveAvatarSessionPlayer] Invalid session response:', data);
          onError?.('Failed to create session');
          return;
        }

        console.log('[LiveAvatarSessionPlayer] Session created, token:', data.data.session_token.substring(0, 20) + '...');
        setSessionToken(data.data.session_token);
      } catch (err) {
        console.error('[LiveAvatarSessionPlayer] Session creation exception:', err);
        onError?.(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setIsCreating(false);
      }
    };

    if (autoStart && !sessionToken) {
      createSession();
    }
  }, [avatarId, category, language, voiceId, autoStart, sessionToken, onError]);

  if (isCreating) {
    return (
      <Card className="w-full aspect-video flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-foreground">Creating session...</p>
        </div>
      </Card>
    );
  }

  if (!sessionToken) {
    return (
      <Card className="w-full aspect-video flex items-center justify-center">
        <p className="text-muted-foreground">Waiting for session...</p>
      </Card>
    );
  }

  return (
    <LiveAvatarContextProvider sessionAccessToken={sessionToken}>
      <LiveAvatarSessionComponent
        showControls={showControls}
        showTimer={showTimer}
        maxDuration={maxDuration}
        onSessionEnd={onSessionEnd}
      />
    </LiveAvatarContextProvider>
  );
};
