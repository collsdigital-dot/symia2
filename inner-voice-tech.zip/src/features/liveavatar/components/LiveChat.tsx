import { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Loader2, Clock, ArrowLeft } from 'lucide-react';
import { LiveAvatarSessionPlayer } from './LiveAvatarSessionPlayer';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/features/auth';

interface Transcript {
  id: string;
  speaker: 'user' | 'avatar';
  text: string;
  timestamp: number;
}

interface LiveChatProps {
  topicId: string;
  topicTitle: string;
  voiceId?: string;
  category: 'mental_health' | 'life_coaching' | 'business' | 'relationships';
  onClose: () => void;
  maxDuration?: number;
}

export function LiveChat({ 
  topicId, 
  topicTitle, 
  category, 
  onClose,
  maxDuration 
}: LiveChatProps) {
  const { user } = useAuth();
  const [transcripts, setTranscripts] = useState<Transcript[]>([]);
  const [sessionDuration, setSessionDuration] = useState(0);
  const [showEndConfirm, setShowEndConfirm] = useState(false);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const transcriptEndRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Load user profile for avatar settings
  useEffect(() => {
    const loadProfile = async () => {
      if (!user) return;
      
      const { data } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (data) {
        setUserProfile(data);
      }
    };
    
    loadProfile();
  }, [user]);

  const handleTranscription = useCallback((text: string, speaker: 'user' | 'avatar') => {
    const newTranscript: Transcript = {
      id: crypto.randomUUID(),
      speaker,
      text,
      timestamp: Date.now()
    };
    
    setTranscripts(prev => [...prev, newTranscript]);
    
    // Auto-scroll to latest
    setTimeout(() => {
      transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }, []);

  // Session timer
  useEffect(() => {
    if (sessionId) {
      timerRef.current = setInterval(() => {
        setSessionDuration(prev => prev + 1);
      }, 1000);
      
      return () => {
        if (timerRef.current) {
          clearInterval(timerRef.current);
        }
      };
    }
  }, [sessionId]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSessionEnd = useCallback(async () => {
    console.log('[LiveChat] Ending session...');
    setShowEndConfirm(false);
    
    try {
      // Save transcripts to database
      if (sessionId && transcripts.length > 0 && user) {
        await supabase.from('live_session_transcripts').insert(
          transcripts.map((t, index) => ({
            session_id: sessionId,
            user_id: user.id,
            speaker: t.speaker,
            content: t.text,
            timestamp_offset_ms: t.timestamp,
            turn_index: index
          }))
        );
      }
      
      // Close the component
      onClose();
    } catch (error) {
      console.error('[LiveChat] Error ending session:', error);
      // Still close even if there's an error
      onClose();
    }
  }, [sessionId, transcripts, onClose, user]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  if (!userProfile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => setShowEndConfirm(true)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold">{topicTitle}</h1>
              <p className="text-sm text-muted-foreground">Live Session</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Clock className="w-4 h-4" />
              {formatTime(sessionDuration)}
            </div>
            
            <Button
              variant="destructive"
              onClick={() => setShowEndConfirm(true)}
              className="gap-2"
            >
              End Call
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 container mx-auto px-4 py-6 grid lg:grid-cols-3 gap-6">
        {/* Video Display - Using Unified Player */}
        <div className="lg:col-span-2">
          <LiveAvatarSessionPlayer
            avatarId={userProfile?.liveavatar_id || '1c690fe7-23e0-49f9-bfba-14344450285b'}
            category={category}
            language={userProfile?.avatar_language || 'en-US'}
            maxDuration={maxDuration}
            showControls={true}
            showTimer={false}
            autoStart={true}
            onSessionEnd={handleSessionEnd}
            onError={(error) => {
              console.error('[LiveChat] Player error:', error, 'avatarId:', userProfile?.liveavatar_id);
            }}
          />
        </div>

        {/* Transcript Sidebar */}
        <div className="lg:col-span-1">
          <Card className="h-full flex flex-col">
            <div className="p-4 border-b">
              <h2 className="font-semibold">Conversation</h2>
              <p className="text-sm text-muted-foreground">Real-time transcript</p>
            </div>
            
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {transcripts.length === 0 && (
                  <div className="text-center text-muted-foreground text-sm py-8">
                    Start speaking to begin the conversation...
                  </div>
                )}
                
                {transcripts.map((t) => (
                  <div
                    key={t.id}
                    className={`flex ${t.speaker === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[85%] p-3 rounded-lg ${
                        t.speaker === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <p className="text-xs font-medium mb-1 opacity-70">
                        {t.speaker === 'user' ? 'You' : 'AI Coach'}
                      </p>
                      <p className="text-sm">{t.text}</p>
                    </div>
                  </div>
                ))}
                <div ref={transcriptEndRef} />
              </div>
            </ScrollArea>
          </Card>
        </div>
      </div>

      {/* End Session Confirmation Dialog */}
      <AlertDialog open={showEndConfirm} onOpenChange={setShowEndConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>End Live Session?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to end this session? Your conversation transcript will be saved.
              <div className="mt-3 text-sm font-medium">
                Session duration: {formatTime(sessionDuration)}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Continue Session</AlertDialogCancel>
            <AlertDialogAction onClick={handleSessionEnd} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              End Session
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
