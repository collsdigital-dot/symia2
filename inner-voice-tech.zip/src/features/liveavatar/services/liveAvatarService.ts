import { supabase } from '@/integrations/supabase/client';
import { AvatarOption } from '@/core/config/avatarConfig';

// Enhanced fallback avatars in case API fails
// These are known working LiveAvatar IDs from HeyGen's platform
const FALLBACK_AVATARS: AvatarOption[] = [
  {
    id: '1c690fe7-23e0-49f9-bfba-14344450285b',
    name: 'Monica',
    gender: 'female',
    thumbnail: 'https://files.heygen.ai/avatar/v3/1c690fe7-23e0-49f9-bfba-14344450285b/0_cropped.webp',
    description: 'Professional female avatar - warm and approachable',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE', 'it-IT', 'pt-BR', 'zh-CN', 'ja-JP'],
    defaultVoiceId: undefined
  },
  {
    id: 'a8b281ee94c84b9384d8cbaf19eb0e2f',
    name: 'Eric',
    gender: 'male',
    thumbnail: 'https://files.heygen.ai/avatar/v3/a8b281ee94c84b9384d8cbaf19eb0e2f/0_cropped.webp',
    description: 'Professional male avatar - confident and friendly',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE', 'it-IT', 'pt-BR', 'zh-CN', 'ja-JP'],
    defaultVoiceId: undefined
  },
  {
    id: 'josh_lite3_20230714',
    name: 'Josh',
    gender: 'male',
    thumbnail: 'https://files.heygen.ai/avatar/v3/josh_lite3_20230714/0_cropped.webp',
    description: 'Casual male avatar - relaxed and engaging',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE', 'it-IT'],
    defaultVoiceId: undefined
  },
  {
    id: 'anna_costume1_cameraA_20220812',
    name: 'Anna',
    gender: 'female',
    thumbnail: 'https://files.heygen.ai/avatar/v3/anna_costume1_cameraA_20220812/0_cropped.webp',
    description: 'Elegant female avatar - professional and articulate',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE', 'it-IT', 'pt-BR'],
    defaultVoiceId: undefined
  },
  {
    id: 'Wayne_20240711',
    name: 'Wayne',
    gender: 'male',
    thumbnail: 'https://files.heygen.ai/avatar/v3/Wayne_20240711/0_cropped.webp',
    description: 'Mature male avatar - experienced and trustworthy',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE'],
    defaultVoiceId: undefined
  },
  {
    id: 'Susan_public_3_20240328',
    name: 'Susan',
    gender: 'female',
    thumbnail: 'https://files.heygen.ai/avatar/v3/Susan_public_3_20240328/0_cropped.webp',
    description: 'Friendly female avatar - supportive and caring',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE', 'it-IT'],
    defaultVoiceId: undefined
  },
  {
    id: 'Tyler-insuit-20220721',
    name: 'Tyler',
    gender: 'male',
    thumbnail: 'https://files.heygen.ai/avatar/v3/Tyler-insuit-20220721/0_cropped.webp',
    description: 'Business male avatar - professional and polished',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE'],
    defaultVoiceId: undefined
  },
  {
    id: 'Angela-inblackskirt-20220820',
    name: 'Angela',
    gender: 'female',
    thumbnail: 'https://files.heygen.ai/avatar/v3/Angela-inblackskirt-20220820/0_cropped.webp',
    description: 'Modern female avatar - dynamic and professional',
    supportedLanguages: ['en-US', 'es-ES', 'fr-FR', 'de-DE', 'it-IT', 'pt-BR'],
    defaultVoiceId: undefined
  }
];

// Track if we're using fallback avatars
let usingFallbackAvatars = false;

/**
 * Fetch available LiveAvatar avatars from the platform
 */
export async function fetchLiveAvatars(): Promise<AvatarOption[]> {
  try {
    console.log('[fetchLiveAvatars] Fetching avatars from API...');
    
    const { data, error } = await supabase.functions.invoke('liveavatar-options', {
      body: { type: 'avatars', page: 1, pageSize: 100 }
    });

    if (error) {
      console.error('[fetchLiveAvatars] Error fetching avatars:', error);
      console.warn('[fetchLiveAvatars] Using enhanced fallback avatars');
      usingFallbackAvatars = true;
      return FALLBACK_AVATARS;
    }

    if (!data?.success || !data?.data?.results) {
      console.warn('[fetchLiveAvatars] Invalid response format or empty results, using fallback');
      console.log('[fetchLiveAvatars] API response:', data);
      usingFallbackAvatars = true;
      return FALLBACK_AVATARS;
    }

    const results = data.data.results;
    
    if (results.length === 0) {
      console.warn('[fetchLiveAvatars] API returned 0 avatars, using enhanced fallback list');
      usingFallbackAvatars = true;
      return FALLBACK_AVATARS;
    }

    console.log('[fetchLiveAvatars] ✓ API returned', results.length, 'avatars');
    usingFallbackAvatars = false;

    const avatars: AvatarOption[] = results.map((avatar: any) => ({
      id: avatar.id || avatar.avatar_id,
      name: avatar.name || avatar.avatar_name || `Avatar ${(avatar.id || avatar.avatar_id).substring(0, 8)}`,
      gender: avatar.gender || 'unspecified',
      thumbnail: avatar.preview_image_url || avatar.thumbnail_url || avatar.preview_url || '',
      description: avatar.description || 'Interactive avatar',
      supportedLanguages: avatar.supported_languages || ['en-US'],
      defaultVoiceId: avatar.default_voice_id
    }));

    console.log('[fetchLiveAvatars] Successfully mapped', avatars.length, 'avatars');
    return avatars;

  } catch (error) {
    console.error('[fetchLiveAvatars] Exception:', error);
    console.warn('[fetchLiveAvatars] Using enhanced fallback avatars');
    usingFallbackAvatars = true;
    return FALLBACK_AVATARS;
  }
}

/**
 * Check if fallback avatars are being used
 */
export function isUsingFallbackAvatars(): boolean {
  return usingFallbackAvatars;
}

/**
 * Helper function to get avatar thumbnail URL
 */
export function getAvatarThumbnail(avatars: AvatarOption[], avatarId: string): string {
  const avatar = avatars.find(a => a.id === avatarId);
  return avatar?.thumbnail || '';
}

/**
 * Helper function to get avatar name
 */
export function getAvatarName(avatars: AvatarOption[], avatarId: string): string {
  const avatar = avatars.find(a => a.id === avatarId);
  return avatar?.name || 'Avatar';
}
