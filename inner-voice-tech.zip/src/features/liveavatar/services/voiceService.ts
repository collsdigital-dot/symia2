import { supabase } from '@/integrations/supabase/client';

export interface VoiceOption {
  id: string;
  name: string;
  gender: 'male' | 'female';
  language: string;
  description?: string;
}

// Fallback voices in case API fails
const FALLBACK_VOICES: VoiceOption[] = [
  {
    id: 'af28cadf-0000-0000-0000-9a8e17ef3eef',
    name: 'English Female',
    gender: 'female',
    language: 'en-US',
    description: 'Professional English voice'
  },
  {
    id: 'bf28cadf-0000-0000-0000-9a8e17ef3eef',
    name: 'English Male',
    gender: 'male',
    language: 'en-US',
    description: 'Professional English voice'
  }
];

/**
 * Fetch available LiveAvatar voices from the platform
 */
export async function fetchLiveVoices(): Promise<VoiceOption[]> {
  try {
    console.log('[VoiceService] Fetching voices from LiveAvatar API...');
    
    const { data, error } = await supabase.functions.invoke('liveavatar-options', {
      body: { type: 'voices', page: 1, pageSize: 100 }
    });

    if (error) {
      console.error('[VoiceService] Edge function error:', error);
      throw error;
    }

    if (!data?.success || !data?.data?.results) {
      console.error('[VoiceService] Invalid response:', data);
      throw new Error('Invalid response from LiveAvatar API');
    }

    // Map API response to VoiceOption format
    const results = data.data.results;
    const voices: VoiceOption[] = results.map((voice: any) => ({
      id: voice.voice_id || voice.id,
      name: voice.display_name || voice.name || `Voice ${voice.voice_id?.substring(0, 8)}`,
      gender: voice.gender || 'female',
      language: voice.language || 'en-US',
      description: voice.preview_text || voice.description || 'Professional voice'
    }));

    console.log(`[VoiceService] Successfully fetched ${voices.length} voices`);
    return voices;
    
  } catch (error) {
    console.error('[VoiceService] Error fetching voices, using fallback:', error);
    // Return fallback voices instead of throwing
    return FALLBACK_VOICES;
  }
}

/**
 * Helper function to get voice name
 */
export function getVoiceName(voices: VoiceOption[], voiceId: string): string {
  const voice = voices.find(v => v.id === voiceId);
  return voice?.name || 'Default Voice';
}

/**
 * Helper function to filter voices by language
 */
export function getVoicesByLanguage(voices: VoiceOption[], language: string): VoiceOption[] {
  return voices.filter(v => v.language.startsWith(language.split('-')[0]));
}
