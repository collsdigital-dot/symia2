import { useEffect, useState } from "react";

interface AIAvatarProps {
  isSpeaking: boolean;
  heygenAvatarId?: string;
  size?: 'small' | 'medium' | 'large';
}

// Fallback thumbnail for any avatar
const DEFAULT_THUMBNAIL = '/avatars/deborah.png';

export function AIAvatar({ isSpeaking, heygenAvatarId, size = 'medium' }: AIAvatarProps) {
  const [scale, setScale] = useState(1);

  const sizeClasses = {
    small: { container: 'w-16 h-16', avatar: 'w-14 h-14' },
    medium: { container: 'w-40 h-40', avatar: 'w-36 h-36' },
    large: { container: 'w-64 h-64', avatar: 'w-60 h-60' }
  };

  useEffect(() => {
    if (isSpeaking) {
      const interval = setInterval(() => {
        setScale(prev => prev === 1 ? 1.1 : 1);
      }, 500);
      return () => clearInterval(interval);
    } else {
      setScale(1);
    }
  }, [isSpeaking]);

  // Use default thumbnail - actual avatar is shown in live video
  const avatarImage = DEFAULT_THUMBNAIL;

  return (
    <div className={`relative ${sizeClasses[size].container} flex items-center justify-center shrink-0`}>
      <div 
        className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/30 to-secondary/30 blur-md"
        style={{
          transform: `scale(${scale})`,
          transition: 'transform 0.3s ease-in-out',
        }}
      />
      <div className={`relative z-10 ${sizeClasses[size].avatar} rounded-full overflow-hidden shadow-glow`}>
        <img
          src={avatarImage}
          alt="AI Coach"
          className="w-full h-full object-cover"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
            e.currentTarget.parentElement!.innerHTML = '<div class="w-full h-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold">AB</div>';
          }}
        />
      </div>
      {isSpeaking && (
        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: '150ms' }} />
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: '300ms' }} />
        </div>
      )}
    </div>
  );
}