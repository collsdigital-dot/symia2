import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, ArrowLeft, Video } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/features/auth/hooks";
import { useToast } from "@/hooks/use-toast";
import { ChatMessage } from "./ChatMessage";
import { VoiceRecorder } from "./VoiceRecorder";
import { AIAvatar } from "./AIAvatar";

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface ChatInterfaceProps {
  topic: string;
  conversationId?: string;
  onBack: () => void;
}

export function ChatInterface({ topic, conversationId, onBack }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState(conversationId);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [hasIncrementedUsage, setHasIncrementedUsage] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadUserProfile();
    if (currentConversationId) {
      loadMessages();
    }
  }, [currentConversationId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const loadUserProfile = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("user_profiles")
      .select("*")
      .eq("user_id", user.id)
      .single();
    setUserProfile(data);
  };

  const loadMessages = async () => {
    if (!currentConversationId) return;
    const { data } = await supabase
      .from("chat_messages")
      .select("*")
      .eq("conversation_id", currentConversationId)
      .order("created_at", { ascending: true });
    
    if (data) {
      setMessages(data.map(m => ({ role: m.role as "user" | "assistant", content: m.content })));
    }
  };

  const createConversation = async () => {
    if (!user) return null;
    const { data, error } = await supabase
      .from("chat_conversations")
      .insert({ user_id: user.id, topic })
      .select()
      .single();
    
    if (error) throw error;
    return data.id;
  };

  const saveMessage = async (role: "user" | "assistant", content: string, convId: string) => {
    await supabase
      .from("chat_messages")
      .insert({
        conversation_id: convId,
        role,
        content,
      });
  };

  const sendMessage = async () => {
    if (!input.trim() || loading || !user) return;

    const userMessage: Message = { role: "user", content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      let convId = currentConversationId;
      if (!convId) {
        convId = await createConversation();
        setCurrentConversationId(convId);
      }

      if (convId) {
        await saveMessage("user", userMessage.content, convId);
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            messages: newMessages,
            userProfile,
          }),
        }
      );

      if (!response.ok || !response.body) {
        throw new Error("Failed to get response");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let assistantMessage = "";
      let textBuffer = "";

      setMessages(prev => [...prev, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        textBuffer += decoder.decode(value, { stream: true });
        let newlineIndex: number;

        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);

          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              assistantMessage += content;
              setMessages(prev => {
                const updated = [...prev];
                updated[updated.length - 1] = { role: "assistant", content: assistantMessage };
                return updated;
              });
            }
          } catch (e) {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }

      if (convId && assistantMessage) {
        await saveMessage("assistant", assistantMessage, convId);
        
        // Increment usage only after first successful message exchange
        if (!hasIncrementedUsage) {
          try {
            await supabase.functions.invoke('increment-usage', {
              body: { feature: 'text_chat' }
            });
            setHasIncrementedUsage(true);
            console.log('[ChatInterface] Usage incremented after first message');
          } catch (error) {
            console.error('[ChatInterface] Error incrementing usage:', error);
          }
        }
        
        await playAudioResponse(assistantMessage);
      }
    } catch (error) {
      console.error("Chat error:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
      setMessages(newMessages);
    } finally {
      setLoading(false);
    }
  };

  const playAudioResponse = async (text: string) => {
    try {
      setIsSpeaking(true);
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/text-to-speech`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ text }),
        }
      );

      if (!response.ok) throw new Error('Failed to generate speech');

      const data = await response.json();
      const audioBlob = new Blob(
        [Uint8Array.from(atob(data.audioContent), c => c.charCodeAt(0))],
        { type: 'audio/mp3' }
      );
      const audioUrl = URL.createObjectURL(audioBlob);
      
      if (audioRef.current) {
        audioRef.current.src = audioUrl;
        audioRef.current.onended = () => setIsSpeaking(false);
        await audioRef.current.play();
      }
    } catch (error) {
      console.error('Error playing audio:', error);
      setIsSpeaking(false);
    }
  };

  const handleVoiceTranscription = (text: string) => {
    setInput(text);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleGoLive = async () => {
    try {
      // Ensure conversation exists
      let convId = currentConversationId;
      if (!convId) {
        convId = await createConversation();
        setCurrentConversationId(convId);
      }

      if (!convId) {
        toast({
          title: "Error",
          description: "Could not create conversation",
          variant: "destructive",
        });
        return;
      }

      // Navigate to live chat with conversation context
      navigate(`/live?trackId=${encodeURIComponent(topic)}&trackTitle=${encodeURIComponent(topic)}&conversationId=${convId}`);
    } catch (error) {
      console.error('Error starting live session:', error);
      toast({
        title: "Error",
        description: "Failed to start live session",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-2rem)] max-w-4xl mx-auto relative">
      <audio ref={audioRef} className="hidden" />
      <Card className="flex-1 flex flex-col backdrop-blur-sm bg-card/95 shadow-soft">
        <div className="p-4 border-b flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <AIAvatar isSpeaking={isSpeaking} />
          <div className="flex-1">
            <h2 className="font-semibold">{topic}</h2>
            <p className="text-sm text-muted-foreground">
              {userProfile?.full_name ? `Chat with your AI companion` : "Loading..."}
            </p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-muted-foreground py-12">
              <p className="text-lg mb-2">👋 Hi {userProfile?.full_name}!</p>
              <p>How can I support you today?</p>
            </div>
          )}
          
          {messages.map((message, index) => (
            <ChatMessage key={index} message={message} />
          ))}
          
          {loading && messages[messages.length - 1]?.role === "user" && (
            <div className="flex gap-2 items-center text-muted-foreground">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-100" />
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-200" />
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t">
          <div className="flex gap-2 mb-2">
            <Button
              onClick={handleGoLive}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Video className="w-4 h-4" />
              Go Live
            </Button>
          </div>
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Type your message or use voice..."
              className="min-h-[60px] resize-none"
              disabled={loading}
            />
            <div className="flex flex-col gap-2">
              <VoiceRecorder onTranscription={handleVoiceTranscription} disabled={loading} />
              <Button
                onClick={sendMessage}
                disabled={!input.trim() || loading}
                size="icon"
                className="shrink-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}