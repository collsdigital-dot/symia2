import { supabase } from "@/integrations/supabase/client";
import { authRepository } from "../data/authRepository";
import { AppRole } from "@/core/types/auth";

/**
 * Authentication service - handles business logic for auth operations
 */
export const authService = {
  /**
   * Sign in with email OTP
   */
  async signInWithOtp(email: string, redirectUrl?: string) {
    const { error } = await supabase.auth.signInWithOtp({
      email: email.trim(),
      options: {
        shouldCreateUser: true,
        emailRedirectTo: redirectUrl || `${window.location.origin}/dashboard`
      }
    });

    if (error) throw error;
  },

  /**
   * Sign in with OAuth provider
   */
  async signInWithOAuth(provider: 'google' | 'facebook' | 'apple', redirectUrl?: string) {
    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: redirectUrl || `${window.location.origin}/dashboard`
      }
    });

    if (error) {
      if (error.message.includes('not enabled')) {
        throw new Error(`${provider.charAt(0).toUpperCase() + provider.slice(1)} sign-in is not enabled.`);
      }
      throw error;
    }
  },

  /**
   * Sign out current user
   */
  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  /**
   * Get current session
   */
  async getSession() {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) throw error;
    return session;
  },

  /**
   * Get user's role with subscription tier
   */
  async getUserWithRole(userId: string) {
    const [role, tier] = await Promise.all([
      authRepository.getUserRole(userId),
      authRepository.getSubscriptionTier(userId),
    ]);

    return { role, tier };
  },

  /**
   * Validate email format
   */
  validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },
};
