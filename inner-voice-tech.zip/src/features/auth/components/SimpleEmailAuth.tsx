import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Mail } from "lucide-react";

interface SimpleEmailAuthProps {
  onComplete?: (email: string) => void;
  mode?: 'signin' | 'signup';
}

export function SimpleEmailAuth({ onComplete, mode = 'signin' }: SimpleEmailAuthProps) {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleContinue = async () => {
    if (!validateEmail(email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    try {
      const emailRedirectTo = mode === 'signup' 
        ? `${window.location.origin}/?resumeFunnel=true`
        : `${window.location.origin}/dashboard`;

      const { error } = await supabase.auth.signInWithOtp({
        email: email.trim(),
        options: {
          shouldCreateUser: true,
          emailRedirectTo
        }
      });

      if (error) throw error;

      toast({
        title: "Check your email!",
        description: "We've sent you a magic link to sign in.",
      });

      if (onComplete) {
        onComplete(email);
      }
    } catch (error: any) {
      console.error("Auth error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to sign in",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="relative">
          <Mail className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleContinue()}
            className="pl-10"
            disabled={loading}
          />
        </div>
      </div>

      <Button
        onClick={handleContinue}
        disabled={loading || !email}
        className="w-full"
      >
        {loading ? "Signing in..." : "Continue"}
      </Button>
    </div>
  );
}
