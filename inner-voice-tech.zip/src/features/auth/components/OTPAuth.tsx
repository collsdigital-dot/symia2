import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Loader2, Mail, CheckCircle2 } from "lucide-react";

interface OTPAuthProps {
  onComplete?: (email: string) => void;
  mode?: "signin" | "signup";
}

export function OTPAuth({ onComplete, mode = "signin" }: OTPAuthProps) {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"email" | "otp">("email");
  const [loading, setLoading] = useState(false);
  const [resendCountdown, setResendCountdown] = useState(0);
  const { toast } = useToast();

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSendOTP = async () => {
    if (!validateEmail(email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      console.log('[OTPAuth] Invoking send-otp-email', { email: email.toLowerCase() });
      const { data, error } = await supabase.functions.invoke('send-otp-email', {
        body: { email: email.toLowerCase() }
      });
      console.log('[OTPAuth] send-otp-email response', { data, error });

      if (error) throw error;

      toast({
        title: "Code sent!",
        description: "Check your email for the verification code",
      });

      setStep("otp");
      setResendCountdown(60);
      
      // Start countdown timer
      const interval = setInterval(() => {
        setResendCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (error: any) {
      console.error("[OTPAuth] Error sending OTP:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to send verification code",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) {
      toast({
        title: "Invalid code",
        description: "Please enter the 6-digit code",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('verify-otp', {
        body: { 
          email: email.toLowerCase(),
          otp: otp 
        }
      });

      if (error) throw error;
      if (!data?.hashed_token) throw new Error('No token received');

      const { error: verifyError } = await supabase.auth.verifyOtp({
        type: 'email',
        token_hash: data.hashed_token,
        email: email.toLowerCase()
      });

      if (verifyError) throw verifyError;

      toast({
        title: "Success!",
        description: "You're now signed in",
      });

      onComplete?.(email);
    } catch (error: any) {
      console.error("Error verifying OTP:", error);
      toast({
        title: "Verification failed",
        description: error.message || "Invalid or expired code",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };


  const handleResend = () => {
    if (resendCountdown > 0) return;
    setOtp("");
    handleSendOTP();
  };

  const handleBack = () => {
    setStep("email");
    setOtp("");
  };

  if (step === "email") {
    return (
      <div className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="email" className="text-sm font-medium">
            Email address
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendOTP()}
              className="pl-10"
              disabled={loading}
            />
          </div>
        </div>

        <Button
          onClick={handleSendOTP}
          disabled={loading || !email}
          className="w-full"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending code...
            </>
          ) : (
            <>
              <Mail className="mr-2 h-4 w-4" />
              Send verification code
            </>
          )}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          We'll send a 6-digit code to your email
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2 text-center">
        <div className="flex justify-center mb-4">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
            <Mail className="h-6 w-6 text-primary" />
          </div>
        </div>
        <h3 className="font-semibold text-lg">Check your email</h3>
        <p className="text-sm text-muted-foreground">
          We sent a code to <span className="font-medium text-foreground">{email}</span>
        </p>
      </div>

      <div className="space-y-4">
        <div className="flex justify-center">
          <InputOTP
            maxLength={6}
            value={otp}
            onChange={setOtp}
            disabled={loading}
          >
            <InputOTPGroup>
              <InputOTPSlot index={0} />
              <InputOTPSlot index={1} />
              <InputOTPSlot index={2} />
              <InputOTPSlot index={3} />
              <InputOTPSlot index={4} />
              <InputOTPSlot index={5} />
            </InputOTPGroup>
          </InputOTP>
        </div>

        <Button
          onClick={handleVerifyOTP}
          disabled={loading || otp.length !== 6}
          className="w-full"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Verifying...
            </>
          ) : (
            <>
              <CheckCircle2 className="mr-2 h-4 w-4" />
              Verify code
            </>
          )}
        </Button>

        <div className="flex items-center justify-between text-sm">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBack}
            disabled={loading}
          >
            Change email
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleResend}
            disabled={loading || resendCountdown > 0}
          >
            {resendCountdown > 0
              ? `Resend in ${resendCountdown}s`
              : "Resend code"}
          </Button>
        </div>
      </div>
    </div>
  );
}
