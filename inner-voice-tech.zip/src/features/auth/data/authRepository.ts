import { supabase } from "@/integrations/supabase/client";
import { AppRole, SubscriptionTier } from "@/core/types/auth";

/**
 * Auth repository - handles database queries for authentication
 */
export const authRepository = {
  /**
   * Get user's operational role
   */
  async getUserRole(userId: string): Promise<AppRole> {
    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .order('role', { ascending: true })
      .limit(1)
      .maybeSingle();
    
    return data?.role || 'user';
  },

  /**
   * Get user's subscription tier
   */
  async getSubscriptionTier(userId: string): Promise<SubscriptionTier> {
    const { data } = await supabase
      .from('usage_limits')
      .select('subscription_tier')
      .eq('user_id', userId)
      .maybeSingle();
    
    return data?.subscription_tier || 'free';
  },

  /**
   * Assign role to user (admin only)
   */
  async assignRole(userId: string, role: AppRole) {
    const { error } = await supabase
      .from('user_roles')
      .insert({ user_id: userId, role });
    
    if (error) throw error;
  },

  /**
   * Check if user has profile
   */
  async hasProfile(userId: string): Promise<boolean> {
    const { data } = await supabase
      .from('user_profiles')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle();
    
    return !!data;
  },

  /**
   * Get all user roles (for role checks)
   */
  async getUserRoles(userId: string): Promise<AppRole[]> {
    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId);
    
    return data?.map(r => r.role) || [];
  },
};
