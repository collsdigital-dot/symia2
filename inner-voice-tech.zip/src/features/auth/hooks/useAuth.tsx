import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { AuthContextType, AuthUser, AppRole, SubscriptionTier } from "@/core/types/auth";

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [subscriptionTier, setSubscriptionTier] = useState<SubscriptionTier | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchUserRole = async (userId: string): Promise<AppRole> => {
    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .order('role', { ascending: true })
      .limit(1)
      .maybeSingle();
    
    return data?.role || 'user';
  };

  const fetchSubscriptionTier = async (userId: string): Promise<SubscriptionTier> => {
    const { data } = await supabase
      .from('usage_limits')
      .select('subscription_tier')
      .eq('user_id', userId)
      .maybeSingle();
    
    return data?.subscription_tier || 'free';
  };

  const refreshRole = async () => {
    if (user) {
      const userRole = await fetchUserRole(user.id);
      setRole(userRole);
    }
  };

  const refreshSubscription = async () => {
    if (user) {
      const tier = await fetchSubscriptionTier(user.id);
      setSubscriptionTier(tier);
    }
  };

  useEffect(() => {
    console.log('[useAuth] Initializing auth...');

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log('[useAuth] Auth state changed:', event, session?.user?.id);
      setSession(session);

      const authUser = session?.user ?? null;

      if (authUser) {
        // Set quick defaults so the app can proceed
        setUser({ ...authUser, role: 'user', subscriptionTier: 'free' });
        setRole('user');
        setSubscriptionTier('free');
        setLoading(false);

        // Defer extra fetches to avoid blocking the auth flow
        setTimeout(() => {
          Promise.all([
            fetchUserRole(authUser.id).catch(() => 'user' as AppRole),
            fetchSubscriptionTier(authUser.id).catch(() => 'free' as SubscriptionTier),
          ]).then(([userRole, tier]) => {
            console.log('[useAuth] Deferred role/tier:', userRole, tier);
            setRole(userRole);
            setSubscriptionTier(tier);
            setUser(prev => prev ? { ...prev, role: userRole, subscriptionTier: tier } : prev);
          });
        }, 0);
      } else {
        console.log('[useAuth] No user, clearing state');
        setUser(null);
        setRole(null);
        setSubscriptionTier(null);
        setLoading(false);
      }
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('[useAuth] Initial session:', session?.user?.id);
      setSession(session);
      const authUser = session?.user ?? null;

      if (authUser) {
        // Same fast-path defaults
        setUser({ ...authUser, role: 'user', subscriptionTier: 'free' });
        setRole('user');
        setSubscriptionTier('free');
        setLoading(false);

        setTimeout(() => {
          Promise.all([
            fetchUserRole(authUser.id).catch(() => 'user' as AppRole),
            fetchSubscriptionTier(authUser.id).catch(() => 'free' as SubscriptionTier),
          ]).then(([userRole, tier]) => {
            console.log('[useAuth] Initial deferred role/tier:', userRole, tier);
            setRole(userRole);
            setSubscriptionTier(tier);
            setUser(prev => prev ? { ...prev, role: userRole, subscriptionTier: tier } : prev);
          });
        }, 0);
      } else {
        setLoading(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setRole(null);
    setSubscriptionTier(null);
    navigate("/");
  };

  const isAdmin = role === 'admin';
  const isModerator = role === 'moderator' || role === 'admin';
  const isFreeUser = subscriptionTier === 'free';
  const isPremiumUser = subscriptionTier === 'premium';

  const value: AuthContextType = {
    session, 
    user, 
    role, 
    subscriptionTier,
    loading, 
    isAdmin, 
    isModerator, 
    isFreeUser,
    isPremiumUser,
    signOut, 
    refreshRole,
    refreshSubscription,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
