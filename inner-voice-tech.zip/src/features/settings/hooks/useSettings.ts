import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { UserProfile, AvatarConfig } from '../types';

export function useSettings(userId: string | undefined) {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    loadSettings();
  }, [userId]);

  const loadSettings = async () => {
    if (!userId) return;

    setLoading(true);
    await Promise.all([
      loadProfile(),
      loadAvatarConfig(),
    ]);
    setLoading(false);
  };

  const loadProfile = async () => {
    if (!userId) return;

    const { data } = await supabase
      .from("user_profiles")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();

    setUserProfile(data as UserProfile | null);
  };

  const loadAvatarConfig = async () => {
    if (!userId) return;

    const { data } = await supabase
      .from("user_avatars")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();

    setAvatarConfig(data as AvatarConfig | null);
  };

  return {
    userProfile,
    avatarConfig,
    loading,
    refreshProfile: loadProfile,
    refreshAvatarConfig: loadAvatarConfig,
  };
}
