import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Check, Loader2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/features/auth/hooks";
import { BackgroundUploader } from "./BackgroundUploader";

interface BackgroundSettingsProps {
  profile: any;
  onUpdate: () => void;
}

const PRESET_COLORS = [
  { name: "Warm Beige", value: "#F5F5DC" },
  { name: "Soft Blue", value: "#E6F3FF" },
  { name: "Mint Green", value: "#E8F5E9" },
  { name: "Lavender", value: "#F3E5F5" },
  { name: "Peach", value: "#FFE5DB" },
  { name: "Sky Blue", value: "#B3E5FC" },
];

export function BackgroundSettings({ profile, onUpdate }: BackgroundSettingsProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedBackground, setSelectedBackground] = useState<any>(
    profile?.video_background || { type: "color", value: "#F5F5DC" }
  );
  const [uploadedBackgrounds, setUploadedBackgrounds] = useState<string[]>([]);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    loadUploadedBackgrounds();
  }, [user]);

  const loadUploadedBackgrounds = async () => {
    if (!user) return;

    const { data, error } = await supabase.storage
      .from('custom-backgrounds')
      .list(user.id, {
        limit: 50,
        sortBy: { column: 'created_at', order: 'desc' }
      });

    if (error) {
      console.error("Error loading backgrounds:", error);
      return;
    }

    const urls = data.map(file => {
      const { data: publicUrlData } = supabase.storage
        .from('custom-backgrounds')
        .getPublicUrl(`${user.id}/${file.name}`);
      return publicUrlData.publicUrl;
    });

    setUploadedBackgrounds(urls);
  };

  const handleSaveBackground = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from("user_profiles")
        .update({ video_background: selectedBackground })
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Video background updated successfully",
      });
      onUpdate();
    } catch (error) {
      console.error("Error updating background:", error);
      toast({
        title: "Error",
        description: "Failed to update background",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteBackground = async (url: string) => {
    if (!user) return;

    // Extract file path from URL
    const urlParts = url.split('/');
    const fileName = urlParts[urlParts.length - 1];
    const filePath = `${user.id}/${fileName}`;

    const { error } = await supabase.storage
      .from('custom-backgrounds')
      .remove([filePath]);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to delete background",
        variant: "destructive",
      });
      return;
    }

    // If the deleted background was selected, reset to default
    if (selectedBackground.type === "image" && selectedBackground.url === url) {
      setSelectedBackground({ type: "color", value: "#F5F5DC" });
    }

    toast({
      title: "Success",
      description: "Background deleted",
    });

    loadUploadedBackgrounds();
  };

  const handleUploadComplete = (url: string) => {
    setSelectedBackground({ type: "image", url });
    loadUploadedBackgrounds();
  };

  const isSelected = (type: string, value: string) => {
    return selectedBackground.type === type && 
           (type === "color" ? selectedBackground.value === value : selectedBackground.url === value);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-semibold mb-2">Video Background</h3>
            <p className="text-sm text-muted-foreground">
              Customize the background for your AI avatar in category introductions and chat videos. Note: Live sessions may use a standard background due to technical limitations.
            </p>
          </div>

          {/* Preview Section */}
          {selectedBackground && (
            <div className="space-y-2">
              <Label>Preview</Label>
              <div 
                className="w-full h-32 rounded-lg border-2 border-border flex items-center justify-center text-sm text-muted-foreground"
                style={{
                  background: selectedBackground.type === 'color' 
                    ? selectedBackground.value 
                    : `url(${selectedBackground.value || selectedBackground.url}) center/cover`
                }}
              >
                Your avatar will appear here
              </div>
            </div>
          )}

          {/* Preset Colors */}
          <div className="space-y-3">
            <Label>Preset Colors</Label>
            <div className="grid grid-cols-3 gap-3">
              {PRESET_COLORS.map((color, index) => (
                <div key={color.value} className="relative">
                  {index === 0 && (
                    <span className="absolute -top-2 -right-2 z-10 text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                      Default
                    </span>
                  )}
                  <button
                    onClick={() => setSelectedBackground({ type: "color", value: color.value })}
                    className={`relative w-full p-4 rounded-lg border-2 transition-all hover:scale-105 ${
                      isSelected("color", color.value) 
                        ? "border-primary shadow-glow" 
                        : "border-border hover:border-primary/50"
                    }`}
                    style={{ backgroundColor: color.value }}
                  >
                    {isSelected("color", color.value) && (
                      <div className="absolute top-2 right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-primary-foreground" />
                      </div>
                    )}
                    <p className="text-sm font-medium mt-8">{color.name}</p>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Uploaded Backgrounds */}
          {uploadedBackgrounds.length > 0 && (
            <div className="space-y-3">
              <Label>Your Uploaded Backgrounds</Label>
              <div className="grid grid-cols-2 gap-3">
                {uploadedBackgrounds.map((url) => (
                  <div key={url} className="relative group">
                    <button
                      onClick={() => setSelectedBackground({ type: "image", url })}
                      className={`relative w-full aspect-video rounded-lg border-2 overflow-hidden transition-all ${
                        isSelected("image", url)
                          ? "border-primary shadow-glow"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <img
                        src={url}
                        alt="Custom background"
                        className="w-full h-full object-cover"
                      />
                      {isSelected("image", url) && (
                        <div className="absolute top-2 right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                          <Check className="w-4 h-4 text-primary-foreground" />
                        </div>
                      )}
                    </button>
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteBackground(url);
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Save Button */}
          <Button
            onClick={handleSaveBackground}
            disabled={isLoading}
            className="w-full"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Background"
            )}
          </Button>
        </div>
      </Card>

      {/* Upload Component */}
      <BackgroundUploader onUploadComplete={handleUploadComplete} />
    </div>
  );
}