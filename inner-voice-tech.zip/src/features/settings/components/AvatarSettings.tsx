import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader, Lock, Search, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/features/auth/hooks";
import { useNavigate } from "react-router-dom";
import { useFunnelAvatars } from "@/hooks/useFunnelAvatars";
import { cn } from "@/lib/utils";

interface AvatarSettingsProps {
  avatarConfig: any;
  profile?: any;
  onUpdate: () => void;
}

export function AvatarSettings({ avatarConfig, profile, onUpdate }: AvatarSettingsProps) {
  const { data: avatars, isLoading: avatarsLoading } = useFunnelAvatars();
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const initialAvatarId = profile?.liveavatar_id 
    || avatarConfig?.config_json?.heygen_avatar_id 
    || (avatars?.[0]?.id || '1c690fe7-23e0-49f9-bfba-14344450285b');
  const [selectedAvatarId, setSelectedAvatarId] = useState(initialAvatarId);
  const [isPaidUser, setIsPaidUser] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    checkSubscription();
  }, [user]);

  const checkSubscription = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from('usage_limits')
      .select('subscription_tier')
      .eq('user_id', user.id)
      .single();
    
    setIsPaidUser(data?.subscription_tier !== 'free');
  };

  const handleSaveAvatar = async () => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      const selectedAvatar = avatars?.find(a => a.id === selectedAvatarId);
      
      console.log('Saving avatar:', selectedAvatarId, selectedAvatar?.name);
      
      // Update user_profiles (source of truth for live calls)
      const { error: profileError } = await supabase
        .from("user_profiles")
        .update({
          avatar_provider: 'heygen',
          liveavatar_id: selectedAvatarId,
        })
        .eq('user_id', user.id);

      if (profileError) {
        console.error('Profile update error:', profileError);
        throw profileError;
      }

      console.log('Profile updated successfully');

      // Also update user_avatars with thumbnail URL
      const { error: avatarError } = await supabase
        .from("user_avatars")
        .upsert({
          user_id: user.id,
          avatar_url: selectedAvatar?.thumbnail || null,
          avatar_type: 'heygen',
          status: 'default',
          config_json: {
            heygen_avatar_id: selectedAvatarId,
            avatar_name: selectedAvatar?.name
          }
        }, {
          onConflict: 'user_id'
        });

      if (avatarError) {
        console.error('Avatar config error:', avatarError);
        throw avatarError;
      }

      console.log('Avatar config updated successfully');

      toast({
        title: "Success",
        description: "Avatar updated successfully",
      });
      onUpdate();
    } catch (error) {
      console.error("Error updating avatar:", error);
      toast({
        title: "Error",
        description: "Failed to update avatar",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (avatarsLoading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center py-8">
          <Loader className="w-6 h-6 animate-spin" />
          <span className="ml-2">Loading avatars...</span>
        </div>
      </Card>
    );
  }

  const savedAvatarId = profile?.liveavatar_id || avatarConfig?.config_json?.heygen_avatar_id;
  const currentAvatar = avatars?.find(a => a.id === selectedAvatarId) 
    || (savedAvatarId && avatars?.find(a => a.id === savedAvatarId))
    || avatars?.[0];

  // Filter avatars based on search
  const filteredAvatars = avatars?.filter(avatar => 
    avatar.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div>
          <h3 className="text-2xl font-semibold mb-2">Your AI Avatar</h3>
          <p className="text-sm text-muted-foreground">
            Choose the avatar that will represent your AI wellness companion during live sessions.
          </p>
        </div>

        {/* Avatar Preview */}
        <div className="flex justify-center">
          <div className="relative w-48 h-48 rounded-lg overflow-hidden ring-4 ring-primary/20 shadow-glow transition-transform hover:scale-105">
            <img
              src={currentAvatar?.thumbnail || '/avatars/deborah.png'}
              alt="Selected Avatar"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-3">
              <p className="text-sm font-medium text-center">
                {currentAvatar?.name || 'Avatar'}
              </p>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search avatars..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Avatar Gallery Grid */}
        <div className="space-y-2">
          <p className="text-sm font-medium">Choose from {filteredAvatars.length} avatars</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[400px] overflow-y-auto p-1">
            {filteredAvatars.map((avatar) => (
              <button
                key={avatar.id}
                onClick={() => setSelectedAvatarId(avatar.id)}
                className={cn(
                  "relative group rounded-lg overflow-hidden transition-all",
                  "hover:scale-105 hover:shadow-lg",
                  selectedAvatarId === avatar.id 
                    ? "ring-4 ring-primary shadow-glow" 
                    : "ring-1 ring-border hover:ring-2 hover:ring-primary/50"
                )}
              >
                <div className="aspect-square">
                  <img
                    src={avatar.thumbnail || '/avatars/deborah.png'}
                    alt={avatar.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                  <p className="text-xs font-medium text-center w-full">
                    {avatar.name}
                  </p>
                </div>
                {selectedAvatarId === avatar.id && (
                  <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
                    <Check className="w-3 h-3" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Info Box */}
        <div className="p-4 bg-muted/50 rounded-lg">
          {isPaidUser ? (
            <p className="text-sm text-muted-foreground">
              💡 Choose from our collection of professional AI avatars for your live wellness sessions.
            </p>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-muted-foreground" />
                <p className="text-sm font-semibold">Full customization requires a paid subscription</p>
              </div>
              <p className="text-sm text-muted-foreground">
                Upgrade to unlock access to all HeyGen avatars and voices.
              </p>
            </div>
          )}
        </div>

        {/* Save Button */}
        <Button 
          onClick={handleSaveAvatar}
          disabled={isLoading || !selectedAvatarId}
          className="w-full"
        >
          {isLoading ? "Saving..." : "Save Avatar"}
        </Button>
        
        {/* Upgrade button for free users */}
        {!isPaidUser && (
          <Button 
            onClick={() => navigate('/pricing')}
            className="w-full"
            variant="outline"
          >
            Upgrade for More Features
          </Button>
        )}
      </div>
    </Card>
  );
}