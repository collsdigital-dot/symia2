import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Volume2 } from "lucide-react";

interface VoiceSelectorProps {
  value: string;
  onChange: (voice: string) => void;
}

const VOICES = [
  { id: '119caed25533477ba63822d5d1552d25', name: 'Emma', gender: 'female', description: 'Warm and friendly' },
  { id: '2d5b0e6c8f9a4d3c7b1e9f0a5c8d6b3a', name: 'Sophia', gender: 'female', description: 'Professional and clear' },
  { id: '7f3e9d2a1c5b8e4f6a9d3c7b2e5f8a1c', name: 'Olivia', gender: 'female', description: 'Energetic and bright' },
  { id: 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6', name: 'Ava', gender: 'female', description: 'Calm and soothing' },
  { id: 'e8f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5', name: 'Isabella', gender: 'female', description: 'Gentle and caring' },
  { id: '4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f', name: 'James', gender: 'male', description: 'Strong and confident' },
  { id: '9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d', name: 'William', gender: 'male', description: 'Wise and measured' },
  { id: 'f5e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0', name: 'Oliver', gender: 'male', description: 'Deep and reassuring' },
];

export function VoiceSelector({ value, onChange }: VoiceSelectorProps) {
  return (
    <div className="space-y-4">
      <div>
        <Label className="text-base font-semibold">AI Voice</Label>
        <p className="text-sm text-muted-foreground mt-1">
          Choose the voice for your AI companion
        </p>
      </div>

      <RadioGroup value={value} onValueChange={onChange} className="gap-3">
        {VOICES.map((voice) => (
          <div
            key={voice.id}
            className={`flex items-center space-x-3 border rounded-lg p-4 cursor-pointer transition-all ${
              value === voice.id 
                ? 'border-primary bg-primary/5' 
                : 'border-border hover:border-primary/50'
            }`}
            onClick={() => onChange(voice.id)}
          >
            <RadioGroupItem value={voice.id} id={voice.id} />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <Label htmlFor={voice.id} className="font-semibold cursor-pointer">
                  {voice.name}
                </Label>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  voice.gender === 'female' 
                    ? 'bg-pink-500/20 text-pink-700 dark:text-pink-300' 
                    : 'bg-blue-500/20 text-blue-700 dark:text-blue-300'
                }`}>
                  {voice.gender}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">{voice.description}</p>
            </div>
            <Volume2 className={`w-5 h-5 ${value === voice.id ? 'text-primary' : 'text-muted-foreground'}`} />
          </div>
        ))}
      </RadioGroup>
    </div>
  );
}