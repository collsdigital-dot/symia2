import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { VoiceSelector } from "./VoiceSelector";

interface ProfileSettingsProps {
  profile: any;
  onUpdate: () => void;
}

export function ProfileSettings({ profile, onUpdate }: ProfileSettingsProps) {
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    full_name: profile.full_name || "",
    primary_goal: profile.primary_goal || "",
    communication_style: profile.communication_style || "",
    preferred_voice: profile.preferred_voice || "119caed25533477ba63822d5d1552d25",
  });
  const { toast } = useToast();

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("user_profiles")
        .update(formData)
        .eq("user_id", profile.user_id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      onUpdate();
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Profile Information</h2>
        <p className="text-sm text-muted-foreground">
          Update your personal information and preferences
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Full Name</Label>
          <Input
            id="name"
            value={formData.full_name}
            onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
            placeholder="Enter your name"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="goal">Primary Goal</Label>
          <Input
            id="goal"
            value={formData.primary_goal}
            onChange={(e) => setFormData({ ...formData, primary_goal: e.target.value })}
            placeholder="What's your main focus?"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="style">Communication Style</Label>
          <Select
            value={formData.communication_style}
            onValueChange={(value) => setFormData({ ...formData, communication_style: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a style" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="supportive">Supportive</SelectItem>
              <SelectItem value="direct">Direct</SelectItem>
              <SelectItem value="motivational">Motivational</SelectItem>
              <SelectItem value="analytical">Analytical</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <VoiceSelector 
          value={formData.preferred_voice}
          onChange={(voice) => setFormData({ ...formData, preferred_voice: voice })}
        />
      </div>

      <Button 
        onClick={handleSave} 
        disabled={saving}
        className="w-full"
      >
        {saving ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Saving...
          </>
        ) : (
          "Save Changes"
        )}
      </Button>
    </Card>
  );
}
