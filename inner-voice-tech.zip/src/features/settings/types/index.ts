export interface UserProfile {
  id: string;
  user_id: string;
  full_name: string;
  primary_goal?: string;
  preferred_topics?: string[];
  communication_style?: string;
  favorite_color?: string;
  preferred_voice: string;
  avatar_provider: string;
  liveavatar_id: string;
  liveavatar_voice_id?: string;
  liveavatar_context_id?: string;
  liveavatar_persona_id?: string;
  preferred_language?: string;
  avatar_language?: string;
  video_background?: {
    type: 'color' | 'image' | 'custom';
    value: string;
  };
  created_at: string;
  updated_at: string;
}

export interface AvatarConfig {
  id: string;
  user_id: string;
  avatar_type: string;
  avatar_url?: string;
  config_json: Record<string, any>;
  status: string;
  created_at: string;
  updated_at: string;
}
