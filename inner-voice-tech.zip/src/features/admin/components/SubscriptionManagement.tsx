import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Users, TrendingUp, DollarSign, Crown } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface UserSubscription {
  user_id: string;
  subscription_tier: string;
  text_chats_used: number;
  live_demos_used: number;
  email?: string;
  full_name?: string;
}

export function SubscriptionManagement() {
  const [users, setUsers] = useState<UserSubscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    free: 0,
    standard: 0,
    premium: 0,
  });

  useEffect(() => {
    loadUserSubscriptions();
  }, []);

  const loadUserSubscriptions = async () => {
    setLoading(true);
    try {
      const { data: limits, error } = await supabase
        .from("usage_limits")
        .select(`
          user_id,
          subscription_tier,
          text_chats_used,
          live_demos_used
        `)
        .order("subscription_tier", { ascending: false });

      if (error) throw error;

      if (limits) {
        setUsers(limits);
        
        // Calculate stats
        const tierCounts = limits.reduce((acc, user) => {
          acc.total++;
          acc[user.subscription_tier as keyof typeof acc]++;
          return acc;
        }, { total: 0, free: 0, standard: 0, premium: 0 });
        
        setStats(tierCounts);
      }
    } catch (error) {
      console.error("Error loading subscriptions:", error);
      toast.error("Failed to load user subscriptions");
    } finally {
      setLoading(false);
    }
  };

  const handleChangeTier = async (userId: string, newTier: 'free' | 'standard' | 'premium') => {
    try {
      const { error } = await supabase
        .from("usage_limits")
        .update({ subscription_tier: newTier })
        .eq("user_id", userId);

      if (error) throw error;

      toast.success("Subscription tier updated successfully");
      loadUserSubscriptions();
    } catch (error) {
      console.error("Error updating tier:", error);
      toast.error("Failed to update subscription tier");
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case "premium":
        return "bg-primary/10 text-primary";
      case "standard":
        return "bg-blue-500/10 text-blue-500";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="w-4 h-4" />
              Total Users
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
              Free Tier
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.free}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-blue-500" />
              Standard
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.standard}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Crown className="w-4 h-4 text-primary" />
              Premium
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.premium}</div>
          </CardContent>
        </Card>
      </div>

      {/* User List */}
      <Card>
        <CardHeader>
          <CardTitle>User Subscriptions</CardTitle>
          <CardDescription>
            Manage user subscription tiers and view usage
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {users.map((user) => (
              <div
                key={user.user_id}
                className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <Badge className={getTierColor(user.subscription_tier)}>
                      {user.subscription_tier.toUpperCase()}
                    </Badge>
                    <span className="text-sm font-mono text-muted-foreground">
                      {user.user_id.slice(0, 8)}...
                    </span>
                  </div>
                  <div className="flex gap-4 text-xs text-muted-foreground">
                    <span>Chats: {user.text_chats_used}</span>
                    <span>Live: {user.live_demos_used}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Select
                    value={user.subscription_tier}
                    onValueChange={(value) => {
                      if (value === 'free' || value === 'standard' || value === 'premium') {
                        handleChangeTier(user.user_id, value);
                      }
                    }}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="free">Free</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="premium">Premium</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
