export interface Topic {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface DashboardConversation {
  id: string;
  topic: string;
  created_at: string;
  last_message?: string;
}

export interface UsageLimits {
  id: string;
  user_id: string;
  subscription_tier: 'free' | 'standard' | 'premium';
  live_demos_limit: number;
  text_chats_used: number;
  live_demos_used: number;
  reset_date: string;
  created_at: string;
  updated_at: string;
}
