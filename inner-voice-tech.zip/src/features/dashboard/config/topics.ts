import mentalHealthIcon from "@/assets/mental-health-icon.png";
import lifeCoachingIcon from "@/assets/life-coaching-icon.png";
import businessIcon from "@/assets/business-icon.png";
import relationshipsIcon from "@/assets/relationships-icon.png";
import { Topic } from '../types';

export const TOPICS: Topic[] = [
  {
    id: "mental-health",
    title: "Mental Health Support",
    description: "Talk about your feelings, manage stress, and improve your emotional well-being",
    icon: mentalHealthIcon,
  },
  {
    id: "life-coaching",
    title: "Life Coaching",
    description: "Set goals, build habits, and create the life you want to live",
    icon: lifeCoachingIcon,
  },
  {
    id: "business",
    title: "Business Mentoring",
    description: "Grow your career, develop leadership skills, and achieve professional success",
    icon: businessIcon,
  },
  {
    id: "relationships",
    title: "Relationships & Communication",
    description: "Improve your connections and communication with others",
    icon: relationshipsIcon,
  },
];

export const NEUTRAL_TOPIC = {
  id: "general-wellness",
  title: "General Wellness Chat",
  description: "Open conversation about any aspect of your wellness journey"
};
