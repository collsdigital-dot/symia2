import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { UsageLimits } from '../types';

export function useDashboard(userId: string | undefined) {
  const [userProfile, setUserProfile] = useState<any>(null);
  const [avatarConfig, setAvatarConfig] = useState<any>(null);
  const [usageLimits, setUsageLimits] = useState<UsageLimits | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    loadDashboardData();
  }, [userId]);

  const loadDashboardData = async () => {
    if (!userId) return;

    setLoading(true);
    await Promise.all([
      loadProfile(),
      loadAvatarConfig(),
      loadUsageLimits(),
    ]);
    setLoading(false);
  };

  const loadProfile = async () => {
    if (!userId) return;

    const { data } = await supabase
      .from("user_profiles")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();

    if (!data) {
      const { data: newProfile, error } = await supabase
        .from("user_profiles")
        .insert({
          user_id: userId,
          full_name: 'User',
          preferred_voice: '119caed25533477ba63822d5d1552d25',
          heygen_avatar_id: 'Angela-inblackskirt-20220820',
          avatar_provider: 'heygen',
        })
        .select()
        .single();

      setUserProfile(newProfile || {
        user_id: userId,
        full_name: 'User',
        preferred_voice: '119caed25533477ba63822d5d1552d25',
        heygen_avatar_id: 'Angela-inblackskirt-20220820',
        avatar_provider: 'heygen',
      });
    } else {
      setUserProfile(data);
    }
  };

  const loadAvatarConfig = async () => {
    if (!userId) return;

    const { data } = await supabase
      .from('user_avatars')
      .select('*')
      .eq('user_id', userId)
      .single();

    setAvatarConfig(data || null);
  };

  const loadUsageLimits = async () => {
    if (!userId) return;

    let { data } = await supabase
      .from('usage_limits')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (!data) {
      const { data: newLimits } = await supabase
        .from('usage_limits')
        .insert({
          user_id: userId,
          subscription_tier: 'free',
          live_demos_limit: 0,
          text_chats_used: 0,
          live_demos_used: 0
        })
        .select()
        .single();

      data = newLimits || {
        id: crypto.randomUUID(),
        user_id: userId,
        subscription_tier: 'free' as const,
        live_demos_limit: 0,
        text_chats_used: 0,
        live_demos_used: 0,
        reset_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }

    setUsageLimits(data);
  };

  return {
    userProfile,
    avatarConfig,
    usageLimits,
    loading,
    refreshProfile: loadProfile,
    refreshAvatarConfig: loadAvatarConfig,
    refreshUsageLimits: loadUsageLimits,
  };
}
