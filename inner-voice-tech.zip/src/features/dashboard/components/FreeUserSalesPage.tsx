import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check, Sparkles, Video, MessageSquare, Clock, Star } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface FreeUserSalesPageProps {
  userName: string;
  onUpgrade: () => void;
}

export function FreeUserSalesPage({ userName, onUpgrade }: FreeUserSalesPageProps) {
  const navigate = useNavigate();

  const benefits = [
    {
      icon: Video,
      title: "Unlimited Live Sessions",
      description: "Real-time AI avatar conversations with instant voice responses"
    },
    {
      icon: MessageSquare,
      title: "Unlimited Text Chats",
      description: "Get coaching support anytime through text conversations"
    },
    {
      icon: Clock,
      title: "Extended Session Times",
      description: "Longer sessions for deeper, more meaningful conversations"
    },
    {
      icon: Star,
      title: "Priority Support",
      description: "Faster response times and advanced AI insights"
    }
  ];

  const testimonials = [
    {
      name: "Sarah M.",
      role: "Mental Health User",
      quote: "SYMIA has been a game-changer for my anxiety management. Having 24/7 access to support is invaluable."
    },
    {
      name: "James T.",
      role: "Business Professional",
      quote: "The business coaching helped me launch my startup. Best investment I've made in my career."
    },
    {
      name: "Emily R.",
      role: "Life Coaching User",
      quote: "I've achieved more in 3 months with SYMIA than in years of trying alone. Highly recommend!"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-lg font-semibold">SYMIA</h1>
          <Button variant="outline" onClick={() => navigate('/settings')}>
            Settings
          </Button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-12 space-y-16">
        {/* Hero Section */}
        <div className="text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
            <Sparkles className="w-4 h-4" />
            Welcome, {userName}!
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
            You've Experienced the
            <span className="block bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Power of AI Coaching
            </span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Your trial gave you a glimpse. Now unlock unlimited access to transform your life with 24/7 AI-powered wellness coaching.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button size="lg" onClick={onUpgrade} className="text-lg px-8 py-6 shadow-glow">
              Upgrade to Premium
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('/pricing')} className="text-lg px-8 py-6">
              View Pricing
            </Button>
          </div>
        </div>

        {/* What You're Missing */}
        <Card className="p-8 bg-gradient-to-br from-card to-card/50 border-primary/20">
          <h2 className="text-3xl font-bold text-center mb-8">
            What You're Missing as a Free User
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex gap-4 p-4 rounded-lg bg-background/50">
                <div className="shrink-0">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <benefit.icon className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">{benefit.title}</h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Pricing Comparison */}
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-center">Free vs Premium</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Free Tier */}
            <Card className="p-6 bg-muted/50">
              <div className="text-center space-y-4">
                <h3 className="text-2xl font-bold">Free Plan</h3>
                <div className="text-4xl font-bold">$0</div>
                <ul className="space-y-3 text-left">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">1 trial session only</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Limited to 60 seconds</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">No text chat access</span>
                  </li>
                </ul>
                <div className="pt-4 text-muted-foreground italic">
                  Your current plan
                </div>
              </div>
            </Card>

            {/* Premium Tier */}
            <Card className="p-6 border-primary shadow-glow relative overflow-hidden">
              <div className="absolute top-4 right-4">
                <span className="bg-gradient-to-r from-primary to-secondary text-white text-xs font-bold px-3 py-1 rounded-full">
                  BEST VALUE
                </span>
              </div>
              <div className="text-center space-y-4">
                <h3 className="text-2xl font-bold">Premium</h3>
                <div>
                  <div className="text-4xl font-bold">$30</div>
                  <div className="text-muted-foreground">/month</div>
                </div>
                <ul className="space-y-3 text-left">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span><strong>Unlimited</strong> live sessions</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span><strong>Unlimited</strong> text conversations</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span><strong>Extended</strong> session times</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span>Priority AI responses</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span>Advanced insights & analytics</span>
                  </li>
                </ul>
                <Button size="lg" className="w-full" onClick={onUpgrade}>
                  Upgrade Now
                </Button>
              </div>
            </Card>
          </div>
        </div>

        {/* Social Proof */}
        <div className="space-y-8">
          <h2 className="text-3xl font-bold text-center">
            Trusted by Thousands
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6 bg-card/50">
                <div className="space-y-4">
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <p className="text-muted-foreground italic">"{testimonial.quote}"</p>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <Card className="p-12 text-center bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/10 border-primary/20">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Transform Your Life?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands who've unlocked their potential with SYMIA. Start your premium journey today.
          </p>
          <Button size="lg" onClick={onUpgrade} className="text-lg px-12 py-6 shadow-glow">
            Upgrade to Premium Now
          </Button>
          <p className="text-sm text-muted-foreground mt-4">
            30-day money-back guarantee • Cancel anytime
          </p>
        </Card>
      </div>
    </div>
  );
}
