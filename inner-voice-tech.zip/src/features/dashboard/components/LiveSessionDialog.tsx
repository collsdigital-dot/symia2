import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Download } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface LiveSessionDialogProps {
  sessionId: string;
  open: boolean;
  onClose: () => void;
}

export function LiveSessionDialog({ sessionId, open, onClose }: LiveSessionDialogProps) {
  const { toast } = useToast();

  const { data: session, isLoading } = useQuery({
    queryKey: ['live-session', sessionId],
    queryFn: async () => {
      const { data: sessionData, error: sessionError } = await supabase
        .from('live_sessions')
        .select('*')
        .eq('id', sessionId)
        .single();

      if (sessionError) throw sessionError;

      const { data: transcripts, error: transcriptsError } = await supabase
        .from('live_session_transcripts')
        .select('*')
        .eq('session_id', sessionId)
        .order('turn_index', { ascending: true });

      if (transcriptsError) throw transcriptsError;

      return {
        ...sessionData,
        transcripts: transcripts || [],
      };
    },
    enabled: open && !!sessionId,
  });

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const formatTimestamp = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const exportTranscript = () => {
    if (!session?.transcripts) return;

    const content = session.transcripts
      .map((t: any) => `[${formatTimestamp(t.timestamp_offset_ms)}] ${t.speaker === 'user' ? 'You' : 'AI Coach'}: ${t.content}`)
      .join('\n\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${session.track_title}-transcript.txt`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Transcript Exported",
      description: "Your conversation transcript has been downloaded.",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>{session?.track_title || 'Live Session'}</DialogTitle>
          <DialogDescription>
            {session?.created_at && formatDistanceToNow(new Date(session.created_at), { addSuffix: true })}
            {session?.seconds_used && ` • ${formatDuration(session.seconds_used)}`}
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4 py-4">
          {isLoading ? (
            <>
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </>
          ) : session?.transcripts && session.transcripts.length > 0 ? (
            session.transcripts.map((transcript: any, i: number) => (
              <div
                key={i}
                className={`flex gap-3 ${transcript.speaker === 'user' ? 'justify-end' : ''}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    transcript.speaker === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  }`}
                >
                  <p className="text-sm font-medium mb-1">
                    {transcript.speaker === 'user' ? 'You' : 'AI Coach'}
                  </p>
                  <p className="text-sm">{transcript.content}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {formatTimestamp(transcript.timestamp_offset_ms)}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>No transcript available for this session.</p>
              <p className="text-sm mt-2">Transcripts are captured during live conversations.</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={exportTranscript}
            disabled={!session?.transcripts || session.transcripts.length === 0}
          >
            <Download className="w-4 h-4 mr-2" />
            Export Transcript
          </Button>
          <Button onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
