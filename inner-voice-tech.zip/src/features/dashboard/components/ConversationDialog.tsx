import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface ConversationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  topic: string;
  conversationCount: number;
  onContinue: () => void;
  onStartNew: () => void;
}

export function ConversationDialog({
  open,
  onOpenChange,
  topic,
  conversationCount,
  onContinue,
  onStartNew,
}: ConversationDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Continue or Start Fresh?</AlertDialogTitle>
          <AlertDialogDescription>
            You have {conversationCount} previous {conversationCount === 1 ? "conversation" : "conversations"} about <strong>{topic}</strong>.
            Would you like to continue your most recent conversation or start a new one?
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={onStartNew}>Start New</AlertDialogCancel>
          <AlertDialogAction onClick={onContinue}>Continue Recent</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
