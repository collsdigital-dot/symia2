import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Video, Settings, User, Lock } from "lucide-react";
import { useState } from "react";

interface DashboardHeroProps {
  userName: string;
  avatarUrl: string | null;
  onStartLiveCall: () => void;
  onCustomizeAvatar: () => void;
  isLiveLocked?: boolean;
  onUpgrade?: () => void;
}

export function DashboardHero({ 
  userName, 
  avatarUrl, 
  onStartLiveCall,
  onCustomizeAvatar,
  isLiveLocked = false,
  onUpgrade = () => {}
}: DashboardHeroProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/5 border-primary/20 backdrop-blur-sm">
      <div className="p-8 md:p-12">
        <div className="flex flex-col md:flex-row items-center gap-8">
          {/* Avatar */}
          <div 
            className="relative shrink-0"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <div className="w-64 h-64 rounded-full overflow-hidden ring-4 ring-primary/20 shadow-glow bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
              {avatarUrl ? (
                <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <User className="w-32 h-32 text-primary/40" />
              )}
            </div>
            {isHovered && (
              <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center animate-fade-in">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={onCustomizeAvatar}
                  className="gap-2"
                >
                  <Settings className="w-4 h-4" />
                  Edit Avatar
                </Button>
              </div>
            )}
          </div>

          {/* Welcome Message */}
          <div className="flex-1 text-center md:text-left space-y-6">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-3">
                Welcome back, {userName}
              </h1>
              <p className="text-xl text-muted-foreground">
                How can I support you today?
              </p>
            </div>

            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Start a live voice session or choose from one of the modes below
              </p>
              
              <Button 
                onClick={() => {
                  if (isLiveLocked) {
                    onUpgrade();
                  } else {
                    onStartLiveCall();
                  }
                }}
                disabled={isLiveLocked}
                size="lg"
                className="gap-2 shadow-hover hover:shadow-glow transition-all"
              >
                {isLiveLocked ? <Lock className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                {isLiveLocked ? "Start Live Call (Premium)" : "Start Live Call"}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent pointer-events-none" />
    </Card>
  );
}
