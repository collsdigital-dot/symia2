import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MessageSquare, Video, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { LiveSessionDialog } from "./LiveSessionDialog";

interface Conversation {
  id: string;
  topic: string;
  created_at: string;
  type: 'text' | 'live';
  duration?: number;
  last_message?: string;
  last_message_time?: string;
}

interface RecentConversationsProps {
  userId: string;
  onSelectConversation: (conversationId: string, topic: string) => void;
}

export function RecentConversations({ userId, onSelectConversation }: RecentConversationsProps) {
  const [selectedLiveSession, setSelectedLiveSession] = useState<string | null>(null);
  const navigate = useNavigate();

  const { data: conversations, isLoading } = useQuery({
    queryKey: ['recent-conversations', userId],
    queryFn: async () => {
      // Get text conversations
      const { data: textChats } = await supabase
        .from('chat_conversations')
        .select('id, topic, created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(5);
      
      // Get live sessions
      const { data: liveSessions } = await supabase
        .from('live_sessions')
        .select('id, track_title, created_at, seconds_used')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(5);
      
      // Get last messages for text chats
      const textChatsWithMessages = await Promise.all(
        (textChats || []).map(async (conv) => {
          const { data: messages } = await supabase
            .from('chat_messages')
            .select('content, created_at')
            .eq('conversation_id', conv.id)
            .order('created_at', { ascending: false })
            .limit(1);

          return {
            ...conv,
            type: 'text' as const,
            last_message: messages?.[0]?.content || 'No messages yet',
            last_message_time: messages?.[0]?.created_at
          };
        })
      );

      // Combine and sort
      const combined = [
        ...textChatsWithMessages,
        ...(liveSessions || []).map(s => ({ 
          id: s.id, 
          topic: s.track_title, 
          created_at: s.created_at,
          type: 'live' as const,
          duration: s.seconds_used,
          last_message: `${Math.floor(s.seconds_used / 60)}m ${s.seconds_used % 60}s live session`,
          last_message_time: s.created_at
        })),
      ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
       .slice(0, 10);
      
      return combined;
    },
    enabled: !!userId,
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  if (!conversations || conversations.length === 0) {
    return (
      <Card className="p-6 text-center text-muted-foreground">
        <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No conversations yet. Start one by selecting a topic above!</p>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {conversations.map((conversation) => (
          <Card
            key={conversation.id}
            className="p-4 hover:bg-muted/50 cursor-pointer transition-colors"
            onClick={() => {
              if (conversation.type === 'live') {
                setSelectedLiveSession(conversation.id);
              } else {
                onSelectConversation(conversation.id, conversation.topic);
              }
            }}
          >
            <div className="flex items-start gap-3">
              {conversation.type === 'live' ? (
                <Video className="w-5 h-5 text-primary mt-0.5" />
              ) : (
                <MessageSquare className="w-5 h-5 text-primary mt-0.5" />
              )}
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm mb-1 truncate">
                  {conversation.topic}
                </h3>
                <p className="text-sm text-muted-foreground truncate">
                  {conversation.last_message}
                </p>
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(conversation.last_message_time || conversation.created_at), { 
                    addSuffix: true 
                  })}
                </span>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {conversations && conversations.length >= 5 && (
        <Button
          variant="outline"
          className="w-full mt-4"
          onClick={() => navigate('/conversations')}
        >
          <ArrowRight className="w-4 h-4 mr-2" />
          View All Conversations
        </Button>
      )}

      {selectedLiveSession && (
        <LiveSessionDialog
          sessionId={selectedLiveSession}
          open={!!selectedLiveSession}
          onClose={() => setSelectedLiveSession(null)}
        />
      )}
    </>
  );
}
