import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Video, Lock } from "lucide-react";

interface TopicCardProps {
  title: string;
  description: string;
  icon: string;
  onClick: () => void;
  onGoLive?: () => void;
  isTextChatLocked?: boolean;
  isLiveLocked?: boolean;
  onUpgrade?: () => void;
}

export function TopicCard({ 
  title, 
  description, 
  icon, 
  onClick, 
  onGoLive,
  isTextChatLocked = false,
  isLiveLocked = false,
  onUpgrade = () => {}
}: TopicCardProps) {
  return (
    <Card 
      className="group p-6 hover:shadow-hover transition-all duration-300 hover:-translate-y-1 bg-gradient-card backdrop-blur-sm border-border/50"
    >
      <div className="flex items-start gap-4 mb-4">
        <div className="shrink-0 w-16 h-16 rounded-2xl overflow-hidden bg-muted/50 flex items-center justify-center">
          <img src={icon} alt={title} className="w-10 h-10 object-contain" />
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">
            {title}
          </h3>
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
            {description}
          </p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2">
        <Button 
          variant="outline" 
          onClick={() => {
            if (isTextChatLocked) {
              onUpgrade();
            } else {
              onClick();
            }
          }}
          disabled={isTextChatLocked}
          className="flex-1 min-h-[44px] w-full"
        >
          {isTextChatLocked && <Lock className="w-4 h-4 mr-2" />}
          Start Chat
          {!isTextChatLocked && <ArrowRight className="w-4 h-4 ml-2" />}
        </Button>
        
        {onGoLive && (
          <Button
            variant={isLiveLocked ? "outline" : "default"}
            onClick={(e) => {
              e.stopPropagation();
              if (isLiveLocked) {
                onUpgrade();
              } else {
                onGoLive();
              }
            }}
            disabled={isLiveLocked}
            className="flex-1 gap-2 min-h-[44px] w-full"
          >
            {isLiveLocked ? <Lock className="w-4 h-4" /> : <Video className="w-4 h-4" />}
            {isLiveLocked ? "Premium" : "Go Live"}
          </Button>
        )}
      </div>
    </Card>
  );
}