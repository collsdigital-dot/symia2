import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { getCategoryById, CategoryId } from '@/core/config/categories';

interface AvatarPreviewProps {
  category: string;
  onStart: () => void;
  avatarName?: string;
  avatarThumbnail?: string;
}

export function AvatarPreview({ category, onStart, avatarName = 'Your AI Coach', avatarThumbnail = '/avatars/deborah.png' }: AvatarPreviewProps) {
  const categoryConfig = getCategoryById(category as CategoryId);
  const welcomeMessage = categoryConfig.greeting;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-8"
    >
      {/* Large Avatar Container */}
      <div className="relative">
        {/* Animated glow effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/30 via-secondary/30 to-primary/30 rounded-full blur-3xl animate-pulse" />
        
        {/* Avatar with decorative corners */}
        <div className="relative">
          <div className="w-[300px] h-[300px] rounded-full overflow-hidden shadow-2xl border-4 border-white/20 bg-gradient-to-br from-primary to-secondary flex items-center justify-center relative z-10">
            <img
              src={avatarThumbnail}
              alt={avatarName}
              className="w-full h-full object-cover"
              onError={(e) => {
                // Fallback to gradient with initials
                e.currentTarget.style.display = 'none';
                e.currentTarget.parentElement!.innerHTML = '<span class="text-white text-8xl font-bold">AI</span>';
              }}
            />
          </div>
          
          {/* Corner accents */}
          <div className="absolute -top-4 -left-4 w-12 h-12 border-t-4 border-l-4 border-primary/60 rounded-tl-2xl" />
          <div className="absolute -top-4 -right-4 w-12 h-12 border-t-4 border-r-4 border-primary/60 rounded-tr-2xl" />
          <div className="absolute -bottom-4 -left-4 w-12 h-12 border-b-4 border-l-4 border-primary/60 rounded-bl-2xl" />
          <div className="absolute -bottom-4 -right-4 w-12 h-12 border-b-4 border-r-4 border-primary/60 rounded-br-2xl" />
        </div>
      </div>

      {/* Welcome message */}
      <div className="text-center max-w-xl px-4">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-4">
          Meet {avatarName}
        </h2>
        <p className="text-lg text-muted-foreground mb-2">
          {welcomeMessage}
        </p>
        <p className="text-sm text-muted-foreground/80">
          Your AI wellness companion is ready to listen
        </p>
      </div>

      {/* Start button */}
      <Button
        onClick={onStart}
        size="lg"
        className="px-12 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all hover:scale-105"
      >
        Start My Free Session
      </Button>

      <p className="text-xs text-muted-foreground text-center">
        60 seconds of personalized AI support • No credit card required
      </p>
    </motion.div>
  );
}
