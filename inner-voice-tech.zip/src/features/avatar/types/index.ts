export interface AvatarOption {
  id: string;
  name: string;
  gender: 'male' | 'female';
  thumbnail: string;
  description: string;
  supportedLanguages: string[];
  defaultVoiceId: string;
}

export interface LiveSessionConfig {
  avatarId: string;
  voiceId: string;
  language: string;
  topic: string;
}

export interface SessionState {
  isActive: boolean;
  sessionId: string | null;
  error: string | null;
}
