export type FunnelStepType = 
  | 'welcome' 
  | 'quiz' 
  | 'registration' 
  | 'avatar-language' 
  | 'trial' 
  | 'payment';

export interface FunnelState {
  step: FunnelStepType;
  quizAnswers: Record<string, any>;
  selectedCategory?: string;
  selectedAvatar?: string;
  selectedLanguage?: string;
  selectedVoice?: string;
  fullName?: string;
  email?: string;
  hasCompletedQuiz: boolean;
  hasCompletedRegistration: boolean;
  hasCompletedAvatarLanguage: boolean;
}
