import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Play, RotateCcw, SkipForward } from 'lucide-react';
import { LiveAvatarSessionPlayer } from '@/features/liveavatar/components/LiveAvatarSessionPlayer';
import { getLanguageName, getLanguageFlag } from "@/utils/languageHelpers";
import { useFunnelAvatars } from "@/hooks/useFunnelAvatars";
import { getCategoryById, CategoryId } from '@/core/config/categories';
import { getAvatarThumbnail, getAvatarName } from '@/features/liveavatar/services/liveAvatarService';

interface TrialStepProps {
  category: string;
  avatarId: string;
  language: string;
  onComplete: () => void;
}

export function TrialStep({ category, avatarId, language, onComplete }: TrialStepProps) {
  const { data: avatars = [] } = useFunnelAvatars();
  const [sessionState, setSessionState] = useState<'idle' | 'active' | 'ended' | 'error'>('idle');
  const [timeRemaining, setTimeRemaining] = useState(60);
  const { toast } = useToast();
  const timerRef = useRef<NodeJS.Timeout>();
  
  const categoryConfig = getCategoryById(category as CategoryId);
  const greeting = categoryConfig.greeting;

  const handleStart = () => {
    console.log('[TrialStep] Starting session...');
    setSessionState('active');
    setTimeRemaining(60);
  };

  const handleRetry = () => {
    setSessionState('idle');
    setTimeRemaining(60);
  };

  const handleEnd = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setSessionState('ended');
  };

  const handleError = (err: string) => {
    console.error('[TrialStep] Session error:', err);
    setSessionState('error');
    toast({
      title: "Connection Error",
      description: err,
      variant: "destructive",
    });
  };

  // Session timer
  useEffect(() => {
    if (sessionState === 'active') {
      timerRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            handleEnd();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        if (timerRef.current) clearInterval(timerRef.current);
      };
    }
  }, [sessionState]);

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-foreground">Your Free 60-Second Demo</h2>
        <p className="text-muted-foreground">
          Experience AI wellness coaching with your chosen avatar
        </p>
      </div>

      {sessionState === 'idle' && (
        <Card className="p-8 space-y-6 bg-gradient-to-br from-primary/5 to-secondary/5 border-border/50">
          <div className="flex flex-col items-center gap-4">
            <div className="w-32 h-32 rounded-full overflow-hidden ring-4 ring-primary/20">
              <img
                src={getAvatarThumbnail(avatars, avatarId)}
                alt={getAvatarName(avatars, avatarId)}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-semibold text-foreground">Ready for Your Demo?</h3>
              <p className="text-muted-foreground max-w-md">
                {greeting}
              </p>
              <p className="text-sm text-muted-foreground">
                Speaking in {getLanguageFlag(language)} {getLanguageName(language)}
              </p>
            </div>
          </div>

          <div className="flex gap-3 justify-center">
            <Button
              onClick={handleStart}
              size="lg"
              className="gap-2"
            >
              <Play className="w-5 h-5" />
              Start Demo
            </Button>
            <Button
              onClick={onComplete}
              variant="outline"
              size="lg"
              className="gap-2"
            >
              <SkipForward className="w-5 h-5" />
              Skip Demo
            </Button>
          </div>
        </Card>
      )}

      {sessionState === 'active' && (
        <div className="space-y-4">
          <LiveAvatarSessionPlayer
            avatarId={avatarId}
            category={category as 'mental_health' | 'life_coaching' | 'business' | 'relationships' | 'general-wellness'}
            language={language}
            maxDuration={60}
            showControls={false}
            showTimer={true}
            autoStart={true}
            onSessionEnd={handleEnd}
            onError={handleError}
          />

          <Card className="p-4 space-y-3 bg-gradient-to-r from-primary/10 to-secondary/10 max-w-3xl mx-auto">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">Time Remaining</span>
              <span className="text-2xl font-bold text-primary">{timeRemaining}s</span>
            </div>
            <Button
              onClick={handleEnd}
              variant="outline"
              size="lg"
              className="w-full"
            >
              End Demo Early
            </Button>
          </Card>
        </div>
      )}

      {sessionState === 'error' && (
        <Card className="p-8 space-y-6 bg-destructive/5 border-destructive/20">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-semibold text-destructive">Connection Issue</h3>
            <p className="text-muted-foreground max-w-md">
              We couldn't connect to the AI coach. Please try again or skip to continue.
            </p>
          </div>

          <div className="flex gap-3 justify-center">
            <Button
              onClick={handleRetry}
              variant="outline"
              size="lg"
              className="gap-2"
            >
              <RotateCcw className="w-5 h-5" />
              Try Again
            </Button>
            <Button
              onClick={onComplete}
              size="lg"
              className="gap-2"
            >
              <SkipForward className="w-5 h-5" />
              Continue Anyway
            </Button>
          </div>
        </Card>
      )}

      {sessionState === 'ended' && (
        <Card className="p-8 space-y-6 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/20">
          <div className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
              <Play className="w-8 h-8 text-primary" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-semibold text-foreground">Demo Complete!</h3>
              <p className="text-muted-foreground max-w-md">
                Ready to unlock unlimited access to your AI wellness coach?
              </p>
            </div>
          </div>

          <Button
            onClick={onComplete}
            size="lg"
            className="w-full"
          >
            Continue to Payment
          </Button>
        </Card>
      )}
    </div>
  );
}
