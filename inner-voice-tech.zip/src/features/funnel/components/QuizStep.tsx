import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { getAllCategories } from '@/core/config/categories';

interface QuizStepProps {
  onComplete: (
    answers: Record<string, any>,
    category: 'mental_health' | 'life_coaching' | 'business' | 'relationships'
  ) => void;
}

const questions = [
  {
    id: 'feeling',
    question: 'How are you feeling today?',
    options: ['Great 😊', 'Good 😌', 'Okay 😐', 'Not great 😔', 'Struggling 😢'],
  },
  {
    id: 'reason',
    question: 'What brings you here?',
    options: [
      'Personal growth',
      'Emotional support',
      'Career guidance',
      'Relationship advice',
      'Just exploring',
    ],
  },
  {
    id: 'experience',
    question: 'Have you ever tried AI wellness coaching before?',
    options: ['Yes, regularly', 'Yes, once or twice', 'No, this is my first time'],
  },
  {
    id: 'style',
    question: 'Would you like support that is more emotional or practical?',
    options: ['More emotional', 'Balanced', 'More practical'],
  },
];

const categories = getAllCategories().map(cat => ({
  id: cat.id,
  name: cat.shortName,
  icon: cat.icon,
  description: cat.description.split(' ').slice(0, 5).join(' '),
  color: cat.backgroundColor,
}));

export function QuizStep({ onComplete }: QuizStepProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [showCategories, setShowCategories] = useState(false);

  const handleAnswer = (answer: string) => {
    const newAnswers = { ...answers, [questions[currentQuestion].id]: answer };
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowCategories(true);
    }
  };

  const handleCategorySelect = (categoryId: string) => {
    onComplete(answers, categoryId as any);
  };

  if (showCategories) {
    return (
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold text-foreground">Which area would you like to focus on?</h2>
          <p className="text-muted-foreground">Choose the path that resonates with you most</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  className="p-6 cursor-pointer hover:shadow-hover transition-all duration-300 group bg-card/80 backdrop-blur-sm border-border/50"
                  onClick={() => handleCategorySelect(category.id)}
                >
                  <div className="space-y-4">
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${category.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-foreground mb-1">{category.name}</h3>
                      <p className="text-sm text-muted-foreground">{category.description}</p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Progress */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>{Math.round(((currentQuestion + 1) / questions.length) * 100)}%</span>
        </div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-primary to-secondary"
            initial={{ width: 0 }}
            animate={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      {/* Question */}
      <motion.div
        key={currentQuestion}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.3 }}
        className="space-y-6"
      >
        <h2 className="text-3xl font-bold text-foreground text-center">
          {questions[currentQuestion].question}
        </h2>

        <div className="grid gap-3 mt-8">
          {questions[currentQuestion].options.map((option, index) => (
            <motion.div
              key={option}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Button
                variant="outline"
                className="w-full py-6 text-lg justify-between hover:bg-primary/10 hover:border-primary transition-all duration-300 rounded-button"
                onClick={() => handleAnswer(option)}
              >
                {option}
                <ChevronRight className="h-5 w-5" />
              </Button>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
