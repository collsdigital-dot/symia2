import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LANGUAGE_OPTIONS } from "@/core/config/avatarConfig";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Sparkles, Loader2 } from "lucide-react";
import { useFunnelAvatars } from "@/hooks/useFunnelAvatars";

interface AvatarLanguageStepProps {
  onComplete: (avatarId: string, language: string) => void;
}

export function AvatarLanguageStep({ onComplete }: AvatarLanguageStepProps) {
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState('en-US');
  const { toast } = useToast();
  const { data: FUNNEL_AVATARS, isLoading, error } = useFunnelAvatars();

  const handleContinue = async () => {
    if (!selectedAvatar) {
      toast({
        title: "Please select an avatar",
        description: "Choose your AI companion to continue",
        variant: "destructive",
      });
      return;
    }

    // Save selections to user profile
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const avatarData = FUNNEL_AVATARS?.find(a => a.id === selectedAvatar);
      const { error } = await supabase
        .from('user_profiles')
        .update({
          heygen_avatar_id: selectedAvatar,
          heygen_voice_id: avatarData?.defaultVoiceId,
          preferred_language: selectedLanguage,
          avatar_language: selectedLanguage,
          avatar_provider: 'heygen',
        })
        .eq('user_id', user.id);

      if (error) {
        console.error('Error saving avatar selection:', error);
      }
    }

    onComplete(selectedAvatar, selectedLanguage);
  };

  const selectedAvatarData = FUNNEL_AVATARS?.find(a => a.id === selectedAvatar);

  if (error) {
    return (
      <div className="text-center space-y-4 py-12">
        <p className="text-destructive">Failed to load avatars. Please try again.</p>
        <Button onClick={() => window.location.reload()}>Retry</Button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          <Sparkles className="w-6 h-6 text-primary" />
          <h2 className="text-3xl font-bold text-foreground">Choose Your AI Companion</h2>
        </div>
        <p className="text-muted-foreground">
          Select your avatar and preferred language for the best experience
        </p>
      </div>

      {/* Language Selection */}
      <Card className="p-6 bg-card/80 backdrop-blur-sm border-border/50">
        <div className="space-y-3">
          <label className="text-sm font-semibold text-foreground flex items-center gap-2">
            <span className="text-lg">🌐</span> Language Preference
          </label>
          <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGE_OPTIONS.map((lang) => (
                <SelectItem key={lang.code} value={lang.code}>
                  <div className="flex items-center gap-2">
                    <span>{lang.flag}</span>
                    <span>{lang.name}</span>
                    <span className="text-muted-foreground text-sm">({lang.nativeName})</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Avatar Grid */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Select Your Avatar</h3>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <p className="ml-3 text-muted-foreground">Loading avatars...</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {FUNNEL_AVATARS?.map((avatar) => (
            <Card
              key={avatar.id}
              className={`cursor-pointer transition-all hover:scale-105 ${
                selectedAvatar === avatar.id
                  ? 'ring-2 ring-primary shadow-lg bg-primary/5'
                  : 'hover:shadow-md'
              }`}
              onClick={() => setSelectedAvatar(avatar.id)}
            >
              <div className="p-3 space-y-3">
                <div className="aspect-square rounded-xl overflow-hidden bg-muted">
                  <img
                    src={avatar.thumbnail}
                    alt={avatar.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-sm text-foreground">{avatar.name}</p>
                    <Badge variant={avatar.gender === 'female' ? 'secondary' : 'default'} className="text-xs">
                      {avatar.gender === 'female' ? '♀' : '♂'}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{avatar.description}</p>
                </div>
              </div>
            </Card>
          ))}
          </div>
        )}
      </div>

      {/* Preview Section */}
      {selectedAvatarData && (
        <Card className="p-6 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/20">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-primary/20 flex-shrink-0">
              <img
                src={selectedAvatarData.thumbnail}
                alt={selectedAvatarData.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 text-center md:text-left space-y-2">
              <h3 className="text-xl font-bold text-foreground">
                Meet {selectedAvatarData.name}
              </h3>
              <p className="text-foreground">
                {selectedAvatarData.description}
              </p>
              <p className="text-sm text-muted-foreground">
                Speaking in {LANGUAGE_OPTIONS.find(l => l.code === selectedLanguage)?.flag}{' '}
                {LANGUAGE_OPTIONS.find(l => l.code === selectedLanguage)?.name}
              </p>
            </div>
          </div>
        </Card>
      )}

      <Button
        onClick={handleContinue}
        size="lg"
        className="w-full"
        disabled={!selectedAvatar}
      >
        Continue to Your Free Demo
      </Button>
    </div>
  );
}
