import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Volume2, VolumeX, Play } from "lucide-react";
import avatarImage from "@/assets/avatar-female-hd.png";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";

interface WelcomeStepProps {
  onComplete: () => void;
}

export function WelcomeStep({ onComplete }: WelcomeStepProps) {
  const navigate = useNavigate();
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showFallback, setShowFallback] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasEnded, setHasEnded] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const welcomeText = "Welcome to SYMIA, your personal AI wellness companion. Let's take a moment to understand your needs so we can guide you toward balance, growth, and peace of mind. Ready to begin?";

  useEffect(() => {
    // Fetch the welcome video
    const fetchVideo = async () => {
      try {
        console.log('Fetching welcome video...');
        const { data, error } = await supabase.functions.invoke('generate-video', {
          body: { type: 'welcome' }
        });
        
        if (error) {
          console.error('Edge function error:', error);
          throw error;
        }
        
        if (data?.videoUrl) {
          console.log('Video URL received:', data.videoUrl);
          setVideoUrl(data.videoUrl);
          setIsLoading(false);
        } else {
          console.warn('No video URL in response');
          setShowFallback(true);
          setIsLoading(false);
        }
      } catch (err) {
        console.error('Failed to load welcome video:', err);
        setShowFallback(true);
        setIsLoading(false);
      }
    };
    
    fetchVideo();
  }, []);

  useEffect(() => {
    if (!videoUrl || !videoRef.current) return;
    const video = videoRef.current;

    const handleLoadedData = () => {
      console.log('Video loaded successfully');
      setIsLoading(false);
    };

    const handlePlay = () => {
      console.log('Video playing');
      setIsSpeaking(true);
    };
    
    const handleEnded = () => {
      console.log('Video ended');
      setIsSpeaking(false);
      setHasEnded(true);
    };
    
    const handlePause = () => setIsSpeaking(false);
    
    const handleError = (e: Event) => {
      const target = e.target as HTMLVideoElement;
      console.error('Video playback error:', target.error);
      toast.error('Video playback failed, showing fallback');
      setShowFallback(true);
      setIsLoading(false);
    };

    video.addEventListener('loadeddata', handleLoadedData);
    video.addEventListener('play', handlePlay);
    video.addEventListener('ended', handleEnded);
    video.addEventListener('pause', handlePause);
    video.addEventListener('error', handleError);

    // Auto-play after video is loaded
    const timer = setTimeout(() => {
      video.play().catch((err) => {
        console.error('Autoplay failed:', err);
        // If autoplay fails due to browser policy, that's okay - user can click
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      video.removeEventListener('loadeddata', handleLoadedData);
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('ended', handleEnded);
      video.removeEventListener('pause', handlePause);
      video.removeEventListener('error', handleError);
    };
  }, [videoUrl]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center space-y-8">
      {/* Logo */}
      <div className="mb-4">
        <h1 className="text-6xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
          SYMIA
        </h1>
        <p className="text-muted-foreground mt-2">Your AI Wellness Companion</p>
      </div>

      {/* Avatar Video Container */}
      <div className="relative w-full max-w-2xl">
        {/* Animated glow effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 via-pink-500/20 to-blue-500/20 rounded-full blur-3xl animate-pulse" />
        
        <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20 bg-gradient-to-br from-purple-500/10 to-pink-500/10 backdrop-blur-md">
          {isLoading && !showFallback && (
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10">
              <div className="text-center space-y-4">
                <div className="animate-pulse space-y-2">
                  <div className="w-16 h-16 mx-auto rounded-full bg-primary/20" />
                  <p className="text-sm text-muted-foreground">Loading your AI companion...</p>
                </div>
              </div>
            </div>
          )}
          
          {!showFallback && videoUrl && (
            <div className="relative w-full h-full">
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-cover"
                playsInline
                muted={isMuted}
                preload="auto"
              />
              
              {/* Replay Button Overlay (when video ended) */}
              {hasEnded && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[1px]">
                  <button
                    onClick={() => {
                      if (videoRef.current) {
                        videoRef.current.currentTime = 0;
                        videoRef.current.play();
                        setHasEnded(false);
                      }
                    }}
                    className="bg-white/95 backdrop-blur-sm rounded-full p-6 hover:bg-white hover:scale-110 transition-all shadow-2xl group"
                    aria-label="Replay video"
                  >
                    <Play className="w-10 h-10 text-gray-700 group-hover:text-primary transition-colors" fill="currentColor" />
                  </button>
                </div>
              )}
              
              {/* Mute/Unmute Button */}
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="absolute bottom-4 right-4 z-20 bg-white/90 backdrop-blur-sm rounded-full p-3 hover:bg-white hover:scale-110 transition-all shadow-lg"
                aria-label={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5 text-gray-700" />
                ) : (
                  <Volume2 className="w-5 h-5 text-gray-700" />
                )}
              </button>
              
              {isSpeaking && !hasEnded && (
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)] animate-pulse" style={{ animationDelay: '0ms' }} />
                  <div className="w-3 h-3 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)] animate-pulse" style={{ animationDelay: '150ms' }} />
                  <div className="w-3 h-3 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)] animate-pulse" style={{ animationDelay: '300ms' }} />
                </div>
              )}
            </div>
          )}

          {showFallback && (
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10">
              <div className="text-center space-y-4 p-8">
                <div className="relative w-32 h-32 mx-auto">
                  <div className="w-32 h-32 rounded-full overflow-hidden ring-4 ring-primary/20 shadow-glow">
                    <img
                      src={avatarImage}
                      alt="Greta Shaw - AI Wellness Companion"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <div className="space-y-2 max-w-xl">
                  <p className="text-lg font-medium text-foreground">
                    "{welcomeText.split('.')[0]}."
                  </p>
                  <p className="text-muted-foreground">
                    "{welcomeText.split('.')[1]}."
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Corner Accents */}
        <div className="absolute -top-4 -left-4 w-8 h-8 border-t-2 border-l-2 border-primary/40 rounded-tl-lg" />
        <div className="absolute -top-4 -right-4 w-8 h-8 border-t-2 border-r-2 border-primary/40 rounded-tr-lg" />
        <div className="absolute -bottom-4 -left-4 w-8 h-8 border-b-2 border-l-2 border-primary/40 rounded-bl-lg" />
        <div className="absolute -bottom-4 -right-4 w-8 h-8 border-b-2 border-r-2 border-primary/40 rounded-br-lg" />
      </div>

      {/* Action Buttons */}
      <div className="space-y-4 flex flex-col items-center">
        <Button 
          size="lg" 
          onClick={onComplete}
          className="px-8 py-6 text-lg rounded-button"
        >
          Let's Begin
        </Button>
        
        <Button 
          variant="ghost" 
          onClick={() => navigate("/auth")}
          className="text-muted-foreground hover:text-foreground"
        >
          Already have an account? <span className="ml-1 font-semibold text-primary">Sign In</span>
        </Button>
      </div>
    </div>
  );
}
