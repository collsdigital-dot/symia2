import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface PaymentStepProps {
  onComplete: (minutes: number) => void;
}

const plans = [
  {
    id: 'basic',
    name: 'Basic',
    duration: 15,
    price: 15,
    features: ['15 minutes of AI coaching', 'Text & voice support', 'Session history'],
  },
  {
    id: 'standard',
    name: 'Standard',
    duration: 30,
    price: 30,
    features: ['30 minutes of AI coaching', 'Text & voice support', 'Session history', 'Priority responses'],
    popular: true,
  },
  {
    id: 'premium',
    name: 'Premium',
    duration: 60,
    price: 60,
    features: ['60 minutes of AI coaching', 'Text & voice support', 'Session history', 'Priority responses', 'Advanced insights'],
  },
];

export function PaymentStep({ onComplete }: PaymentStepProps) {
  const [selectedPlan, setSelectedPlan] = useState('standard');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handlePayment = async () => {
    const plan = plans.find(p => p.id === selectedPlan);
    if (!plan) return;

    setLoading(true);

    try {
      // TODO: Implement Stripe checkout
      // For now, simulate successful payment
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Payment successful!",
        description: "Your personalized SYMIA companion is now fully unlocked.",
      });

      onComplete(plan.duration);
    } catch (error: any) {
      console.error('Payment error:', error);
      toast({
        title: "Payment failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSkip = async () => {
    try {
      // Set user to free tier in usage_limits
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        await supabase
          .from('usage_limits')
          .upsert({
            user_id: user.id,
            subscription_tier: 'free',
            live_demos_limit: 0,
            live_demos_used: 0,
            text_chats_used: 0,
          });
      }

      toast({
        title: "Welcome to SYMIA!",
        description: "You can upgrade anytime from your dashboard.",
      });
      
      onComplete(0); // 0 minutes = free tier
    } catch (error) {
      console.error('Error setting free tier:', error);
      // Still complete the funnel even if there's an error
      onComplete(0);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-foreground">Choose Your Plan</h2>
        <p className="text-muted-foreground">
          Unlock the full power of AI wellness coaching
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`p-6 cursor-pointer transition-all duration-300 relative ${
              selectedPlan === plan.id
                ? 'border-primary shadow-glow bg-primary/5'
                : 'border-border/50 hover:border-primary/50 bg-card/80 backdrop-blur-sm'
            }`}
            onClick={() => setSelectedPlan(plan.id)}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="bg-gradient-to-r from-primary to-secondary text-white text-xs font-semibold px-3 py-1 rounded-full">
                  Most Popular
                </span>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <h3 className="text-xl font-bold text-foreground">{plan.name}</h3>
                <div className="mt-2">
                  <span className="text-4xl font-bold text-foreground">${plan.price}</span>
                  <span className="text-muted-foreground ml-2">/ {plan.duration} min</span>
                </div>
              </div>

              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-2">
                <div
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    selectedPlan === plan.id
                      ? 'border-primary bg-primary'
                      : 'border-border'
                  }`}
                >
                  {selectedPlan === plan.id && (
                    <Check className="h-4 w-4 text-white" />
                  )}
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="space-y-4 flex flex-col items-center">
        <Button
          size="lg"
          className="w-full max-w-md"
          onClick={handlePayment}
          disabled={loading}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            `Continue to Payment - $${plans.find(p => p.id === selectedPlan)?.price}`
          )}
        </Button>

        <Button
          variant="ghost"
          size="lg"
          className="w-full max-w-md"
          onClick={handleSkip}
          disabled={loading}
        >
          Skip for now - Start with free tier
        </Button>

        <p className="text-xs text-muted-foreground text-center max-w-md">
          Free tier users can upgrade anytime from the dashboard
        </p>
      </div>
    </div>
  );
}
