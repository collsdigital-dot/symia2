import { useState } from 'react';
import { FunnelState, FunnelStepType } from '../types';

const INITIAL_STATE: FunnelState = {
  step: 'welcome',
  quizAnswers: {},
  hasCompletedQuiz: false,
  hasCompletedRegistration: false,
  hasCompletedAvatarLanguage: false,
};

export function useFunnelState() {
  const [state, setState] = useState<FunnelState>(INITIAL_STATE);

  const updateState = (updates: Partial<FunnelState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const goToStep = (step: FunnelStepType) => {
    setState(prev => ({ ...prev, step }));
  };

  const reset = () => {
    setState(INITIAL_STATE);
  };

  return {
    state,
    updateState,
    goToStep,
    reset,
  };
}
