import { Button } from "@/components/ui/button";
import { MessageSquare, Video, Mic } from "lucide-react";

interface ConversationActionsProps {
  conversation: {
    id: string;
    type: 'text' | 'live';
    topic: string;
  };
  onContinue: () => void;
  onStartLiveCall: () => void;
  onStartVoiceChat: () => void;
}

export function ConversationActions({ 
  conversation, 
  onContinue, 
  onStartLiveCall, 
  onStartVoiceChat 
}: ConversationActionsProps) {
  return (
    <div className="flex flex-wrap gap-2 mt-3" onClick={(e) => e.stopPropagation()}>
      {conversation.type === 'text' && (
        <>
          <Button 
            size="sm" 
            variant="outline"
            onClick={(e) => {
              e.stopPropagation();
              onContinue();
            }}
          >
            <MessageSquare className="w-3 h-3 mr-1" />
            Continue Chat
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={(e) => {
              e.stopPropagation();
              onStartVoiceChat();
            }}
          >
            <Mic className="w-3 h-3 mr-1" />
            Voice Chat
          </Button>
        </>
      )}
      <Button 
        size="sm" 
        variant="default"
        onClick={(e) => {
          e.stopPropagation();
          onStartLiveCall();
        }}
      >
        <Video className="w-3 h-3 mr-1" />
        {conversation.type === 'live' ? 'New Call' : 'Start Call'}
      </Button>
    </div>
  );
}
