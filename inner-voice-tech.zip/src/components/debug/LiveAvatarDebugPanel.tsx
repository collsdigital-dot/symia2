import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bug, 
  ChevronDown, 
  ChevronUp, 
  Copy, 
  RefreshCw, 
  Trash2,
  CheckCircle2,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/features/auth';
import { toast } from 'sonner';

interface LogEntry {
  id: string;
  timestamp: number;
  level: 'info' | 'warn' | 'error' | 'success';
  category: string;
  message: string;
  data?: any;
}

interface DebugState {
  isExpanded: boolean;
  logs: LogEntry[];
  userProfile: any;
  sessionState: any;
  apiCalls: any[];
}

export function LiveAvatarDebugPanel() {
  const { user } = useAuth();
  const [state, setState] = useState<DebugState>({
    isExpanded: false,
    logs: [],
    userProfile: null,
    sessionState: null,
    apiCalls: []
  });

  useEffect(() => {
    // Listen for debug events
    const handleDebugEvent = (event: CustomEvent) => {
      addLog(event.detail);
    };

    window.addEventListener('liveavatar-debug' as any, handleDebugEvent);
    
    return () => {
      window.removeEventListener('liveavatar-debug' as any, handleDebugEvent);
    };
  }, []);

  const addLog = (entry: Omit<LogEntry, 'id' | 'timestamp'>) => {
    const newLog: LogEntry = {
      ...entry,
      id: crypto.randomUUID(),
      timestamp: Date.now()
    };

    setState(prev => ({
      ...prev,
      logs: [newLog, ...prev.logs].slice(0, 100) // Keep last 100 logs
    }));
  };

  const loadUserProfile = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;

      setState(prev => ({ ...prev, userProfile: data }));
      addLog({
        level: 'success',
        category: 'Profile',
        message: 'User profile loaded',
        data
      });
    } catch (error) {
      addLog({
        level: 'error',
        category: 'Profile',
        message: 'Failed to load user profile',
        data: error
      });
    }
  };

  const testAvatarAPI = async () => {
    addLog({
      level: 'info',
      category: 'API Test',
      message: 'Testing LiveAvatar avatars API...'
    });

    try {
      const startTime = Date.now();
      const { data, error } = await supabase.functions.invoke('liveavatar-options', {
        body: { type: 'avatars' }
      });
      const duration = Date.now() - startTime;

      if (error) throw error;

      addLog({
        level: 'success',
        category: 'API Test',
        message: `Avatars API responded in ${duration}ms`,
        data
      });

      setState(prev => ({
        ...prev,
        apiCalls: [...prev.apiCalls, {
          endpoint: 'liveavatar-options (avatars)',
          duration,
          response: data,
          timestamp: Date.now()
        }]
      }));
    } catch (error) {
      addLog({
        level: 'error',
        category: 'API Test',
        message: 'Avatars API test failed',
        data: error
      });
    }
  };

  const testVoiceAPI = async () => {
    addLog({
      level: 'info',
      category: 'API Test',
      message: 'Testing LiveAvatar voices API...'
    });

    try {
      const startTime = Date.now();
      const { data, error } = await supabase.functions.invoke('liveavatar-options', {
        body: { type: 'voices' }
      });
      const duration = Date.now() - startTime;

      if (error) throw error;

      addLog({
        level: 'success',
        category: 'API Test',
        message: `Voices API responded in ${duration}ms`,
        data
      });

      setState(prev => ({
        ...prev,
        apiCalls: [...prev.apiCalls, {
          endpoint: 'liveavatar-options (voices)',
          duration,
          response: data,
          timestamp: Date.now()
        }]
      }));
    } catch (error) {
      addLog({
        level: 'error',
        category: 'API Test',
        message: 'Voices API test failed',
        data: error
      });
    }
  };

  const testSessionCreate = async () => {
    addLog({
      level: 'info',
      category: 'API Test',
      message: 'Testing session creation...'
    });

    try {
      const startTime = Date.now();
      const { data, error } = await supabase.functions.invoke('liveavatar-create-session', {
        body: {
          avatarId: state.userProfile?.liveavatar_id || '1c690fe7-23e0-49f9-bfba-14344450285b',
          voiceId: state.userProfile?.liveavatar_voice_id || 'af28cadf-0000-0000-0000-9a8e17ef3eef',
          category: 'general-wellness',
          language: 'en-US'
        }
      });
      const duration = Date.now() - startTime;

      if (error) throw error;

      addLog({
        level: 'success',
        category: 'API Test',
        message: `Session created in ${duration}ms`,
        data
      });

      setState(prev => ({
        ...prev,
        sessionState: data,
        apiCalls: [...prev.apiCalls, {
          endpoint: 'liveavatar-create-session',
          duration,
          response: data,
          timestamp: Date.now()
        }]
      }));
    } catch (error) {
      addLog({
        level: 'error',
        category: 'API Test',
        message: 'Session creation failed',
        data: error
      });
    }
  };

  const clearLogs = () => {
    setState(prev => ({ ...prev, logs: [] }));
    toast.success('Logs cleared');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'success':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-destructive" />;
      case 'warn':
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-blue-500" />;
    }
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString() + '.' + date.getMilliseconds();
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 w-full max-w-3xl">
      <Card className="border-2 border-primary/50 shadow-2xl">
        {/* Header */}
        <div 
          className="flex items-center justify-between p-4 bg-primary/10 cursor-pointer"
          onClick={() => setState(prev => ({ ...prev, isExpanded: !prev.isExpanded }))}
        >
          <div className="flex items-center gap-2">
            <Bug className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">LiveAvatar Debug Panel</h3>
            <Badge variant="outline">{state.logs.length} logs</Badge>
          </div>
          <Button size="icon" variant="ghost">
            {state.isExpanded ? <ChevronDown /> : <ChevronUp />}
          </Button>
        </div>

        {/* Expanded Content */}
        {state.isExpanded && (
          <div className="p-4">
            <Tabs defaultValue="logs">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="logs">Logs</TabsTrigger>
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="session">Session</TabsTrigger>
                <TabsTrigger value="api">API Tests</TabsTrigger>
              </TabsList>

              {/* Logs Tab */}
              <TabsContent value="logs" className="space-y-3">
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={clearLogs}>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear Logs
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => copyToClipboard(JSON.stringify(state.logs, null, 2))}
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy All
                  </Button>
                </div>

                <ScrollArea className="h-96 border rounded-lg p-3">
                  {state.logs.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      No logs yet. Actions will appear here.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {state.logs.map((log) => (
                        <div 
                          key={log.id}
                          className="border-l-4 pl-3 py-2 hover:bg-accent/50 rounded"
                          style={{
                            borderLeftColor: 
                              log.level === 'error' ? '#ef4444' :
                              log.level === 'warn' ? '#f59e0b' :
                              log.level === 'success' ? '#10b981' : '#3b82f6'
                          }}
                        >
                          <div className="flex items-start gap-2">
                            {getLevelIcon(log.level)}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                                <span>{formatTimestamp(log.timestamp)}</span>
                                <Badge variant="outline" className="text-xs">
                                  {log.category}
                                </Badge>
                              </div>
                              <p className="text-sm font-medium">{log.message}</p>
                              {log.data && (
                                <details className="mt-2">
                                  <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
                                    View details
                                  </summary>
                                  <pre className="mt-2 text-xs bg-muted p-2 rounded overflow-auto max-h-40">
                                    {JSON.stringify(log.data, null, 2)}
                                  </pre>
                                </details>
                              )}
                            </div>
                            <Button 
                              size="icon" 
                              variant="ghost"
                              className="h-6 w-6"
                              onClick={() => copyToClipboard(JSON.stringify(log, null, 2))}
                            >
                              <Copy className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              {/* Profile Tab */}
              <TabsContent value="profile" className="space-y-3">
                <Button size="sm" onClick={loadUserProfile}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh Profile
                </Button>

                <ScrollArea className="h-96 border rounded-lg p-3">
                  {state.userProfile ? (
                    <pre className="text-xs">
                      {JSON.stringify(state.userProfile, null, 2)}
                    </pre>
                  ) : (
                    <div className="text-center text-muted-foreground py-8">
                      Click "Refresh Profile" to load user data
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              {/* Session Tab */}
              <TabsContent value="session" className="space-y-3">
                <div className="text-sm text-muted-foreground">
                  Current session state and LiveKit connection info
                </div>

                <ScrollArea className="h-96 border rounded-lg p-3">
                  {state.sessionState ? (
                    <pre className="text-xs">
                      {JSON.stringify(state.sessionState, null, 2)}
                    </pre>
                  ) : (
                    <div className="text-center text-muted-foreground py-8">
                      No active session. Create a session to see details.
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              {/* API Tests Tab */}
              <TabsContent value="api" className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" onClick={testAvatarAPI}>
                    Test Avatars API
                  </Button>
                  <Button size="sm" onClick={testVoiceAPI}>
                    Test Voices API
                  </Button>
                  <Button size="sm" onClick={testSessionCreate} disabled={!state.userProfile}>
                    Test Session Create
                  </Button>
                  <Button size="sm" variant="outline" onClick={loadUserProfile}>
                    Load Profile First
                  </Button>
                </div>

                <ScrollArea className="h-96 border rounded-lg p-3">
                  {state.apiCalls.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      Run API tests to see results here
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {state.apiCalls.map((call, index) => (
                        <div key={index} className="border rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-sm">{call.endpoint}</span>
                            <Badge>{call.duration}ms</Badge>
                          </div>
                          <div className="text-xs text-muted-foreground mb-2">
                            {new Date(call.timestamp).toLocaleString()}
                          </div>
                          <details>
                            <summary className="text-xs cursor-pointer hover:text-foreground">
                              View response
                            </summary>
                            <pre className="mt-2 text-xs bg-muted p-2 rounded overflow-auto max-h-60">
                              {JSON.stringify(call.response, null, 2)}
                            </pre>
                          </details>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </Card>
    </div>
  );
}

// Helper function to dispatch debug events
export function logDebug(
  level: 'info' | 'warn' | 'error' | 'success',
  category: string,
  message: string,
  data?: any
) {
  window.dispatchEvent(
    new CustomEvent('liveavatar-debug', {
      detail: { level, category, message, data }
    })
  );
  
  // Also log to console with appropriate method
  const consoleMethod = level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log';
  console[consoleMethod](`[${category}] ${message}`, data || '');
}
