import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshTransmissionMaterial, MeshDistortMaterial, Environment, Sparkles } from '@react-three/drei';
import { useRef } from 'react';
import * as THREE from 'three';

function OrganicBlob({ position, scale, color, speed }: { position: [number, number, number]; scale: number; color: string; speed: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      // Continuous rotation
      meshRef.current.rotation.x += 0.001 * speed;
      meshRef.current.rotation.y += 0.002 * speed;
      
      // Organic morphing with sine waves
      const time = state.clock.elapsedTime;
      meshRef.current.position.y = position[1] + Math.sin(time * 0.5 * speed) * 0.2;
    }
  });
  
  return (
    <Float
      speed={1.5 * speed}
      rotationIntensity={0.3}
      floatIntensity={0.5}
      floatingRange={[-0.15, 0.15]}
    >
      <mesh ref={meshRef} position={position} scale={scale}>
        <icosahedronGeometry args={[1, 4]} />
        <MeshDistortMaterial
          color={color}
          speed={2 * speed}
          distort={0.4}
          radius={1}
          roughness={0.1}
          metalness={0.8}
          transparent
          opacity={0.7}
        />
      </mesh>
    </Float>
  );
}

function GlassyOrb({ position, scale }: { position: [number, number, number]; scale: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += 0.001;
      meshRef.current.rotation.y += 0.002;
      
      // Color shifting
      const time = state.clock.elapsedTime;
      const hue = (time * 0.05) % 1;
      (meshRef.current.material as any).color = new THREE.Color().setHSL(hue * 0.3 + 0.5, 0.7, 0.6);
    }
  });
  
  return (
    <Float
      speed={1}
      rotationIntensity={0.2}
      floatIntensity={0.4}
      floatingRange={[-0.1, 0.1]}
    >
      <mesh ref={meshRef} position={position} scale={scale}>
        <sphereGeometry args={[1, 64, 64]} />
        <MeshTransmissionMaterial
          backside
          samples={16}
          thickness={1.5}
          chromaticAberration={1.2}
          anisotropy={1}
          distortion={0.5}
          distortionScale={0.3}
          temporalDistortion={0.2}
          iridescence={1.5}
          iridescenceIOR={1.3}
          iridescenceThicknessRange={[0, 1400]}
          transmission={0.95}
          opacity={0.9}
          roughness={0.1}
          metalness={0.9}
          color="#8b5cf6"
        />
      </mesh>
    </Float>
  );
}

function OrbitingLights() {
  const light1Ref = useRef<THREE.PointLight>(null);
  const light2Ref = useRef<THREE.PointLight>(null);
  const light3Ref = useRef<THREE.PointLight>(null);
  
  useFrame((state) => {
    const time = state.clock.elapsedTime;
    
    if (light1Ref.current) {
      light1Ref.current.position.x = Math.cos(time * 0.5) * 3;
      light1Ref.current.position.z = Math.sin(time * 0.5) * 3;
    }
    
    if (light2Ref.current) {
      light2Ref.current.position.x = Math.cos(time * 0.7 + Math.PI) * 2.5;
      light2Ref.current.position.z = Math.sin(time * 0.7 + Math.PI) * 2.5;
    }
    
    if (light3Ref.current) {
      light3Ref.current.position.y = Math.sin(time * 0.3) * 2;
    }
  });
  
  return (
    <>
      <pointLight ref={light1Ref} color="#06b6d4" intensity={2} distance={10} />
      <pointLight ref={light2Ref} color="#8b5cf6" intensity={2} distance={10} />
      <pointLight ref={light3Ref} position={[0, 2, 2]} color="#ec4899" intensity={1.5} distance={8} />
    </>
  );
}

function EnhancedSparkles() {
  const particlesRef = useRef<any>(null);
  
  useFrame((state) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y += 0.0005;
    }
  });
  
  return (
    <group ref={particlesRef}>
      <Sparkles
        count={80}
        scale={10}
        size={2.5}
        speed={0.4}
        opacity={0.6}
        color="#06b6d4"
      />
      <Sparkles
        count={60}
        scale={8}
        size={2}
        speed={0.3}
        opacity={0.5}
        color="#8b5cf6"
      />
      <Sparkles
        count={40}
        scale={6}
        size={1.5}
        speed={0.2}
        opacity={0.4}
        color="#ec4899"
      />
    </group>
  );
}

export function CalmingBackdrop() {
  return (
    <div className="absolute inset-0 -z-10 overflow-hidden">
      {/* Rich gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-purple-500/5 to-pink-500/10" />
      
      <Canvas
        camera={{ position: [0, 0, 3.5], fov: 50 }}
        dpr={[1, 1.5]}
        style={{ position: 'absolute', inset: 0 }}
        gl={{ 
          antialias: true,
          alpha: true,
          powerPreference: 'high-performance'
        }}
      >
        {/* Ambient lighting */}
        <ambientLight intensity={0.4} />
        
        {/* Orbiting colored lights for drama */}
        <OrbitingLights />
        
        {/* Rim lighting */}
        <spotLight position={[0, 5, 0]} angle={0.5} penumbra={1} intensity={0.5} color="#06b6d4" />
        <spotLight position={[0, -5, 0]} angle={0.5} penumbra={1} intensity={0.3} color="#8b5cf6" />
        
        {/* Multiple organic blobs at different depths */}
        <OrganicBlob position={[-1.5, 0.5, -1]} scale={1.2} color="#06b6d4" speed={1} />
        <OrganicBlob position={[1.2, -0.3, 0]} scale={1.5} color="#8b5cf6" speed={0.8} />
        <OrganicBlob position={[0, 0.8, -2]} scale={0.9} color="#ec4899" speed={1.2} />
        
        {/* Central glassy orb with iridescence */}
        <GlassyOrb position={[0, 0, 0.5]} scale={1.3} />
        
        {/* Enhanced multi-layered sparkles */}
        <EnhancedSparkles />
        
        {/* Studio environment for rich reflections */}
        <Environment preset="sunset" />
        
        {/* Subtle fog for depth */}
        <fog attach="fog" args={['#ffffff', 5, 15]} />
      </Canvas>
    </div>
  );
}
