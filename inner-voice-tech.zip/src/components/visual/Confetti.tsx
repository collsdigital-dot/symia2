import { motion } from "framer-motion";

interface ConfettiProps {
  show: boolean;
}

export function Confetti({ show }: ConfettiProps) {
  if (!show) return null;

  const confettiPieces = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    color: ['#a78bfa', '#f472b6', '#0ea5e9', '#fbbf24'][Math.floor(Math.random() * 4)],
    delay: Math.random() * 0.5
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {confettiPieces.map((piece) => (
        <motion.div
          key={piece.id}
          className="absolute w-3 h-3 rounded-full"
          style={{
            left: `${piece.x}%`,
            top: -20,
            backgroundColor: piece.color
          }}
          initial={{ y: -20, rotate: 0, opacity: 1 }}
          animate={{ 
            y: typeof window !== 'undefined' ? window.innerHeight + 100 : 1000,
            rotate: 720,
            opacity: [1, 1, 0]
          }}
          transition={{
            duration: 3,
            delay: piece.delay,
            ease: "easeIn"
          }}
        />
      ))}
    </div>
  );
}
