export function LightweightBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Animated gradient base */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 dark:from-purple-950/30 dark:via-blue-950/30 dark:to-pink-950/30 animate-gradient" />
      
      {/* Multiple Moving Gradient Orbs */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-primary/20 via-transparent to-transparent blur-3xl animate-pulse-slow" />
      <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-gradient-radial from-purple-500/10 via-transparent to-transparent blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-[700px] h-[700px] bg-gradient-radial from-pink-500/10 via-transparent to-transparent blur-3xl animate-float" style={{ animationDelay: '2s', animationDuration: '25s' }} />
      
      {/* Floating particles with variety */}
      <div className="absolute inset-0 overflow-hidden opacity-50">
        {[...Array(30)].map((_, i) => {
          const size = Math.random() > 0.7 ? 'w-2 h-2' : 'w-1 h-1';
          const colors = ['bg-purple-400/40', 'bg-pink-400/40', 'bg-blue-400/40', 'bg-primary/40'];
          const color = colors[Math.floor(Math.random() * colors.length)];
          
          return (
            <div
              key={i}
              className={`absolute ${size} ${color} rounded-full animate-float`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${8 + Math.random() * 15}s`
              }}
            />
          );
        })}
      </div>

      {/* Subtle Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:64px_64px] opacity-20" />
    </div>
  );
}
