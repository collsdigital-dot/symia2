import { Link, useLocation } from "react-router-dom";
import { Home, MessageSquare, Settings, MessageSquareText, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/features/auth/hooks";

interface NavButtonProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

function NavButton({ to, icon, label, isActive }: NavButtonProps) {
  return (
    <Link
      to={to}
      className={cn(
        "flex flex-col items-center justify-center gap-1 py-2 px-4 rounded-lg transition-all duration-200 min-w-[60px] min-h-[44px] relative",
        isActive
          ? "text-primary font-semibold"
          : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
      )}
    >
      {isActive && (
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-primary rounded-full" />
      )}
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </Link>
  );
}

export function BottomNav() {
  const location = useLocation();
  const { role } = useAuth();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-background/98 backdrop-blur-lg border-t shadow-[0_-2px_8px_-2px_hsl(0_0%_0%/0.1)] z-40 safe-area-inset-bottom">
      <div className="flex justify-around items-center h-16 px-2">
        <NavButton
          to="/dashboard"
          icon={<Home className="w-5 h-5" />}
          label="Home"
          isActive={location.pathname === "/dashboard"}
        />
        <NavButton
          to="/conversations"
          icon={<MessageSquareText className="w-5 h-5" />}
          label="History"
          isActive={location.pathname === "/conversations"}
        />
        {role === 'admin' && (
          <NavButton
            to="/admin"
            icon={<Shield className="w-5 h-5" />}
            label="Admin"
            isActive={location.pathname === "/admin"}
          />
        )}
        <NavButton
          to="/settings"
          icon={<Settings className="w-5 h-5" />}
          label="Settings"
          isActive={location.pathname === "/settings"}
        />
      </div>
    </nav>
  );
}
