import { useTheme } from "next-themes";
import { Toaster as Sonner, toast } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme();

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      position="top-center"
      duration={4000}
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-card group-[.toaster]:text-card-foreground group-[.toaster]:border group-[.toaster]:rounded-xl group-[.toaster]:shadow-[0_8px_16px_-4px_hsl(0_0%_0%/0.15)] group-[.toaster]:backdrop-blur-sm",
          description: "group-[.toast]:text-muted-foreground group-[.toast]:text-sm",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground group-[.toast]:rounded-lg group-[.toast]:font-medium group-[.toast]:min-h-[44px]",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground group-[.toast]:rounded-lg group-[.toast]:min-h-[44px]",
          success: "group-[.toaster]:border-primary/20 group-[.toaster]:bg-primary/5",
          error: "group-[.toaster]:border-destructive/20 group-[.toaster]:bg-destructive/5",
          warning: "group-[.toaster]:border-accent/20 group-[.toaster]:bg-accent/5",
        },
      }}
      {...props}
    />
  );
};

export { Toaster, toast };
