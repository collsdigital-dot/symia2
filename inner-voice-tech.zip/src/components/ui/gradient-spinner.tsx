export function GradientSpinner() {
  return (
    <div className="relative w-12 h-12">
      <div className="absolute inset-0 rounded-full border-4 border-transparent 
        bg-gradient-to-r from-primary via-secondary to-accent bg-clip-border 
        animate-spin" />
      <div className="absolute inset-2 rounded-full bg-background" />
    </div>
  );
}
