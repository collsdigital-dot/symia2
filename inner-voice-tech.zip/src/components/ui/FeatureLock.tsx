import { ReactNode } from "react";
import { Lock } from "lucide-react";
import { Button } from "./button";
import { useAuth } from "@/features/auth/hooks";

interface FeatureLockProps {
  isLocked: boolean;
  feature: string;
  onUpgrade: () => void;
  children: ReactNode;
}

export function FeatureLock({ isLocked, feature, onUpgrade, children }: FeatureLockProps) {
  const { isAdmin } = useAuth();
  
  // Admins bypass all feature locks
  if (!isLocked || isAdmin) {
    return <>{children}</>;
  }

  return (
    <div className="relative">
      <div className="filter blur-sm pointer-events-none opacity-50">
        {children}
      </div>
      
      <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm rounded-lg">
        <div className="text-center space-y-4 p-6">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
            <Lock className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Upgrade to Access {feature}</h3>
            <p className="text-sm text-muted-foreground mb-4">
              This feature is available with Premium plan
            </p>
            <Button onClick={onUpgrade} className="gap-2">
              <Lock className="w-4 h-4" />
              Upgrade Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
