import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const startTime = Date.now();
    console.log('[LiveAvatarOptions] === REQUEST START ===');
    console.log('[LiveAvatarOptions] Timestamp:', new Date().toISOString());
    
    const LIVEAVATAR_API_KEY = Deno.env.get('LIVEAVATAR_API_KEY');
    if (!LIVEAVATAR_API_KEY) {
      throw new Error('LIVEAVATAR_API_KEY not configured');
    }

    const { type, page = 1, pageSize = 100 } = await req.json();
    console.log('[LiveAvatarOptions] Request params:', { type, page, pageSize });
    
    let endpoint = '';
    if (type === 'avatars') {
      endpoint = `https://api.liveavatar.com/v1/avatars?page=${page}&page_size=${pageSize}`;
    } else if (type === 'voices') {
      endpoint = `https://api.liveavatar.com/v1/voices?page=${page}&page_size=${pageSize}`;
    } else {
      throw new Error('Invalid type. Use "avatars" or "voices"');
    }
    
    console.log(`[LiveAvatarOptions] Fetching from: ${endpoint}`);
    
    const fetchStart = Date.now();
    const response = await fetch(endpoint, {
      method: 'GET',
      headers: {
        'X-API-KEY': LIVEAVATAR_API_KEY,
        'Accept': 'application/json',
      }
    });
    const fetchDuration = Date.now() - fetchStart;
    
    console.log(`[LiveAvatarOptions] API response status: ${response.status} (${fetchDuration}ms)`);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[LiveAvatarOptions] API error (${response.status}):`, errorText);
      throw new Error(`LiveAvatar API returned ${response.status}: ${errorText}`);
    }
    
    const responseData = await response.json();
    console.log('[LiveAvatarOptions] Raw API response:', JSON.stringify(responseData, null, 2));
    
    // Log first item to see actual field structure
    const results = Array.isArray(responseData.data) ? responseData.data : (responseData.data?.results || []);
    if (results.length > 0) {
      console.log('[LiveAvatarOptions] First item sample:', JSON.stringify(results[0], null, 2));
    }
    
    // LiveAvatar API returns: { code: 1000, data: [...] or { results: [...] }, message: "Success" }
    if (responseData.code !== 100 && responseData.code !== 1000) {
      console.error(`[LiveAvatarOptions] API returned error code:`, responseData);
      throw new Error(`LiveAvatar API error: ${responseData.message || 'Unknown error'}`);
    }
    const pagination = { 
      page: page, 
      page_size: pageSize, 
      total: results.length 
    };
    
    const totalDuration = Date.now() - startTime;
    console.log(`[LiveAvatarOptions] ✓ Successfully fetched ${results.length} ${type} (total: ${totalDuration}ms)`);
    
    return new Response(
      JSON.stringify({
        success: true,
        data: {
          results,
          pagination
        }
      }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        }
      }
    );
  } catch (error) {
    console.error('[LiveAvatarOptions] ✗ Error:', error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred' 
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        }
      }
    );
  }
});
