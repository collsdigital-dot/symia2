import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface VideoRequest {
  type: 'welcome' | 'landing' | 'intro' | 'category';
  text?: string;
  avatarId?: string;
  backgroundUrl?: string;
  outputPath?: string;
  category?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const HEYGEN_API_KEY = Deno.env.get('HEYGEN_API_KEY');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!HEYGEN_API_KEY || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error('Missing required environment variables');
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const body: VideoRequest = await req.json();
    const { type, text, avatarId, backgroundUrl, outputPath, category } = body;

    // Determine output path based on type
    const finalOutputPath = outputPath || (() => {
      switch (type) {
        case 'welcome': return 'welcome/intro.mp4';
        case 'landing': return 'landing/intro.mp4';
        case 'intro': return 'intro/video.mp4';
        case 'category': return `category/${category || 'default'}.mp4`;
        default: return 'videos/default.mp4';
      }
    })();

    console.log(`[generate-video] Generating ${type} video at ${finalOutputPath}`);

    // Check if video already exists
    const { data: existingFile } = await supabase.storage
      .from('site-assets')
      .list(finalOutputPath.split('/')[0], {
        search: finalOutputPath.split('/')[1]
      });

    if (existingFile && existingFile.length > 0) {
      console.log(`[generate-video] Video already exists at ${finalOutputPath}`);
      const { data: { publicUrl } } = supabase.storage
        .from('site-assets')
        .getPublicUrl(finalOutputPath);

      return new Response(
        JSON.stringify({ videoUrl: publicUrl }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Default configuration
    const defaultText = text || "Welcome to SYMIA, your personal AI wellness companion. Let's take a moment to understand your needs so we can guide you toward balance, growth, and peace of mind. Ready to begin?";
    const defaultAvatarId = avatarId || "Abigail_expressive_2024112501";
    const defaultBackgroundUrl = backgroundUrl || `${SUPABASE_URL}/storage/v1/object/public/site-assets/backgrounds/mental-health-office.jpg`;

    // Prepare HeyGen API payload
    const payload = {
      video_inputs: [{
        character: {
          type: "avatar",
          avatar_id: defaultAvatarId,
          avatar_style: "closeUp"
        },
        voice: {
          type: "text",
          input_text: defaultText,
          voice_id: "f8c69e517f424cafaecde32dde57096b"
        },
        background: {
          type: "image",
          url: defaultBackgroundUrl
        }
      }],
      dimension: {
        width: 1280,
        height: 720
      },
      test: false,
      aspect_ratio: "16:9"
    };

    console.log('[generate-video] Calling HeyGen API...');
    const generateResponse = await fetch('https://api.heygen.com/v2/video/generate', {
      method: 'POST',
      headers: {
        'X-Api-Key': HEYGEN_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!generateResponse.ok) {
      const errorText = await generateResponse.text();
      console.error('[generate-video] HeyGen API error:', errorText);
      throw new Error(`HeyGen API error: ${generateResponse.status}`);
    }

    const generateData = await generateResponse.json();
    const videoId = generateData.data.video_id;
    console.log('[generate-video] Video generation started, ID:', videoId);

    // Poll for video completion
    let videoUrl = null;
    let attempts = 0;
    const maxAttempts = 60; // 5 minutes with 5 second intervals

    while (!videoUrl && attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      attempts++;

      const statusResponse = await fetch(
        `https://api.heygen.com/v1/video_status.get?video_id=${videoId}`,
        {
          headers: {
            'X-Api-Key': HEYGEN_API_KEY,
          },
        }
      );

      if (!statusResponse.ok) {
        console.error('[generate-video] Status check failed:', await statusResponse.text());
        continue;
      }

      const statusData = await statusResponse.json();
      console.log(`[generate-video] Poll attempt ${attempts}: Status = ${statusData.data.status}`);

      if (statusData.data.status === 'completed') {
        videoUrl = statusData.data.video_url;
        break;
      } else if (statusData.data.status === 'failed') {
        console.error('[generate-video] HeyGen status failed:', JSON.stringify(statusData));
        throw new Error('Video generation failed');
      }
    }

    if (!videoUrl) {
      throw new Error('Video generation timed out');
    }

    console.log('[generate-video] Video generated, downloading...');

    // Download the video
    const videoResponse = await fetch(videoUrl);
    if (!videoResponse.ok) {
      throw new Error('Failed to download video');
    }

    const videoBlob = await videoResponse.blob();
    const videoArrayBuffer = await videoBlob.arrayBuffer();

    console.log('[generate-video] Uploading to Supabase Storage...');

    // Upload to Supabase Storage
    const { error: uploadError } = await supabase.storage
      .from('site-assets')
      .upload(finalOutputPath, videoArrayBuffer, {
        contentType: 'video/mp4',
        upsert: true
      });

    if (uploadError) {
      console.error('[generate-video] Upload error:', uploadError);
      throw uploadError;
    }

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('site-assets')
      .getPublicUrl(finalOutputPath);

    console.log('[generate-video] Video generated and uploaded successfully');

    return new Response(
      JSON.stringify({ videoUrl: publicUrl }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[generate-video] Error:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
