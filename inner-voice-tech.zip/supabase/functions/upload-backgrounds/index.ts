import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const backgrounds = [
      { name: 'mental-health-office.jpg', path: 'backgrounds/mental-health-office.jpg' },
      { name: 'life-coaching-office.jpg', path: 'backgrounds/life-coaching-office.jpg' },
      { name: 'business-strategy-office.jpg', path: 'backgrounds/business-strategy-office.jpg' },
      { name: 'relationships-office.jpg', path: 'backgrounds/relationships-office.jpg' },
    ];

    const results = [];

    // Use direct URLs from your deployed app
    const baseUrl = 'https://id-preview--e2285508-faa4-4938-a51e-5fb77e203dc7.lovable.app';

    for (const bg of backgrounds) {
      try {
        // Fetch from the deployed app's public folder
        const publicUrl = `${baseUrl}/${bg.path}`;
        console.log(`Fetching: ${publicUrl}`);
        
        const response = await fetch(publicUrl);
        if (!response.ok) {
          console.error(`Failed to fetch ${bg.name}: ${response.status}`);
          results.push({ file: bg.name, status: 'failed', error: `HTTP ${response.status}` });
          continue;
        }

        const imageBlob = await response.arrayBuffer();
        
        // Upload to storage
        const { data, error } = await supabase.storage
          .from('site-assets')
          .upload(`backgrounds/${bg.name}`, imageBlob, {
            contentType: 'image/jpeg',
            upsert: true,
          });

        if (error) {
          console.error(`Upload error for ${bg.name}:`, error);
          results.push({ file: bg.name, status: 'failed', error: error.message });
        } else {
          console.log(`✅ Uploaded: ${bg.name}`);
          results.push({ file: bg.name, status: 'success', path: data.path });
        }
      } catch (err) {
        console.error(`Error processing ${bg.name}:`, err);
        results.push({ file: bg.name, status: 'error', error: String(err) });
      }
    }

    return new Response(
      JSON.stringify({ results }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Upload backgrounds error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
