import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, otp } = await req.json();

    if (!email || !otp) {
      return new Response(
        JSON.stringify({ error: "Email and OTP code are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });

    console.log("Looking for OTP:", { email: email.toLowerCase(), otp, currentTime: new Date().toISOString() });

    // Find the OTP code
    const { data: otpData, error: fetchError } = await supabase
      .from("otp_codes")
      .select("*")
      .eq("email", email.toLowerCase())
      .eq("otp_code", otp)
      .eq("is_used", false)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    console.log("OTP lookup result:", { found: !!otpData, error: fetchError?.message, expired: otpData ? false : "likely expired or invalid" });

    if (fetchError || !otpData) {
      // Secondary check: recently used code within last 2 minutes (helps recover from partial flows)
      const nowIso = new Date().toISOString();
      const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000).toISOString();

      const { data: usedOtp } = await supabase
        .from("otp_codes")
        .select("*")
        .eq("email", email.toLowerCase())
        .eq("otp_code", otp)
        .eq("is_used", true)
        .gt("expires_at", nowIso)
        .gte("created_at", twoMinutesAgo)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (usedOtp) {
        console.log("Found recently used OTP, regenerating auth link...");
        // Generate magic link again without touching the OTP row
        const generateResult = await supabase.auth.admin.generateLink({
          type: 'magiclink',
          email: email.toLowerCase(),
        });

        if (generateResult.error || !generateResult.data || !generateResult.data.properties) {
          console.error("Error generating auth link (used flow):", generateResult.error);
          return new Response(
            JSON.stringify({ error: "Failed to create session" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        return new Response(
          JSON.stringify({ 
            success: true,
            token: generateResult.data.properties.hashed_token,
            email: email.toLowerCase()
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Check all OTPs for this email to help debug
      const { data: allOtps } = await supabase
        .from("otp_codes")
        .select("*")
        .eq("email", email.toLowerCase())
        .order("created_at", { ascending: false })
        .limit(5);
      
      console.log("Recent OTPs for this email:", allOtps);
      
      // Increment attempts on the most recent OTP for this email/code combo
      const { data: recentOtp } = await supabase
        .from("otp_codes")
        .select("*")
        .eq("email", email.toLowerCase())
        .eq("otp_code", otp)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (recentOtp && recentOtp.attempts < 10) {
        await supabase
          .from("otp_codes")
          .update({ attempts: recentOtp.attempts + 1 })
          .eq("id", recentOtp.id);
      }

      return new Response(
        JSON.stringify({ error: "Invalid or expired code. Please try again." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check attempt limit
    if (otpData.attempts >= 3) {
      return new Response(
        JSON.stringify({ error: "Too many attempts. Please request a new code." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Mark OTP as used
    const { error: updateError } = await supabase
      .from("otp_codes")
      .update({ is_used: true })
      .eq("id", otpData.id);

    if (updateError) {
      console.error("Error marking OTP as used:", updateError);
    }

    // Create user if doesn't exist, then generate magic link
    let authData;
    let authError;

    // Try to generate link first
    const generateResult = await supabase.auth.admin.generateLink({
      type: 'magiclink',
      email: email.toLowerCase(),
    });

    if (generateResult.error?.message?.includes("User not found")) {
      // Create user first
      console.log("User not found, creating new user...");
      const { error: createError } = await supabase.auth.admin.createUser({
        email: email.toLowerCase(),
        email_confirm: true,
      });

      if (createError) {
        console.error("Error creating user:", createError);
        return new Response(
          JSON.stringify({ error: "Failed to create user account" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Try generating link again
      const retryResult = await supabase.auth.admin.generateLink({
        type: 'magiclink',
        email: email.toLowerCase(),
      });

      authData = retryResult.data;
      authError = retryResult.error;
    } else {
      authData = generateResult.data;
      authError = generateResult.error;
    }

    if (authError || !authData || !authData.properties) {
      console.error("Error generating auth link:", authError);
      return new Response(
        JSON.stringify({ error: "Failed to create session" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        token: authData.properties.hashed_token,
        email: email.toLowerCase()
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error in verify-otp:", error);

    return new Response(
      JSON.stringify({ error: error?.message || "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
