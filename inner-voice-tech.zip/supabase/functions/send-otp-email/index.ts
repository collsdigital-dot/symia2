import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email } = await req.json();

    if (!email || !email.includes("@")) {
      return new Response(
        JSON.stringify({ error: "Valid email is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Rate limiting: allow unlimited during preview (Lovable) to ease testing
    const origin = req.headers.get("origin") ?? req.headers.get("referer") ?? "";
    const isPreview = typeof origin === 'string' && origin.includes('.lovableproject.com');

    // Rate limiting: Check if user has requested OTP recently (max 10 per hour for testing)
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { data: recentOtps, error: countError } = await supabase
      .from("otp_codes")
      .select("id, created_at")
      .eq("email", email.toLowerCase())
      .gte("created_at", oneHourAgo)
      .order("created_at", { ascending: true });

    if (countError) {
      console.error("Error checking rate limit:", countError);
    }

    if (!isPreview && recentOtps && recentOtps.length >= 10) {
      const oldestRequestTime = new Date(recentOtps[0].created_at).getTime();
      const minutesRemaining = Math.max(1, Math.ceil((oldestRequestTime + 60 * 60 * 1000 - Date.now()) / 60000));
      return new Response(
        JSON.stringify({ 
          error: `Rate limit reached (10 codes per hour). Try again in ${minutesRemaining} minutes or use an existing code.` 
        }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (isPreview) {
      console.log("Bypassing OTP rate limit for preview origin:", origin);
    }

    // Generate 6-digit OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();

    // Store OTP in database
    const { error: insertError } = await supabase
      .from("otp_codes")
      .insert({
        email: email.toLowerCase(),
        otp_code: otpCode,
        expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
      });

    if (insertError) {
      console.error("Error storing OTP:", insertError);
      return new Response(
        JSON.stringify({ error: "Failed to generate verification code" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Extract first name from email (before @)
    const firstName = email.split("@")[0].charAt(0).toUpperCase() + email.split("@")[0].slice(1);

    // Send email via Resend using direct fetch (following Resend documentation)
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: 'SYMIA <onboarding@resend.dev>',
        to: [email],
        subject: 'Your SYMIA Verification Code',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <p style="font-size: 16px; color: #333;">Hi ${firstName},</p>
            
            <p style="font-size: 16px; color: #333; margin: 20px 0;">
              Your verification code is: <strong style="font-size: 24px; color: #8B5CF6; letter-spacing: 2px;">${otpCode}</strong>
            </p>
            
            <p style="font-size: 16px; color: #333;">
              Enter this code in the app to continue.<br/>
              This code will expire in 10 minutes.
            </p>
            
            <p style="font-size: 14px; color: #666; margin: 30px 0;">
              If you didn't request this, you can safely ignore this email.
            </p>
            
            <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;" />
            
            <p style="font-size: 14px; color: #8B5CF6; text-align: center;">
              – The SYMIA Team
            </p>
          </div>
        `,
      }),
    });

    const emailData = await res.json();

    if (!res.ok || emailData.error) {
      console.error("Error sending email:", emailData);
      
      // Provide specific error message for Resend test mode restriction
      const errorMessage = emailData.error?.message || emailData.message || "";
      if (res.status === 403 || errorMessage.toLowerCase().includes("testing emails")) {
        return new Response(
          JSON.stringify({ 
            error: "⚠️ Resend is in test mode. For testing, please use: collsdigital@gmail.com\n\nTo send to other emails, verify a domain at https://resend.com/domains" 
          }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: emailData.error?.message || "Failed to send verification email" }),
        { status: res.status || 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Clean up old expired codes (fire and forget)
    supabase.rpc("cleanup_expired_otps").then(() => console.log("Cleanup complete"));

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error in send-otp-email:", error);
    return new Response(
      JSON.stringify({ error: error?.message || "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
