import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { action, feature } = await req.json();

    // Get or create usage limits
    let { data: limits, error: limitsError } = await supabase
      .from('usage_limits')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (limitsError && limitsError.code === 'PGRST116') {
      // Create new limits record
      const { data: newLimits, error: createError } = await supabase
        .from('usage_limits')
        .insert({
          user_id: user.id,
          subscription_tier: 'free',
          live_demos_limit: 0,
        })
        .select()
        .single();

      if (createError) throw createError;
      limits = newLimits;
    } else if (limitsError) {
      throw limitsError;
    }

    // Check if reset date has passed
    const now = new Date();
    const resetDate = new Date(limits.reset_date);
    
    if (now > resetDate) {
      // Reset counters
      const { data: resetLimits, error: resetError } = await supabase
        .from('usage_limits')
        .update({
          live_demos_used: 0,
          text_chats_used: 0,
          reset_date: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        })
        .eq('user_id', user.id)
        .select()
        .single();

      if (resetError) throw resetError;
      limits = resetLimits;
    }

    if (action === 'check') {
      const canUse = feature === 'live_demo' 
        ? limits.live_demos_used < limits.live_demos_limit
        : true;

      return new Response(
        JSON.stringify({ 
          success: true, 
          canUse,
          limits: {
            tier: limits.subscription_tier,
            liveDemosUsed: limits.live_demos_used,
            liveDemosLimit: limits.live_demos_limit,
            resetDate: limits.reset_date,
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'increment') {
      const updateField = feature === 'live_demo' ? 'live_demos_used' : 'text_chats_used';
      
      const { data: updated, error: updateError } = await supabase
        .from('usage_limits')
        .update({
          [updateField]: limits[updateField] + 1,
        })
        .eq('user_id', user.id)
        .select()
        .single();

      if (updateError) throw updateError;

      return new Response(
        JSON.stringify({ success: true, limits: updated }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    throw new Error('Invalid action. Use "check" or "increment"');

  } catch (error) {
    console.error('Check usage limits error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
