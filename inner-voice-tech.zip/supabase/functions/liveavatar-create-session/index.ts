import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Single universal Symia-Coach context - no longer need category-specific prompts

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const requestStartTime = Date.now();
    console.log('[LiveAvatar] === SESSION CREATION START ===');
    console.log('[LiveAvatar] Timestamp:', new Date().toISOString());
    
    const LIVEAVATAR_API_KEY = Deno.env.get('LIVEAVATAR_API_KEY');
    if (!LIVEAVATAR_API_KEY) {
      throw new Error('LIVEAVATAR_API_KEY not configured');
    }

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { avatarId, category, language = 'en-US' } = await req.json();
    console.log('[LiveAvatar] Request payload:', JSON.stringify({ avatarId, category, language }, null, 2));

    // Initialize backend client and resolve user early (used for context caching)
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    const jwt = authHeader.replace('Bearer ', '');
    const { data: { user } } = await supabase.auth.getUser(jwt);

    // Accept both UUID and string-based avatar IDs (e.g., "Angela-inblackskirt-20220820")
    console.log('[LiveAvatar] Using avatar_id:', avatarId);

    // Load cached context from user profile
    let contextId: string | null = null;
    
    if (user) {
      const { data: profile } = await supabase
        .from('user_profiles')
        .select('liveavatar_context_id')
        .eq('user_id', user.id)
        .maybeSingle();
      
      contextId = profile?.liveavatar_context_id ?? null;
      if (contextId) {
        console.log('[LiveAvatar] ✓ Using cached context from profile:', contextId);
      }
    }

    // Ensure a context (knowledge base) exists
    const contextName = 'Symia-Coach';
    
    console.log('[LiveAvatar] === CONTEXT RESOLUTION START ===');
    console.log('[LiveAvatar] Context name:', contextName);

    // Try to find existing context by name on provider side first (avoids duplicate errors)
    if (!contextId) {
      console.log('[LiveAvatar] No cached context, searching LiveAvatar API by name...');
      const contextSearchStart = Date.now();
      try {
        const listResp = await fetch('https://api.liveavatar.com/v1/contexts?page=1&page_size=100', {
          method: 'GET',
          headers: { 'X-API-KEY': LIVEAVATAR_API_KEY, 'Accept': 'application/json' }
        });
        const contextSearchDuration = Date.now() - contextSearchStart;
        console.log('[LiveAvatar] Context list API response status:', listResp.status, `(${contextSearchDuration}ms)`);
        
        if (listResp.ok) {
          const listData = await listResp.json();
          console.log('[LiveAvatar] Context list response:', JSON.stringify(listData, null, 2));
          const existing = listData?.data?.results?.find((c: any) => c?.name === contextName);
          if (existing?.id) {
            contextId = existing.id;
            console.log('[LiveAvatar] ✓ Reusing existing context by name:', contextId);
          }
        }
      } catch (e) {
        console.warn('[LiveAvatar] Failed to list contexts, will try to create:', e);
      }
    }

    // Create context if needed
    if (!contextId) {
      console.log('[LiveAvatar] Creating new context for category:', category);
      const contextCreateStart = Date.now();
      
      const contextResp = await fetch('https://api.liveavatar.com/v1/contexts', {
        method: 'POST',
        headers: { 'X-API-KEY': LIVEAVATAR_API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: contextName,
          prompt: `## PERSONA
You are Symia, a warm, empathetic wellness coach and trusted companion. You support people across all life areas: mental health, personal growth, business strategy, and relationships.

## YOUR ROLE
- Listen deeply and ask thoughtful follow-up questions
- Help users clarify goals, feelings, and next steps
- Provide practical strategies, not generic advice
- Adapt your approach to what the user needs most right now
- Maintain a warm, non-judgmental, encouraging tone

## RESPONSE CONSTRAINTS (CRITICAL FOR VOICE)
- Maximum 30 words per response
- Speak naturally, conversationally — like a friend
- Use light fillers: "yeah", "right", "okay", "gotcha"
- Never list or number things
- Ask one question at a time
- Keep responses short and flowing

## COMMUNICATION STYLE
- Be warm but professional
- Mirror the user's energy (calm if they're stressed, upbeat if excited)
- Use reflection: "So it sounds like..." to show you're listening
- Validate feelings before offering solutions
- Stay curious — ask "what" and "how" questions

## CONVERSATION FLOW
1. Start: Greet warmly, ask open-ended: "What's on your mind today?"
2. Explore: Ask follow-ups to understand context and feelings
3. Clarify: Reflect back what you heard: "So you're feeling..."
4. Support: Offer one practical insight, question, or reframe
5. Guide Forward: Ask what feels most helpful next

## BOUNDARIES
- You're a coach, not a therapist or medical professional
- If user mentions crisis (self-harm, danger), say: "I care about your safety. Please reach out to a crisis line or trusted person right now."
- Decline unrelated requests politely: "Let's stay focused on supporting you."

## EXAMPLE EXCHANGES

User: "I'm so overwhelmed with work lately."
Symia: "That sounds really tough. What's making it feel most overwhelming right now?"

User: "I don't know if I should quit my job."
Symia: "Big decision. What's pulling you toward leaving — and what's keeping you there?"

User: "My partner and I keep arguing."
Symia: "That must be draining. What's the pattern you're noticing in those arguments?"

User: "I want to start a business but I'm scared."
Symia: "Totally normal fear. What part of starting feels scariest to you?"`,
          opening_text: "Hi! I'm Symia, your wellness coach. I'm here to support you through whatever's on your mind — whether it's stress, goals, work challenges, or relationships. What's on your mind today?"
        })
      });

      const contextCreateDuration = Date.now() - contextCreateStart;
      console.log('[LiveAvatar] Context create API response status:', contextResp.status, `(${contextCreateDuration}ms)`);

      if (!contextResp.ok) {
        const txt = await contextResp.text();
        console.error('[LiveAvatar] Context creation failed:', txt);
        
        try {
          const parsed = JSON.parse(txt);
          const msg = parsed?.message || '';
          
          // If name already exists, fetch it and reuse
          if (contextResp.status === 400 && msg.includes('Context with this name already exists')) {
            console.log('[LiveAvatar] Context name conflict, searching for existing...');
            const retryList = await fetch('https://api.liveavatar.com/v1/contexts?page=1&page_size=100', {
              headers: { 'X-API-KEY': LIVEAVATAR_API_KEY, 'Accept': 'application/json' }
            });
            const retryData = await retryList.json();
            const match = retryData?.data?.results?.find((c: any) => c?.name === contextName);
            if (match?.id) {
              contextId = match.id;
              console.log('[LiveAvatar] ✓ Found existing context after conflict:', contextId);
            } else {
              throw new Error('Context name exists but could not be found');
            }
          } else {
            throw new Error(`Failed to create context: ${contextResp.status} - ${txt}`);
          }
        } catch (parseError) {
          throw new Error(`Failed to create context: ${contextResp.status} - ${txt}`);
        }
      } else {
        const contextData = await contextResp.json();
        console.log('[LiveAvatar] Context creation response:', JSON.stringify(contextData, null, 2));
        
        const ctxId = contextData?.data?.id || contextData?.id;
        if (!ctxId) {
          throw new Error(`Failed to parse context id from response: ${JSON.stringify(contextData)}`);
        }
        contextId = ctxId;
        console.log('[LiveAvatar] ✓ Context created:', contextId);
      }
    }

    // Persist context to user profile
    if (user && contextId) {
      await supabase
        .from('user_profiles')
        .update({ 
          liveavatar_context_id: contextId
        })
        .eq('user_id', user.id);
      console.log('[LiveAvatar] ✓ Cached context to profile');
    }

    // Validate we have context_id (knowledge base)
    if (!contextId || contextId.length < 10) {
      console.error('[LiveAvatar] Invalid or empty context_id:', contextId);
      throw new Error(`Failed to resolve valid context_id: ${contextId}`);
    }
    console.log('[LiveAvatar] Using context_id:', contextId);

    console.log('[LiveAvatar] === SESSION TOKEN CREATION START ===');
    console.log('[LiveAvatar] Using configuration:', { 
      mode: 'FULL',
      avatar_id: avatarId, 
      context_id: contextId,
      language: language || 'en'
    });

    // Step 1: Create session token with LiveAvatar API
    // Using the correct FULL mode structure with avatar_persona
    const requestBody: any = {
      mode: "FULL",  // Required discriminator for LiveAvatar API
      avatar_id: avatarId,
      avatar_persona: {
        context_id: contextId,  // Use context_id, not knowledge_base_id
        language: language || "en"
      }
    };

    console.log('[LiveAvatar] Step 1: Creating session token with payload:', JSON.stringify(requestBody, null, 2));

    const tokenCreateStart = Date.now();
    const tokenResponse = await fetch('https://api.liveavatar.com/v1/sessions/token', {
      method: 'POST',
      headers: {
        'X-API-KEY': LIVEAVATAR_API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    const tokenCreateDuration = Date.now() - tokenCreateStart;
    console.log('[LiveAvatar] Token create API response status:', tokenResponse.status, `(${tokenCreateDuration}ms)`);

    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text();
      console.error('[LiveAvatar] ✗ Token API error details:', {
        status: tokenResponse.status,
        statusText: tokenResponse.statusText,
        body: errorText,
        requestPayload: requestBody
      });
      
      return new Response(
        JSON.stringify({
          success: false,
          code: 'TOKEN_CREATE_FAILED',
          error: `LiveAvatar token creation failed: ${tokenResponse.status}`,
          details: errorText
        }),
        {
          status: 502,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const tokenData = await tokenResponse.json();
    console.log('[LiveAvatar] Token creation response:', JSON.stringify(tokenData, null, 2));
    
    // Check API response code
    if (tokenData.code !== 1000) {
      console.error('[LiveAvatar] ✗ Token API returned error code:', tokenData);
      throw new Error(`LiveAvatar API error: ${tokenData.message || 'Unknown error'}`);
    }

    const sessionToken = tokenData.data.session_token;
    const sessionId = tokenData.data.session_id;
    console.log('[LiveAvatar] ✓ Token created, session_id:', sessionId);

    // Step 2: Start the session
    console.log('[LiveAvatar] === SESSION START ===');
    console.log('[LiveAvatar] Step 2: Starting session with token...');
    
    const sessionStartStart = Date.now();
    const startResponse = await fetch('https://api.liveavatar.com/v1/sessions/start', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${sessionToken}`,
        'Accept': 'application/json'
      }
    });

    const sessionStartDuration = Date.now() - sessionStartStart;
    console.log('[LiveAvatar] Session start API response status:', startResponse.status, `(${sessionStartDuration}ms)`);

    if (!startResponse.ok) {
      const errorText = await startResponse.text();
      console.error('[LiveAvatar] ✗ Session start API error:', startResponse.status, errorText);
      console.error('[LiveAvatar] ✗ Full error context:', {
        status: startResponse.status,
        avatarId,
        contextId,
        language,
        responseBody: errorText
      });
      
      // Check for "no credits" error
      try {
        const errorData = JSON.parse(errorText);
        if (startResponse.status === 403 && errorData.code === 4003) {
          return new Response(
            JSON.stringify({
              success: false,
              code: 'NO_CREDITS',
              error: 'Your LiveAvatar account has no credits. Please top up or update API key.',
              avatarId: avatarId
            }),
            {
              status: 402,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            }
          );
        }
      } catch (e) {
        // Not JSON or different error structure
      }
      
      return new Response(
        JSON.stringify({
          success: false,
          code: 'SESSION_START_FAILED',
          error: `LiveAvatar session start failed: ${startResponse.status}`,
          details: errorText,
          avatarId: avatarId
        }),
        {
          status: 502,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const startData = await startResponse.json();
    console.log('[LiveAvatar] Session start response:', JSON.stringify(startData, null, 2));
    
    // Check API response code
    if (startData.code !== 1000) {
      console.error('[LiveAvatar] ✗ Session start API returned error code:', startData);
      throw new Error(`LiveAvatar start error: ${startData.message || 'Unknown error'}`);
    }

    const totalDuration = Date.now() - requestStartTime;
    console.log('[LiveAvatar] ✓ SESSION STARTED SUCCESSFULLY');
    console.log('[LiveAvatar] Total request duration:', `${totalDuration}ms`);

    if (user) {
      // Store session in database
      const { error: dbError } = await supabase.from('liveavatar_sessions').insert({
        user_id: user.id,
        session_id: sessionId,
        avatar_id: avatarId,
        voice_id: null,  // No longer using voice_id
        context_id: contextId,
        category: category,
        status: 'active'
      });
      
      if (dbError) {
        console.error('[LiveAvatar] Failed to store session in database:', dbError);
        // Don't throw - session is already started, just log the error
      } else {
        console.log('[LiveAvatar] ✓ Session stored in database');
      }
    }

    const responsePayload = {
      success: true,
      data: {
        session_token: sessionToken,
        session_id: sessionId,
        livekit_url: startData.data.livekit_url,
        livekit_client_token: startData.data.livekit_client_token,
        max_session_duration: startData.data.max_session_duration,
        ws_url: startData.data.ws_url
      }
    };

    console.log('[LiveAvatar] Final response payload:', JSON.stringify(responsePayload, null, 2));

    return new Response(
      JSON.stringify(responsePayload),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200
      }
    );

  } catch (error) {
    console.error('[LiveAvatar] Error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
