import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { storageKey, message, background } = await req.json();
    
    if (!storageKey || !message) {
      return new Response(
        JSON.stringify({ error: "storageKey and message are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const heygenApiKey = Deno.env.get("HEYGEN_API_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!heygenApiKey || !supabaseUrl || !supabaseServiceKey) {
      console.error("Missing required environment variables");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if video already exists
    const { data: existingFile } = await supabase.storage
      .from("site-assets")
      .list(storageKey.split('/')[0], {
        search: storageKey.split('/')[1]
      });

    if (existingFile && existingFile.length > 0) {
      console.log(`Video already exists at ${storageKey}, returning cached URL`);
      const { data: urlData } = supabase.storage
        .from("site-assets")
        .getPublicUrl(storageKey);
      
      return new Response(
        JSON.stringify({ video_url: urlData.publicUrl }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Generating video for: ${storageKey}`);

    // Determine background configuration
    let backgroundConfig: any = { type: "color", value: "#F5F5DC" }; // Default warm beige
    
    if (background) {
      if (background.type === "color" && background.value) {
        backgroundConfig = { type: "color", value: background.value };
      } else if (background.type === "image" && background.url) {
        backgroundConfig = { type: "image", url: background.url };
      } else if (background.type === "green_screen") {
        backgroundConfig = { type: "green_screen" };
      }
    }

    // Create video using HeyGen API with custom background support
    const heygenPayload = {
      video_inputs: [{
        character: {
          type: "avatar",
          avatar_id: "Abigail_expressive_2024112501",
          avatar_style: "normal"
        },
        voice: {
          type: "text",
          input_text: message,
          voice_id: "f8c69e517f424cafaecde32dde57096b"
        },
        background: backgroundConfig
      }],
      dimension: { width: 1920, height: 1080 },
      test: false
    };
    
    console.log("Background config:", JSON.stringify(backgroundConfig));

    console.log("Calling HeyGen API to generate video...");
    const generateResponse = await fetch("https://api.heygen.com/v2/video/generate", {
      method: "POST",
      headers: {
        "X-Api-Key": heygenApiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(heygenPayload),
    });

    if (!generateResponse.ok) {
      const errorText = await generateResponse.text();
      console.error("HeyGen API error:", generateResponse.status, errorText);
      return new Response(
        JSON.stringify({ error: "Failed to generate video", details: errorText }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const generateData = await generateResponse.json();
    const videoId = generateData.data?.video_id;

    if (!videoId) {
      console.error("No video_id in response:", generateData);
      return new Response(
        JSON.stringify({ error: "No video ID returned from HeyGen" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Video generation started with ID: ${videoId}`);

    // Poll for video status
    let videoUrl = null;
    let attempts = 0;
    const maxAttempts = 60; // 5 minutes max

    while (attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
      
      const statusResponse = await fetch(`https://api.heygen.com/v1/video_status.get?video_id=${videoId}`, {
        headers: { "X-Api-Key": heygenApiKey },
      });

      if (!statusResponse.ok) {
        console.error("Failed to check video status:", statusResponse.status);
        attempts++;
        continue;
      }

      const statusData = await statusResponse.json();
      const status = statusData.data?.status;
      
      console.log(`Video status (attempt ${attempts + 1}): ${status}`);

      if (status === "completed") {
        videoUrl = statusData.data?.video_url;
        break;
      } else if (status === "failed") {
        console.error("Video generation failed:", statusData.data?.error);
        return new Response(
          JSON.stringify({ error: "Video generation failed", details: statusData.data?.error }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      attempts++;
    }

    if (!videoUrl) {
      return new Response(
        JSON.stringify({ error: "Video generation timed out" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Video ready, downloading from: ${videoUrl}`);

    // Download the video
    const videoResponse = await fetch(videoUrl);
    if (!videoResponse.ok) {
      console.error("Failed to download video:", videoResponse.status);
      return new Response(
        JSON.stringify({ error: "Failed to download generated video" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const videoBlob = await videoResponse.blob();
    const videoBuffer = await videoBlob.arrayBuffer();

    console.log(`Uploading video to storage: ${storageKey}`);

    // Upload to Supabase Storage
    const { error: uploadError } = await supabase.storage
      .from("site-assets")
      .upload(storageKey, videoBuffer, {
        contentType: "video/mp4",
        upsert: true,
      });

    if (uploadError) {
      console.error("Storage upload error:", uploadError);
      return new Response(
        JSON.stringify({ error: "Failed to upload video to storage", details: uploadError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: urlData } = supabase.storage
      .from("site-assets")
      .getPublicUrl(storageKey);

    console.log(`Video successfully uploaded to: ${urlData.publicUrl}`);

    return new Response(
      JSON.stringify({ video_url: urlData.publicUrl }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
