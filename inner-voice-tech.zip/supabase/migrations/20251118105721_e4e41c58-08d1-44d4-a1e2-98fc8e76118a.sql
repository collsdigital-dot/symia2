-- Update existing user profiles from public avatar string ID to UUID format
UPDATE public.user_profiles 
SET liveavatar_id = '1c690fe7-23e0-49f9-bfba-14344450285b'
WHERE liveavatar_id = 'Angela-inblackskirt-20220820' 
   OR liveavatar_id = 'Pedro_CasualLook_public'
   OR liveavatar_id NOT SIMILAR TO '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';