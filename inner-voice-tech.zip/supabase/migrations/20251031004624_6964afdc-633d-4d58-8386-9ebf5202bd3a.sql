-- Create table for tracking HeyGen video generation usage and costs
CREATE TABLE IF NOT EXISTS public.heygen_usage_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  video_id text NOT NULL,
  category text NOT NULL,
  duration_seconds integer NOT NULL DEFAULT 60,
  cost_usd numeric(10,2) NOT NULL DEFAULT 1.00,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.heygen_usage_logs ENABLE ROW LEVEL SECURITY;

-- Users can view their own usage logs
CREATE POLICY "Users can view their own usage logs"
ON public.heygen_usage_logs
FOR SELECT
USING (auth.uid() = user_id);

-- Service role can insert usage logs
CREATE POLICY "Service role can insert usage logs"
ON public.heygen_usage_logs
FOR INSERT
WITH CHECK (true);

-- Add index for better query performance
CREATE INDEX idx_heygen_usage_user_id ON public.heygen_usage_logs(user_id);
CREATE INDEX idx_heygen_usage_created_at ON public.heygen_usage_logs(created_at);