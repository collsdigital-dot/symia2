-- Create storage bucket for site assets (landing video, etc.)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'site-assets',
  'site-assets',
  true,
  52428800, -- 50MB limit
  ARRAY['video/mp4', 'video/webm', 'image/jpeg', 'image/png', 'image/webp']
);

-- Allow public read access to site assets
CREATE POLICY "Public read access to site assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'site-assets');

-- Allow service role to write site assets
CREATE POLICY "Service role can manage site assets"
ON storage.objects FOR ALL
USING (bucket_id = 'site-assets' AND auth.role() = 'service_role')
WITH CHECK (bucket_id = 'site-assets' AND auth.role() = 'service_role');

-- Add HeyGen avatar fields to user_profiles
ALTER TABLE public.user_profiles 
ADD COLUMN IF NOT EXISTS avatar_provider text NOT NULL DEFAULT 'heygen',
ADD COLUMN IF NOT EXISTS heygen_avatar_id text NOT NULL DEFAULT 'Angela-inblackskirt-20220820',
ADD COLUMN IF NOT EXISTS heygen_voice_id text DEFAULT NULL;