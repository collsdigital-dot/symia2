-- Create temporary RPM sessions table
CREATE TABLE IF NOT EXISTS public.rpm_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  rpm_token TEXT NOT NULL,
  rpm_user_id TEXT NOT NULL,
  rpm_avatar_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL
);

-- Enable RLS
ALTER TABLE public.rpm_sessions ENABLE ROW LEVEL SECURITY;

-- Users can only manage their own sessions
CREATE POLICY "Users can manage own RPM sessions"
  ON public.rpm_sessions
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Index for cleanup queries
CREATE INDEX idx_rpm_sessions_expires_at ON public.rpm_sessions(expires_at);
CREATE INDEX idx_rpm_sessions_user_id ON public.rpm_sessions(user_id);