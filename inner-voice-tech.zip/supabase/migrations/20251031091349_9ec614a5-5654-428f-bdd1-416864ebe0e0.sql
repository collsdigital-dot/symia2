-- Ensure all users have a default background
UPDATE user_profiles 
SET video_background = '{"type": "color", "value": "#F5F5DC"}'::jsonb
WHERE video_background IS NULL OR video_background = 'null'::jsonb;