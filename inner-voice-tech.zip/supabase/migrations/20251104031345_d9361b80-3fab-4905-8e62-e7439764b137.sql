-- Fix RLS policies for user_profiles to allow INSERT
DROP POLICY IF EXISTS "Users can insert own profile" ON public.user_profiles;

-- Recreate INSERT policy with proper permissions
CREATE POLICY "Users can insert own profile"
ON public.user_profiles
FOR INSERT
TO public
WITH CHECK (auth.uid() = user_id);

-- Ensure RLS is enabled
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;