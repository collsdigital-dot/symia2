-- Add unique index on rpm_sessions(user_id) for proper upsert
CREATE UNIQUE INDEX IF NOT EXISTS ux_rpm_sessions_user_id ON public.rpm_sessions(user_id);

-- Add conversation_id to live_sessions for continuity
ALTER TABLE public.live_sessions
  ADD COLUMN IF NOT EXISTS conversation_id uuid REFERENCES public.chat_conversations(id) ON DELETE SET NULL;

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_live_sessions_conversation_id ON public.live_sessions(conversation_id);