-- Remove persona_id column from user_profiles as it's no longer needed
-- The LiveAvatar API doesn't use a separate persona concept
-- We now use knowledge_base_id (context) directly in session creation

ALTER TABLE public.user_profiles 
DROP COLUMN IF EXISTS liveavatar_persona_id;