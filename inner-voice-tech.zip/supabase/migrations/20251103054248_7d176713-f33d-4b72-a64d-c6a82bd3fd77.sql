-- Add language preference columns to user_profiles
ALTER TABLE user_profiles 
ADD COLUMN IF NOT EXISTS preferred_language TEXT DEFAULT 'en-US',
ADD COLUMN IF NOT EXISTS avatar_language TEXT DEFAULT 'en-US';

-- Update existing rows to have default language values
UPDATE user_profiles 
SET preferred_language = 'en-US', avatar_language = 'en-US'
WHERE preferred_language IS NULL;