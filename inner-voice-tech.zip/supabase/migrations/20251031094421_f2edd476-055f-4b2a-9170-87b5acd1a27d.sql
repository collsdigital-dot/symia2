-- Update default video_background to use professional mental health office image
UPDATE user_profiles 
SET video_background = '{"type":"image","value":"https://xkcudhurtfbrmskihztk.supabase.co/storage/v1/object/public/site-assets/backgrounds/mental-health-office.jpg"}'::jsonb
WHERE video_background->>'type' = 'color' OR video_background IS NULL;