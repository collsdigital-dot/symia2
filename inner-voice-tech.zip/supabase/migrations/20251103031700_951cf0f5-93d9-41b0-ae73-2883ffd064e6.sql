-- Drop the existing confusing policy
DROP POLICY IF EXISTS "Service role only" ON public.otp_codes;

-- Create a clear, explicit policy that allows service role operations
CREATE POLICY "Allow service role full access"
ON public.otp_codes
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Ensure authenticated and anon roles have NO access
CREATE POLICY "Block public access"
ON public.otp_codes
FOR ALL
TO authenticated, anon
USING (false)
WITH CHECK (false);