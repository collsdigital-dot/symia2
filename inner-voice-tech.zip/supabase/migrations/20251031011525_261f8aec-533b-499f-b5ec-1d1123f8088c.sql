-- Create subscription_events table for logging all subscription activities
CREATE TABLE IF NOT EXISTS public.subscription_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  tier text NOT NULL CHECK (tier IN ('free', 'standard', 'premium')),
  duration_minutes integer NOT NULL,
  payment_status text NOT NULL CHECK (payment_status IN ('pending', 'success', 'failed', 'cancelled')),
  amount_usd numeric(10,2) NOT NULL,
  payment_method text,
  stripe_payment_intent_id text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.subscription_events ENABLE ROW LEVEL SECURITY;

-- Users can view their own subscription events
CREATE POLICY "Users can view own subscription events"
  ON public.subscription_events FOR SELECT
  USING (auth.uid() = user_id);

-- Service role can insert subscription events (for backend logging)
CREATE POLICY "Service role can insert subscription events"
  ON public.subscription_events FOR INSERT
  WITH CHECK (true);