-- Create storage bucket for custom backgrounds
INSERT INTO storage.buckets (id, name, public)
VALUES ('custom-backgrounds', 'custom-backgrounds', true)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for custom-backgrounds bucket
CREATE POLICY "Users can upload their own backgrounds"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'custom-backgrounds' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their own backgrounds"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'custom-backgrounds' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own backgrounds"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'custom-backgrounds' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Add video_background column to user_profiles
ALTER TABLE user_profiles 
ADD COLUMN IF NOT EXISTS video_background JSONB 
DEFAULT '{"type":"color","value":"#F5F5DC"}'::jsonb;