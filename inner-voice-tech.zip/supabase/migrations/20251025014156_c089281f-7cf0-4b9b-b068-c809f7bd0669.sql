-- Create live_session_transcripts table for storing conversation transcripts
CREATE TABLE IF NOT EXISTS public.live_session_transcripts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES public.live_sessions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  speaker TEXT NOT NULL CHECK (speaker IN ('user', 'assistant')),
  content TEXT NOT NULL,
  timestamp_offset_ms INTEGER DEFAULT 0,
  turn_index INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.live_session_transcripts ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own transcripts"
  ON public.live_session_transcripts FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own transcripts"
  ON public.live_session_transcripts FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX idx_transcripts_session ON public.live_session_transcripts(session_id);
CREATE INDEX idx_transcripts_user ON public.live_session_transcripts(user_id);
CREATE INDEX idx_transcripts_created ON public.live_session_transcripts(created_at DESC);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.live_session_transcripts;