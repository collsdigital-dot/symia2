-- Drop RPM-related table
DROP TABLE IF EXISTS public.rpm_sessions CASCADE;

-- Update user_avatars table structure
-- Remove any RPM-specific columns if they exist
ALTER TABLE public.user_avatars 
  DROP COLUMN IF EXISTS rpm_avatar_id CASCADE,
  DROP COLUMN IF EXISTS rpm_config CASCADE;

-- Ensure user_profiles has proper avatar_config structure for HeyGen
-- Set default HeyGen configuration for users who don't have one
UPDATE public.user_profiles
SET avatar_provider = 'heygen',
    heygen_avatar_id = COALESCE(heygen_avatar_id, 'Wayne_20240711'),
    heygen_voice_id = COALESCE(heygen_voice_id, '255f8e3f207d4cf58632f0ee48ea75ef')
WHERE avatar_provider IS NULL OR avatar_provider = 'rpm';