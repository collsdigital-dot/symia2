-- Phase 1: Standardize on LiveAvatar

-- Step 1: Drop existing check constraints
ALTER TABLE user_avatars DROP CONSTRAINT IF EXISTS user_avatars_avatar_type_check;
ALTER TABLE user_avatars DROP CONSTRAINT IF EXISTS user_avatars_status_check;

-- Step 2: Update all existing 'heygen' values to 'liveavatar'
UPDATE user_avatars 
SET avatar_type = 'liveavatar' 
WHERE avatar_type = 'heygen';

UPDATE user_avatars 
SET status = 'liveavatar' 
WHERE status = 'heygen';

-- Step 3: Add new check constraints with 'liveavatar' instead of 'heygen'
ALTER TABLE user_avatars 
ADD CONSTRAINT user_avatars_avatar_type_check 
CHECK (avatar_type = ANY (ARRAY['default'::text, '3d'::text, 'rpm'::text, 'liveavatar'::text]));

ALTER TABLE user_avatars 
ADD CONSTRAINT user_avatars_status_check 
CHECK (status = ANY (ARRAY['default'::text, 'customized'::text, 'liveavatar'::text]));

-- Step 4: Update all avatar_provider values from 'heygen' to 'liveavatar' in user_profiles
UPDATE user_profiles 
SET avatar_provider = 'liveavatar' 
WHERE avatar_provider = 'heygen';

-- Step 5: Update the default value for avatar_provider in user_profiles
ALTER TABLE user_profiles 
ALTER COLUMN avatar_provider SET DEFAULT 'liveavatar';