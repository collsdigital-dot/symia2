-- Drop the check constraint on preferred_voice that restricts values to OpenAI voices
ALTER TABLE public.user_profiles 
DROP CONSTRAINT IF EXISTS user_profiles_preferred_voice_check;

-- Update user_profiles table default for preferred_voice from OpenAI to HeyGen voice ID
ALTER TABLE public.user_profiles 
ALTER COLUMN preferred_voice SET DEFAULT '119caed25533477ba63822d5d1552d25';

-- Update existing users with OpenAI voice IDs to use HeyGen default
UPDATE public.user_profiles 
SET preferred_voice = '119caed25533477ba63822d5d1552d25'
WHERE preferred_voice IN ('shimmer', 'alloy', 'nova', 'ballad', 'coral', 'echo', 'sage', 'ash');