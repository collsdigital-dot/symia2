-- Drop the old constraint that only allowed 'default', '3d', and 'rpm'
ALTER TABLE user_avatars DROP CONSTRAINT user_avatars_avatar_type_check;

-- Add the new constraint with 'heygen' included
ALTER TABLE user_avatars ADD CONSTRAINT user_avatars_avatar_type_check 
CHECK (avatar_type = ANY (ARRAY['default'::text, '3d'::text, 'rpm'::text, 'heygen'::text]));