-- Backfill missing user_profiles for existing users
INSERT INTO user_profiles (user_id, full_name, preferred_voice, heygen_avatar_id, avatar_provider)
SELECT 
  au.id,
  COALESCE(NULLIF(split_part(au.email, '@', 1), ''), 'User'),
  'shimmer',
  'Angela-inblackskirt-20220820',
  'heygen'
FROM auth.users au
LEFT JOIN user_profiles up ON au.id = up.user_id
WHERE up.user_id IS NULL
ON CONFLICT (user_id) DO NOTHING;

-- Backfill missing usage_limits for existing users
INSERT INTO usage_limits (user_id, subscription_tier, live_demos_limit, text_chats_used, live_demos_used)
SELECT 
  au.id,
  'free',
  0,
  0,
  0
FROM auth.users au
LEFT JOIN usage_limits ul ON au.id = ul.user_id
WHERE ul.user_id IS NULL
ON CONFLICT (user_id) DO NOTHING;