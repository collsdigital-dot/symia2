-- Create user_avatars table
CREATE TABLE public.user_avatars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  avatar_type text NOT NULL DEFAULT 'default' CHECK (avatar_type IN ('default', '3d', 'rpm')),
  avatar_url text,
  config_json jsonb DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'default' CHECK (status IN ('default', 'customized')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE public.user_avatars ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own avatar"
  ON public.user_avatars FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own avatar"
  ON public.user_avatars FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own avatar"
  ON public.user_avatars FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Auto-update timestamp trigger
CREATE OR REPLACE FUNCTION public.handle_avatar_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_avatar_updated
  BEFORE UPDATE ON public.user_avatars
  FOR EACH ROW EXECUTE FUNCTION public.handle_avatar_updated_at();

-- Create live_sessions table
CREATE TABLE public.live_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  track_id text NOT NULL,
  track_title text NOT NULL,
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  seconds_used integer DEFAULT 0,
  avatar_snapshot_json jsonb DEFAULT '{}'::jsonb,
  quality_metrics_json jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.live_sessions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own live sessions"
  ON public.live_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own live sessions"
  ON public.live_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own live sessions"
  ON public.live_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Index for performance
CREATE INDEX live_sessions_user_id_idx ON public.live_sessions(user_id);
CREATE INDEX live_sessions_track_id_idx ON public.live_sessions(track_id);