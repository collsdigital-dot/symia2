-- Add preferred_voice column to user_profiles table
ALTER TABLE public.user_profiles 
ADD COLUMN preferred_voice TEXT DEFAULT 'shimmer' 
CHECK (preferred_voice IN ('alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse'));