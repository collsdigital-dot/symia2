-- Create enum for subscription tiers
CREATE TYPE public.subscription_tier AS ENUM ('free', 'standard', 'premium');

-- Create personalization_responses table
CREATE TABLE public.personalization_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  answers JSONB NOT NULL DEFAULT '{}',
  ai_insights JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create usage_limits table
CREATE TABLE public.usage_limits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subscription_tier subscription_tier NOT NULL DEFAULT 'free',
  live_demos_used INT NOT NULL DEFAULT 0,
  live_demos_limit INT NOT NULL DEFAULT 0,
  text_chats_used INT NOT NULL DEFAULT 0,
  reset_date TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '30 days'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE public.personalization_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.usage_limits ENABLE ROW LEVEL SECURITY;

-- RLS Policies for personalization_responses
CREATE POLICY "Users can view own personalization responses"
  ON public.personalization_responses
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own personalization responses"
  ON public.personalization_responses
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own personalization responses"
  ON public.personalization_responses
  FOR UPDATE
  USING (auth.uid() = user_id);

-- RLS Policies for usage_limits
CREATE POLICY "Users can view own usage limits"
  ON public.usage_limits
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own usage limits"
  ON public.usage_limits
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own usage limits"
  ON public.usage_limits
  FOR UPDATE
  USING (auth.uid() = user_id);

-- Create trigger function for updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Add triggers for updated_at
CREATE TRIGGER set_personalization_responses_updated_at
  BEFORE UPDATE ON public.personalization_responses
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_usage_limits_updated_at
  BEFORE UPDATE ON public.usage_limits
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- Create function to initialize usage limits for new users
CREATE OR REPLACE FUNCTION public.initialize_usage_limits()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.usage_limits (user_id, subscription_tier, live_demos_limit)
  VALUES (NEW.id, 'free', 0)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger to auto-create usage limits on user signup
CREATE TRIGGER on_auth_user_created_usage_limits
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.initialize_usage_limits();