-- Rename HeyGen columns to be provider-agnostic
ALTER TABLE user_profiles 
  RENAME COLUMN heygen_avatar_id TO liveavatar_id;

ALTER TABLE user_profiles
  RENAME COLUMN heygen_voice_id TO liveavatar_voice_id;

-- Add new columns for LiveAvatar configuration
ALTER TABLE user_profiles
  ADD COLUMN IF NOT EXISTS liveavatar_context_id TEXT,
  ADD COLUMN IF NOT EXISTS liveavatar_persona_id TEXT;

-- Create liveavatar_sessions table for session tracking
CREATE TABLE IF NOT EXISTS liveavatar_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  session_id TEXT NOT NULL,
  avatar_id TEXT NOT NULL,
  voice_id TEXT,
  context_id TEXT,
  category TEXT,
  duration_seconds INTEGER DEFAULT 0,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'ended', 'error')),
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for quick lookups
CREATE INDEX idx_liveavatar_sessions_user_id ON liveavatar_sessions(user_id);
CREATE INDEX idx_liveavatar_sessions_status ON liveavatar_sessions(status);

-- RLS policies
ALTER TABLE liveavatar_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own sessions"
  ON liveavatar_sessions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own sessions"
  ON liveavatar_sessions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sessions"
  ON liveavatar_sessions FOR UPDATE
  USING (auth.uid() = user_id);